/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package MainApplication;

import static java.awt.Color.black;
import static java.awt.Color.green;
import static java.awt.Color.white;
import java.awt.Container;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.Timer;
import javax.swing.border.MatteBorder;
import javax.swing.plaf.basic.BasicInternalFrameUI;


/**
 *
 * @author kurt
 */
public class StudentInformation extends javax.swing.JInternalFrame {
    /**
     * Creates new form Menu1
     */
    Timer timer;
    String Time = null, Date = null;
    public StudentInformation() {
        initComponents();
       
        this.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI panel = (BasicInternalFrameUI) this.getUI();
        panel.setNorthPane(null);
        
       ActionListener actionListener = (ActionEvent e) -> {
            Date time = new Date();
            DateFormat timeFormat = new SimpleDateFormat("hh:mm:ssa");
            Time = timeFormat.format(time);
            LiveTime.setText(Time);
            
            Date date = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date = dateFormat.format(date);
            LiveDate.setText(Date);
        };
        timer = new Timer(1000, actionListener);
        timer.setInitialDelay(0);
        timer.start();
        SetBorder(); 
        
    }
    Connection connect;
    public void Connect(){
       try{ Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
    String path = "C:\\Users\\ADMIN\\Documents\\AttendanceSystem.accdb";
    String url = "jdbc:ucanaccess://" + path;
    connect = DriverManager.getConnection(url);
       }
       catch(ClassNotFoundException | SQLException e){
   System.out.println(e);
  }}
    
    
    String section1;
    public void StudentInfo(){
        ClearMondaySched();
        ClearTuesdaySched();
        ClearWednesdaySched();
        ClearThursdaySched();
        ClearFridaySched();
        ClearSaturdaySched(); 
       
        String RFID = KeyGetter.getText();
           try{Connect();
            Statement st = connect.createStatement();
            int rowcount = 0;
            String query = "SELECT Count(*) FROM Table_Names";
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
             rowcount = rs.getInt(1);
            }
            rowcount++;
        for(int i = 1; i < rowcount; i++){
            String sql = "SELECT Section_Table FROM Table_Names WHERE ID = '"+i+"'";
            rs = st.executeQuery(sql);
            String StudentNumber = null;
            String section = null;
            while(rs.next()){
              section = rs.getString(1);
              
            }
            sql = "SELECT * FROM "+section+" WHERE RFID= '"+RFID+"'";  
           rs = st.executeQuery(sql);
           
           String Fname = null, Lname = null, Gender = null, ProfileID = null, Time_In = null, Time_Out = null, TimeDate = null, SGS = null;
            while(rs.next()){
                StudentNumber = rs.getString("Student_Number");
                Fname = rs.getString("Student_First_Name");
                Lname = rs.getString("Student_Last_Name");
                Gender = rs.getString("Gender");
                SGS = rs.getString("Strand_Grade_Section");
                section = SGS;
                ProfileID = rs.getString("ProfileID");
                Time_In = rs.getString("Time_In");
                Time_Out = rs.getString("Time_Out");
                TimeDate = rs.getString("TimeDate");
                
                section1 = section;
                
                ImageIcon ii = new ImageIcon(getClass().getResource("/Profiles/"+ ProfileID));
                Image img = ii.getImage().getScaledInstance(230,230, Image.SCALE_SMOOTH);
                ImageProfile.setIcon(new ImageIcon(img));
                
                jLabel5.setText(Time_In);
                jLabel6.setText(Time_Out);
                jLabel3.setText(StudentNumber);
                FirstNameInputLabel.setText(Fname);
                LastNameInputLabel.setText(Lname);
                GenderInputLabel.setText(Gender);
                
                LocalDate currentDate = LocalDate.now();
                if (TimeDate != null && TimeDate.equals(currentDate.toString())) {
                    // Entry already exists for today, don't allow time in or time out again
                    return;
                }
                
                boolean In = false, Out = false;
                if (Time_In == null) {
                    if (TimeDate != null && TimeDate.equals(currentDate.toString())) {  
                        
                    return;
                }
                    String TimeIn = LiveTime.getText();
                    jLabel5.setText(TimeIn);
                    sql = "UPDATE " + SGS + " SET Time_In = '" + TimeIn + "' WHERE Student_Number= '" + StudentNumber + "'";
                    st.executeUpdate(sql);
                }
                else if (Time_Out == null && Time_In != "") {
                   
                    String TimeOut = LiveTime.getText();
                    jLabel6.setText(TimeOut);
                    sql = "UPDATE " + SGS + " SET Time_Out = '" + TimeOut + "' WHERE Student_Number= '" + StudentNumber + "'";
                    st.executeUpdate(sql);
                    Out = true;
                }
                else if (Time_In != null && Time_Out != null){
                     TimeDate = LiveDate.getText();
                    sql = "UPDATE " + SGS + " SET TimeDate = '" + TimeDate + "' WHERE Student_Number= '" + StudentNumber + "'";
                    st.executeUpdate(sql);
                }
            }
        }
        }
        catch (Exception e){
            System.out.println(e);
        }
           finally{
            
            MondaySchd();
            TuesdaySchd();
            WednesdaySchd();
            ThursdaySchd();
            FridaySchd();
            SaturdaySchd();
            remove1s(); 
            KeyGetter.setText("");

           }
        
    }
 
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        LoginButton2 = new CustomElements.CurvedPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        LoginButton3 = new CustomElements.CurvedPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        curvedPanel1 = new CustomElements.CurvedPanel();
        jPanel1 = new javax.swing.JPanel();
        ImageProfile = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        FirstNameInputLabel = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        GenderInputLabel = new javax.swing.JLabel();
        LastNameInputLabel = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jPanel51 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        WEDNESDAY1_7TO8 = new javax.swing.JPanel();
        WEDNESDAY1_7TO8LABEL = new javax.swing.JLabel();
        MONDAY1_7TO8 = new javax.swing.JPanel();
        MONDAY1_7TO8LABEL = new javax.swing.JLabel();
        TUESDAY1_7TO8 = new javax.swing.JPanel();
        TUESDAY1_7TO8LABEL = new javax.swing.JLabel();
        THURSDAY1_7TO8 = new javax.swing.JPanel();
        THURSDAY1_7TO8LABEL = new javax.swing.JLabel();
        SATURDAY1_7TO8 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        jPanel61 = new javax.swing.JPanel();
        jLabel55 = new javax.swing.JLabel();
        jPanel42 = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        SATURDAY1_7TO8LABEL = new javax.swing.JLabel();
        FRIDAY1_7TO8 = new javax.swing.JPanel();
        FRIDAY1_7TO8LABEL = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        MONDAY2_7TO8 = new javax.swing.JPanel();
        MONDAY2_7TO8LABEL = new javax.swing.JLabel();
        TUESDAY2_7TO8 = new javax.swing.JPanel();
        TUESDAY2_7TO8LABEL = new javax.swing.JLabel();
        WEDNESDAY2_7TO8 = new javax.swing.JPanel();
        WEDNESDAY2_7TO8LABEL = new javax.swing.JLabel();
        THURSDAY2_7TO8 = new javax.swing.JPanel();
        THURSDAY2_7TO8LABEL = new javax.swing.JLabel();
        FRIDAY2_7TO8 = new javax.swing.JPanel();
        FRIDAY2_7TO8LABEL = new javax.swing.JLabel();
        SATURDAY2_7TO8 = new javax.swing.JPanel();
        SATURDAY2_7TO8LABEL = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        MONDAY1_8TO9 = new javax.swing.JPanel();
        MONDAY1_8TO9LABEL = new javax.swing.JLabel();
        MONDAY2_8TO9 = new javax.swing.JPanel();
        MONDAY2_8TO9LABEL = new javax.swing.JLabel();
        TUESDAY1_8TO9 = new javax.swing.JPanel();
        TUESDAY1_8TO9LABEL = new javax.swing.JLabel();
        TUESDAY2_8TO9 = new javax.swing.JPanel();
        TUESDAY2_8TO9LABEL = new javax.swing.JLabel();
        WEDNESDAY1_8TO9 = new javax.swing.JPanel();
        WEDNESDAY1_8TO9LABEL = new javax.swing.JLabel();
        WEDNESDAY2_8TO9 = new javax.swing.JPanel();
        WEDNESDAY2_8TO9LABEL = new javax.swing.JLabel();
        THURSDAY1_8TO9 = new javax.swing.JPanel();
        THURSDAY1_8TO9LABEL = new javax.swing.JLabel();
        THURSDAY2_8TO9 = new javax.swing.JPanel();
        THURSDAY2_8TO9LABEL = new javax.swing.JLabel();
        FRIDAY1_8TO9 = new javax.swing.JPanel();
        FRIDAY1_8TO9LABEL = new javax.swing.JLabel();
        FRIDAY2_8TO9 = new javax.swing.JPanel();
        FRIDAY2_8TO9LABEL = new javax.swing.JLabel();
        SATURDAY1_8TO9 = new javax.swing.JPanel();
        SATURDAY1_8TO9LABEL = new javax.swing.JLabel();
        SATURDAY2_8TO9 = new javax.swing.JPanel();
        SATURDAY2_8TO9LABEL = new javax.swing.JLabel();
        WEDNESDAY2_9TO10 = new javax.swing.JPanel();
        WEDNESDAY2_9TO10LABEL = new javax.swing.JLabel();
        TUESDAY2_9TO10 = new javax.swing.JPanel();
        TUESDAY2_9TO10LABEL = new javax.swing.JLabel();
        THURSDAY1_9TO10 = new javax.swing.JPanel();
        THURSDAY1_9TO10LABEL = new javax.swing.JLabel();
        FRIDAY2_9TO10 = new javax.swing.JPanel();
        FRIDAY2_9TO10LABEL = new javax.swing.JLabel();
        THURSDAY2_9TO10 = new javax.swing.JPanel();
        THURSDAY2_9TO10LABEL = new javax.swing.JLabel();
        SATURDAY2_9TO10 = new javax.swing.JPanel();
        SATURDAY2_9TO10LABEL = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        SATURDAY1_9TO10 = new javax.swing.JPanel();
        SATURDAY1_9TO10LABEL = new javax.swing.JLabel();
        FRIDAY1_9TO10 = new javax.swing.JPanel();
        FRIDAY1_9TO10LABEL = new javax.swing.JLabel();
        WEDNESDAY1_9TO10 = new javax.swing.JPanel();
        WEDNESDAY1_9TO10LABEL = new javax.swing.JLabel();
        TUESDAY1_9TO10 = new javax.swing.JPanel();
        TUESDAY1_9TO10LABEL = new javax.swing.JLabel();
        MONDAY1_9TO10 = new javax.swing.JPanel();
        MONDAY1_9TO10LABEL = new javax.swing.JLabel();
        MONDAY2_9TO10 = new javax.swing.JPanel();
        MONDAY2_9TO10LABEL = new javax.swing.JLabel();
        TUESDAY2_10TO11 = new javax.swing.JPanel();
        TUESDAY2_10TO11LABEL = new javax.swing.JLabel();
        WEDNESDAY2_10TO11 = new javax.swing.JPanel();
        WEDNESDAY2_10TO11LABEL = new javax.swing.JLabel();
        FRIDAY2_10TO11 = new javax.swing.JPanel();
        FRIDAY2_10TO11LABEL = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        SATURDAY1_10TO11 = new javax.swing.JPanel();
        SATURDAY1_10TO11LABEL = new javax.swing.JLabel();
        MONDAY2_10TO11 = new javax.swing.JPanel();
        MONDAY2_10TO11LABEL = new javax.swing.JLabel();
        THURSDAY1_10TO11 = new javax.swing.JPanel();
        THURSDAY1_10TO11LABEL = new javax.swing.JLabel();
        THURSDAY2_10TO11 = new javax.swing.JPanel();
        THURSDAY2_10TO11LABEL = new javax.swing.JLabel();
        FRIDAY1_10TO11 = new javax.swing.JPanel();
        FRIDAY1_10TO11LABEL = new javax.swing.JLabel();
        TUESDAY1_10TO11 = new javax.swing.JPanel();
        TUESDAY1_10TO11LABEL = new javax.swing.JLabel();
        WEDNESDAY1_10TO11 = new javax.swing.JPanel();
        WEDNESDAY1_10TO11LABEL = new javax.swing.JLabel();
        SATURDAY2_10TO11 = new javax.swing.JPanel();
        SATURDAY2_10TO11LABEL = new javax.swing.JLabel();
        MONDAY1_10TO11 = new javax.swing.JPanel();
        MONDAY1_10TO11LABEL = new javax.swing.JLabel();
        jPanel62 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        FRIDAY2_11TO12 = new javax.swing.JPanel();
        FRIDAY2_11TO12LABEL = new javax.swing.JLabel();
        jPanel64 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        TUESDAY2_11TO12 = new javax.swing.JPanel();
        TUESDAY2_11TO12LABEL = new javax.swing.JLabel();
        FRIDAY1_11TO12 = new javax.swing.JPanel();
        FRIDAY1_11TO12LABEL = new javax.swing.JLabel();
        WEDNESDAY2_11TO12 = new javax.swing.JPanel();
        WEDNESDAY2_11TO12LABEL = new javax.swing.JLabel();
        THURSDAY2_11TO12 = new javax.swing.JPanel();
        THURSDAY2_11TO12LABEL = new javax.swing.JLabel();
        SATURDAY1_11TO12 = new javax.swing.JPanel();
        SATURDAY1_11TO12LABEL = new javax.swing.JLabel();
        TUESDAY1_11TO12 = new javax.swing.JPanel();
        TUESDAY1_11TO12LABEL = new javax.swing.JLabel();
        MONDAY1_11TO12 = new javax.swing.JPanel();
        MONDAY1_11TO12LABEL = new javax.swing.JLabel();
        THURSDAY1_11TO12 = new javax.swing.JPanel();
        THURSDAY1_11TO12LABEL = new javax.swing.JLabel();
        MONDAY2_11TO12 = new javax.swing.JPanel();
        MONDAY2_11TO12LABEL = new javax.swing.JLabel();
        WEDNESDAY1_11TO12 = new javax.swing.JPanel();
        WEDNESDAY1_11TO12LABEL = new javax.swing.JLabel();
        SATURDAY2_11TO12 = new javax.swing.JPanel();
        SATURDAY2_11TO12LABEL = new javax.swing.JLabel();
        FRIDAY1_12TO1 = new javax.swing.JPanel();
        FRIDAY1_12TO1LABEL = new javax.swing.JLabel();
        SATURDAY1_12TO1 = new javax.swing.JPanel();
        SATURDAY1_12TO1LABEL = new javax.swing.JLabel();
        THURSDAY2_12TO1 = new javax.swing.JPanel();
        THURSDAY2_12TO1LABEL = new javax.swing.JLabel();
        FRIDAY2_12TO1 = new javax.swing.JPanel();
        FRIDAY2_12TO1LABEL = new javax.swing.JLabel();
        MONDAY2_12TO1 = new javax.swing.JPanel();
        MONDAY2_12TO1LABEL = new javax.swing.JLabel();
        MONDAY1_12TO1 = new javax.swing.JPanel();
        MONDAY1_12TO1LABEL = new javax.swing.JLabel();
        WEDNESDAY2_12TO1 = new javax.swing.JPanel();
        WEDNESDAY2_12TO1LABEL = new javax.swing.JLabel();
        jPanel83 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        SATURDAY2_12TO1 = new javax.swing.JPanel();
        SATURDAY2_12TO1LABEL = new javax.swing.JLabel();
        TUESDAY2_12TO1 = new javax.swing.JPanel();
        TUESDAY2_12TO1LABEL = new javax.swing.JLabel();
        WEDNESDAY1_12TO1 = new javax.swing.JPanel();
        WEDNESDAY1_12TO1LABEL = new javax.swing.JLabel();
        THURSDAY1_12TO1 = new javax.swing.JPanel();
        THURSDAY1_12TO1LABEL = new javax.swing.JLabel();
        TUESDAY1_12TO1 = new javax.swing.JPanel();
        TUESDAY1_12TO1LABEL = new javax.swing.JLabel();
        SATURDAY1_1TO2 = new javax.swing.JPanel();
        SATURDAY1_1TO2LABEL = new javax.swing.JLabel();
        TUESDAY2_1TO2 = new javax.swing.JPanel();
        TUESDAY2_1TO2LABEL = new javax.swing.JLabel();
        MONDAY2_1TO2 = new javax.swing.JPanel();
        MONDAY2_1TO2LABEL = new javax.swing.JLabel();
        WEDNESDAY1_1TO2 = new javax.swing.JPanel();
        WEDNESDAY1_1TO2LABEL = new javax.swing.JLabel();
        FRIDAY1_1TO2 = new javax.swing.JPanel();
        FRIDAY1_1TO2LABEL = new javax.swing.JLabel();
        FRIDAY2_1TO2 = new javax.swing.JPanel();
        FRIDAY2_1TO2LABEL = new javax.swing.JLabel();
        THURSDAY1_1TO2 = new javax.swing.JPanel();
        THURSDAY1_1TO2LABEL = new javax.swing.JLabel();
        SATURDAY2_1TO2 = new javax.swing.JPanel();
        SATURDAY2_1TO2LABEL = new javax.swing.JLabel();
        TUESDAY1_1TO2 = new javax.swing.JPanel();
        TUESDAY1_1TO2LABEL = new javax.swing.JLabel();
        jPanel98 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        MONDAY1_1TO2 = new javax.swing.JPanel();
        MONDAY1_1TO2LABEL = new javax.swing.JLabel();
        THURSDAY2_1TO2 = new javax.swing.JPanel();
        THURSDAY2_1TO2LABEL = new javax.swing.JLabel();
        WEDNESDAY2_1TO2 = new javax.swing.JPanel();
        WEDNESDAY2_1TO2LABEL = new javax.swing.JLabel();
        TUESDAY2_2TO3 = new javax.swing.JPanel();
        TUESDAY2_2TO3LABEL = new javax.swing.JLabel();
        WEDNESDAY2_2TO3 = new javax.swing.JPanel();
        WEDNESDAY2_2TO3LABEL = new javax.swing.JLabel();
        FRIDAY2_2TO3 = new javax.swing.JPanel();
        FRIDAY2_2TO3LABEL = new javax.swing.JLabel();
        jPanel105 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        SATURDAY1_2TO3 = new javax.swing.JPanel();
        SATURDAY1_2TO3LABEL = new javax.swing.JLabel();
        MONDAY1_2TO3 = new javax.swing.JPanel();
        MONDAY1_2TO3LABEL = new javax.swing.JLabel();
        SATURDAY2_2TO3 = new javax.swing.JPanel();
        SATURDAY2_2TO3LABEL = new javax.swing.JLabel();
        TUESDAY1_2TO3 = new javax.swing.JPanel();
        TUESDAY1_2TO3LABEL = new javax.swing.JLabel();
        WEDNESDAY1_2TO3 = new javax.swing.JPanel();
        WEDNESDAY1_2TO3LABEL = new javax.swing.JLabel();
        FRIDAY1_2TO3 = new javax.swing.JPanel();
        FRIDAY1_2TO3LABEL = new javax.swing.JLabel();
        THURSDAY1_2TO3 = new javax.swing.JPanel();
        THURSDAY1_2TO3LABEL = new javax.swing.JLabel();
        THURSDAY2_2TO3 = new javax.swing.JPanel();
        THURSDAY2_2TO3LABEL = new javax.swing.JLabel();
        MONDAY2_2TO3 = new javax.swing.JPanel();
        MONDAY2_2TO3LABEL = new javax.swing.JLabel();
        TUESDAY2_3TO4 = new javax.swing.JPanel();
        TUESDAY2_3TO4LABEL = new javax.swing.JLabel();
        FRIDAY2_3TO4 = new javax.swing.JPanel();
        FRIDAY2_3TO4LABEL = new javax.swing.JLabel();
        jPanel117 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        THURSDAY2_3TO4 = new javax.swing.JPanel();
        THURSDAY2_3TO4LABEL = new javax.swing.JLabel();
        TUESDAY1_3TO4 = new javax.swing.JPanel();
        TUESDAY1_3TO4LABEL = new javax.swing.JLabel();
        FRIDAY1_3TO4 = new javax.swing.JPanel();
        FRIDAY1_3TO4LABEL = new javax.swing.JLabel();
        MONDAY1_3TO4 = new javax.swing.JPanel();
        MONDAY1_3TO4LABEL = new javax.swing.JLabel();
        SATURDAY2_3TO4 = new javax.swing.JPanel();
        SATURDAY2_3TO4LABEL = new javax.swing.JLabel();
        MONDAY2_3TO4 = new javax.swing.JPanel();
        MONDAY2_3TO4LABEL = new javax.swing.JLabel();
        SATURDAY1_3TO4 = new javax.swing.JPanel();
        SATURDAY1_3TO4LABEL = new javax.swing.JLabel();
        WEDNESDAY1_3TO4 = new javax.swing.JPanel();
        WEDNESDAY1_3TO4LABEL = new javax.swing.JLabel();
        THURSDAY1_3TO4 = new javax.swing.JPanel();
        THURSDAY1_3TO4LABEL = new javax.swing.JLabel();
        WEDNESDAY2_3TO4 = new javax.swing.JPanel();
        WEDNESDAY2_3TO4LABEL = new javax.swing.JLabel();
        SATURDAY2_4TO5 = new javax.swing.JPanel();
        SATURDAY2_4TO5LABEL = new javax.swing.JLabel();
        MONDAY1_4TO5 = new javax.swing.JPanel();
        MONDAY1_4TO5LABEL = new javax.swing.JLabel();
        TUESDAY1_4TO5 = new javax.swing.JPanel();
        TUESDAY1_4TO5LABEL = new javax.swing.JLabel();
        THURSDAY2_4TO5 = new javax.swing.JPanel();
        THURSDAY2_4TO5LABEL = new javax.swing.JLabel();
        FRIDAY2_4TO5 = new javax.swing.JPanel();
        FRIDAY2_4TO5LABEL = new javax.swing.JLabel();
        SATURDAY1_4TO5 = new javax.swing.JPanel();
        SATURDAY1_4TO5LABEL = new javax.swing.JLabel();
        THURSDAY1_4TO5 = new javax.swing.JPanel();
        THURSDAY1_4TO5LABEL = new javax.swing.JLabel();
        WEDNESDAY2_4TO5 = new javax.swing.JPanel();
        WEDNESDAY2_4TO5LABEL = new javax.swing.JLabel();
        WEDNESDAY1_4TO5 = new javax.swing.JPanel();
        WEDNESDAY1_4TO5LABEL = new javax.swing.JLabel();
        TUESDAY2_4TO5 = new javax.swing.JPanel();
        TUESDAY2_4TO5LABEL = new javax.swing.JLabel();
        jPanel138 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        MONDAY2_4TO5 = new javax.swing.JPanel();
        MONDAY2_4TO5LABEL = new javax.swing.JLabel();
        FRIDAY1_4TO5 = new javax.swing.JPanel();
        FRIDAY1_4TO5LABEL = new javax.swing.JLabel();
        THURSDAY2_5TO6 = new javax.swing.JPanel();
        THURSDAY2_5TO6LABEL = new javax.swing.JLabel();
        MONDAY1_5TO6 = new javax.swing.JPanel();
        MONDAY1_5TO6LABEL = new javax.swing.JLabel();
        SATURDAY2_5TO6 = new javax.swing.JPanel();
        SATURDAY2_5TO6LABEL = new javax.swing.JLabel();
        TUESDAY1_5TO6 = new javax.swing.JPanel();
        TUESDAY1_5TO6LABEL = new javax.swing.JLabel();
        WEDNESDAY1_5TO6 = new javax.swing.JPanel();
        WEDNESDAY1_5TO6LABEL = new javax.swing.JLabel();
        FRIDAY1_5TO6 = new javax.swing.JPanel();
        FRIDAY1_5TO6LABEL = new javax.swing.JLabel();
        WEDNESDAY2_5TO6 = new javax.swing.JPanel();
        WEDNESDAY2_5TO6LABEL = new javax.swing.JLabel();
        jPanel148 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        TUESDAY2_5TO6 = new javax.swing.JPanel();
        TUESDAY2_5TO6LABEL = new javax.swing.JLabel();
        MONDAY2_5TO6 = new javax.swing.JPanel();
        MONDAY2_5TO6LABEL = new javax.swing.JLabel();
        SATURDAY1_5TO6 = new javax.swing.JPanel();
        SATURDAY1_5TO6LABEL = new javax.swing.JLabel();
        FRIDAY2_5TO6 = new javax.swing.JPanel();
        FRIDAY2_5TO6LABEL = new javax.swing.JLabel();
        THURSDAY1_5TO6 = new javax.swing.JPanel();
        THURSDAY1_5TO6LABEL = new javax.swing.JLabel();
        WEDNESDAY1_6TO7 = new javax.swing.JPanel();
        WEDNESDAY1_6TO7LABEL = new javax.swing.JLabel();
        THURSDAY2_6TO7 = new javax.swing.JPanel();
        THURSDAY2_6TO7LABEL = new javax.swing.JLabel();
        jPanel156 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        SATURDAY1_6TO7 = new javax.swing.JPanel();
        SATURDAY1_6TO7LABEL = new javax.swing.JLabel();
        MONDAY1_6TO7 = new javax.swing.JPanel();
        MONDAY1_6TO7LABEL = new javax.swing.JLabel();
        FRIDAY2_6TO7 = new javax.swing.JPanel();
        FRIDAY2_6TO7LABEL = new javax.swing.JLabel();
        SATURDAY2_6TO7 = new javax.swing.JPanel();
        SATURDAY2_6TO7LABEL = new javax.swing.JLabel();
        WEDNESDAY2_6TO7 = new javax.swing.JPanel();
        WEDNESDAY2_6TO7LABEL = new javax.swing.JLabel();
        TUESDAY1_6TO7 = new javax.swing.JPanel();
        TUESDAY1_6TO7LABEL = new javax.swing.JLabel();
        TUESDAY2_6TO7 = new javax.swing.JPanel();
        TUESDAY2_6TO7LABEL = new javax.swing.JLabel();
        MONDAY2_6TO7 = new javax.swing.JPanel();
        MONDAY2_6TO7LABEL = new javax.swing.JLabel();
        THURSDAY1_6TO7 = new javax.swing.JPanel();
        THURSDAY1_6TO7LABEL = new javax.swing.JLabel();
        FRIDAY1_6TO7 = new javax.swing.JPanel();
        FRIDAY1_6TO7LABEL = new javax.swing.JLabel();
        curvedPanel2 = new CustomElements.CurvedPanel();
        jLabel36 = new javax.swing.JLabel();
        LiveTime = new javax.swing.JLabel();
        LiveDate = new javax.swing.JLabel();
        KeyGetter = new javax.swing.JTextField();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(null);
        setNormalBounds(new java.awt.Rectangle(0, 0, 1700, 1010));
        setOpaque(true);
        setPreferredSize(new java.awt.Dimension(1000, 750));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setForeground(new java.awt.Color(0, 102, 204));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LoginButton2.setBackground(new java.awt.Color(0, 102, 204));
        LoginButton2.setRoundBottomLeft(15);
        LoginButton2.setRoundBottomRight(15);
        LoginButton2.setRoundTopLeft(15);
        LoginButton2.setRoundTopRight(15);

        jLabel1.setFont(new java.awt.Font("Bauhaus 93", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 0));
        jLabel1.setText("Time In:");

        jLabel5.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 52)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("00:00AM");

        javax.swing.GroupLayout LoginButton2Layout = new javax.swing.GroupLayout(LoginButton2);
        LoginButton2.setLayout(LoginButton2Layout);
        LoginButton2Layout.setHorizontalGroup(
            LoginButton2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginButton2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                .addContainerGap())
        );
        LoginButton2Layout.setVerticalGroup(
            LoginButton2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginButton2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(LoginButton2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LoginButton2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel2.add(LoginButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 50, 390, 110));

        LoginButton3.setBackground(new java.awt.Color(0, 102, 204));
        LoginButton3.setRoundBottomLeft(15);
        LoginButton3.setRoundBottomRight(15);
        LoginButton3.setRoundTopLeft(15);
        LoginButton3.setRoundTopRight(15);

        jLabel4.setFont(new java.awt.Font("Bauhaus 93", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 0));
        jLabel4.setText("Time Out:");

        jLabel6.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 52)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("00:00AM");

        javax.swing.GroupLayout LoginButton3Layout = new javax.swing.GroupLayout(LoginButton3);
        LoginButton3.setLayout(LoginButton3Layout);
        LoginButton3Layout.setHorizontalGroup(
            LoginButton3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginButton3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                .addContainerGap())
        );
        LoginButton3Layout.setVerticalGroup(
            LoginButton3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginButton3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(LoginButton3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LoginButton3Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(0, 62, Short.MAX_VALUE))
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel2.add(LoginButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 50, 420, 110));

        curvedPanel1.setBackground(new java.awt.Color(49, 140, 231));
        curvedPanel1.setRoundBottomLeft(30);
        curvedPanel1.setRoundBottomRight(30);
        curvedPanel1.setRoundTopLeft(30);
        curvedPanel1.setRoundTopRight(30);

        jPanel1.setAlignmentX(0.0F);
        jPanel1.setAlignmentY(0.0F);
        jPanel1.setPreferredSize(new java.awt.Dimension(200, 200));

        ImageProfile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ImageProfile.setText("Image of Student");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ImageProfile, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ImageProfile, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
        );

        jLabel8.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Gender:");

        jLabel3.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setPreferredSize(new java.awt.Dimension(89, 45));

        jLabel9.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Student Number:");

        jLabel10.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("First Name:");

        jLabel11.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Last Name:");

        jLabel12.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Grade Level:");

        jLabel13.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Strand & Section:");

        FirstNameInputLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        FirstNameInputLabel.setForeground(new java.awt.Color(255, 255, 255));

        jLabel28.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 24)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("[ADDITIONAL INFORMATION]");

        GenderInputLabel.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 36)); // NOI18N
        GenderInputLabel.setForeground(new java.awt.Color(255, 255, 255));
        GenderInputLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        GenderInputLabel.setPreferredSize(new java.awt.Dimension(68, 26));

        LastNameInputLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        LastNameInputLabel.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout curvedPanel1Layout = new javax.swing.GroupLayout(curvedPanel1);
        curvedPanel1.setLayout(curvedPanel1Layout);
        curvedPanel1Layout.setHorizontalGroup(
            curvedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(curvedPanel1Layout.createSequentialGroup()
                .addGroup(curvedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(curvedPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(curvedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(curvedPanel1Layout.createSequentialGroup()
                                .addGroup(curvedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(curvedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(FirstNameInputLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(LastNameInputLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(curvedPanel1Layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(jLabel28))
                    .addGroup(curvedPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(curvedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(curvedPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(curvedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(curvedPanel1Layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(curvedPanel1Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(curvedPanel1Layout.createSequentialGroup()
                                .addGap(53, 53, 53)
                                .addComponent(GenderInputLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        curvedPanel1Layout.setVerticalGroup(
            curvedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(curvedPanel1Layout.createSequentialGroup()
                .addGroup(curvedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(curvedPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(curvedPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(GenderInputLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(curvedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(curvedPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(22, 22, 22)
                        .addComponent(jLabel11))
                    .addGroup(curvedPanel1Layout.createSequentialGroup()
                        .addComponent(FirstNameInputLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(LastNameInputLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(11, 11, 11)
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addComponent(jLabel13)
                .addGap(112, 112, 112)
                .addComponent(jLabel28)
                .addContainerGap(184, Short.MAX_VALUE))
        );

        jPanel2.add(curvedPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, 490, 740));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jPanel4.setBackground(new java.awt.Color(0, 102, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Time");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addComponent(jLabel15)
                .addGap(42, 42, 42))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel15)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(0, 102, 204));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel5.setForeground(new java.awt.Color(255, 255, 255));

        jLabel37.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Monday");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel37)
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel37)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(0, 102, 204));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel6.setForeground(new java.awt.Color(255, 255, 255));

        jLabel38.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Tuesday");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel38)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel38)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel19.setBackground(new java.awt.Color(0, 102, 204));
        jPanel19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel19.setForeground(new java.awt.Color(255, 255, 255));

        jLabel39.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Wednesday");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel39)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel39)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel21.setBackground(new java.awt.Color(0, 102, 204));
        jPanel21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel21.setForeground(new java.awt.Color(255, 255, 255));

        jLabel40.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("Thursday");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel40)
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel40)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel22.setBackground(new java.awt.Color(0, 102, 204));
        jPanel22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel22.setForeground(new java.awt.Color(255, 255, 255));

        jLabel41.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("Friday");

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel41)
                .addContainerGap(40, Short.MAX_VALUE))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel41)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel51.setBackground(new java.awt.Color(0, 102, 204));
        jPanel51.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel51.setForeground(new java.awt.Color(255, 255, 255));

        jLabel42.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("Saturday");

        javax.swing.GroupLayout jPanel51Layout = new javax.swing.GroupLayout(jPanel51);
        jPanel51.setLayout(jPanel51Layout);
        jPanel51Layout.setHorizontalGroup(
            jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel51Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel42)
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel51Layout.setVerticalGroup(
            jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel51Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel42)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        WEDNESDAY1_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_7TO8LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_7TO8Layout = new javax.swing.GroupLayout(WEDNESDAY1_7TO8);
        WEDNESDAY1_7TO8.setLayout(WEDNESDAY1_7TO8Layout);
        WEDNESDAY1_7TO8Layout.setHorizontalGroup(
            WEDNESDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_7TO8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_7TO8Layout.setVerticalGroup(
            WEDNESDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_7TO8Layout.createSequentialGroup()
                .addComponent(WEDNESDAY1_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY1_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_7TO8LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_7TO8Layout = new javax.swing.GroupLayout(MONDAY1_7TO8);
        MONDAY1_7TO8.setLayout(MONDAY1_7TO8Layout);
        MONDAY1_7TO8Layout.setHorizontalGroup(
            MONDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_7TO8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MONDAY1_7TO8LABEL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        MONDAY1_7TO8Layout.setVerticalGroup(
            MONDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_7TO8Layout.createSequentialGroup()
                .addComponent(MONDAY1_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TUESDAY1_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_7TO8Layout = new javax.swing.GroupLayout(TUESDAY1_7TO8);
        TUESDAY1_7TO8.setLayout(TUESDAY1_7TO8Layout);
        TUESDAY1_7TO8Layout.setHorizontalGroup(
            TUESDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_7TO8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_7TO8Layout.setVerticalGroup(
            TUESDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_7TO8Layout.createSequentialGroup()
                .addComponent(TUESDAY1_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY1_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_7TO8LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_7TO8Layout = new javax.swing.GroupLayout(THURSDAY1_7TO8);
        THURSDAY1_7TO8.setLayout(THURSDAY1_7TO8Layout);
        THURSDAY1_7TO8Layout.setHorizontalGroup(
            THURSDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_7TO8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_7TO8Layout.setVerticalGroup(
            THURSDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_7TO8Layout.createSequentialGroup()
                .addComponent(THURSDAY1_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY1_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        jLabel47.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(0, 0, 0));
        jLabel47.setText("Room");

        jPanel61.setBackground(new java.awt.Color(255, 255, 255));
        jPanel61.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel61.setForeground(new java.awt.Color(0, 0, 0));
        jPanel61.setPreferredSize(new java.awt.Dimension(125, 28));

        jLabel55.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(0, 0, 0));
        jLabel55.setText("Room");

        jPanel42.setBackground(new java.awt.Color(255, 255, 255));
        jPanel42.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel42.setForeground(new java.awt.Color(0, 0, 0));
        jPanel42.setPreferredSize(new java.awt.Dimension(125, 28));

        jLabel56.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(0, 0, 0));
        jLabel56.setText("Room");

        javax.swing.GroupLayout jPanel42Layout = new javax.swing.GroupLayout(jPanel42);
        jPanel42.setLayout(jPanel42Layout);
        jPanel42Layout.setHorizontalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel42Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel56)
                .addGap(42, 42, 42))
        );
        jPanel42Layout.setVerticalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel42Layout.createSequentialGroup()
                .addComponent(jLabel56)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel61Layout = new javax.swing.GroupLayout(jPanel61);
        jPanel61.setLayout(jPanel61Layout);
        jPanel61Layout.setHorizontalGroup(
            jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel61Layout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addComponent(jLabel55)
                .addGap(36, 36, 36))
        );
        jPanel61Layout.setVerticalGroup(
            jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel61Layout.createSequentialGroup()
                .addComponent(jLabel55)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY1_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_7TO8LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_7TO8Layout = new javax.swing.GroupLayout(SATURDAY1_7TO8);
        SATURDAY1_7TO8.setLayout(SATURDAY1_7TO8Layout);
        SATURDAY1_7TO8Layout.setHorizontalGroup(
            SATURDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SATURDAY1_7TO8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY1_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel47)
                .addGap(36, 36, 36))
            .addGroup(SATURDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(SATURDAY1_7TO8Layout.createSequentialGroup()
                    .addGap(256, 256, 256)
                    .addComponent(jPanel61, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        SATURDAY1_7TO8Layout.setVerticalGroup(
            SATURDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_7TO8Layout.createSequentialGroup()
                .addGroup(SATURDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SATURDAY1_7TO8Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel47))
                    .addComponent(SATURDAY1_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(SATURDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(SATURDAY1_7TO8Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel61, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        FRIDAY1_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_7TO8LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_7TO8Layout = new javax.swing.GroupLayout(FRIDAY1_7TO8);
        FRIDAY1_7TO8.setLayout(FRIDAY1_7TO8Layout);
        FRIDAY1_7TO8Layout.setHorizontalGroup(
            FRIDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_7TO8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_7TO8Layout.setVerticalGroup(
            FRIDAY1_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_7TO8Layout.createSequentialGroup()
                .addComponent(FRIDAY1_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel9.setForeground(new java.awt.Color(0, 0, 0));
        jPanel9.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 0));
        jLabel16.setText("7:00-8:00");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel16)
                .addGap(22, 22, 22))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel16)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        MONDAY2_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_7TO8LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_7TO8Layout = new javax.swing.GroupLayout(MONDAY2_7TO8);
        MONDAY2_7TO8.setLayout(MONDAY2_7TO8Layout);
        MONDAY2_7TO8Layout.setHorizontalGroup(
            MONDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_7TO8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MONDAY2_7TO8LABEL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        MONDAY2_7TO8Layout.setVerticalGroup(
            MONDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_7TO8Layout.createSequentialGroup()
                .addComponent(MONDAY2_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TUESDAY2_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_7TO8Layout = new javax.swing.GroupLayout(TUESDAY2_7TO8);
        TUESDAY2_7TO8.setLayout(TUESDAY2_7TO8Layout);
        TUESDAY2_7TO8Layout.setHorizontalGroup(
            TUESDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_7TO8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_7TO8Layout.setVerticalGroup(
            TUESDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_7TO8Layout.createSequentialGroup()
                .addComponent(TUESDAY2_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY2_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_7TO8LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_7TO8Layout = new javax.swing.GroupLayout(WEDNESDAY2_7TO8);
        WEDNESDAY2_7TO8.setLayout(WEDNESDAY2_7TO8Layout);
        WEDNESDAY2_7TO8Layout.setHorizontalGroup(
            WEDNESDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_7TO8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_7TO8Layout.setVerticalGroup(
            WEDNESDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_7TO8Layout.createSequentialGroup()
                .addComponent(WEDNESDAY2_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY2_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_7TO8LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_7TO8Layout = new javax.swing.GroupLayout(THURSDAY2_7TO8);
        THURSDAY2_7TO8.setLayout(THURSDAY2_7TO8Layout);
        THURSDAY2_7TO8Layout.setHorizontalGroup(
            THURSDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_7TO8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_7TO8Layout.setVerticalGroup(
            THURSDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_7TO8Layout.createSequentialGroup()
                .addComponent(THURSDAY2_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY2_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_7TO8LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_7TO8Layout = new javax.swing.GroupLayout(FRIDAY2_7TO8);
        FRIDAY2_7TO8.setLayout(FRIDAY2_7TO8Layout);
        FRIDAY2_7TO8Layout.setHorizontalGroup(
            FRIDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_7TO8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY2_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY2_7TO8Layout.setVerticalGroup(
            FRIDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, FRIDAY2_7TO8Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(FRIDAY2_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        SATURDAY2_7TO8.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_7TO8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_7TO8.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_7TO8.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_7TO8LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_7TO8LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_7TO8LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_7TO8LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_7TO8Layout = new javax.swing.GroupLayout(SATURDAY2_7TO8);
        SATURDAY2_7TO8.setLayout(SATURDAY2_7TO8Layout);
        SATURDAY2_7TO8Layout.setHorizontalGroup(
            SATURDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_7TO8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_7TO8Layout.setVerticalGroup(
            SATURDAY2_7TO8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SATURDAY2_7TO8Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(SATURDAY2_7TO8LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel12.setForeground(new java.awt.Color(0, 0, 0));
        jPanel12.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 0, 0));
        jLabel17.setText("8:00-9:00");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel17)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel17)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        MONDAY1_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_8TO9LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_8TO9Layout = new javax.swing.GroupLayout(MONDAY1_8TO9);
        MONDAY1_8TO9.setLayout(MONDAY1_8TO9Layout);
        MONDAY1_8TO9Layout.setHorizontalGroup(
            MONDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY1_8TO9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY1_8TO9Layout.setVerticalGroup(
            MONDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_8TO9Layout.createSequentialGroup()
                .addComponent(MONDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        MONDAY2_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_8TO9LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_8TO9Layout = new javax.swing.GroupLayout(MONDAY2_8TO9);
        MONDAY2_8TO9.setLayout(MONDAY2_8TO9Layout);
        MONDAY2_8TO9Layout.setHorizontalGroup(
            MONDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_8TO9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY2_8TO9Layout.setVerticalGroup(
            MONDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_8TO9Layout.createSequentialGroup()
                .addComponent(MONDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TUESDAY1_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_8TO9Layout = new javax.swing.GroupLayout(TUESDAY1_8TO9);
        TUESDAY1_8TO9.setLayout(TUESDAY1_8TO9Layout);
        TUESDAY1_8TO9Layout.setHorizontalGroup(
            TUESDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_8TO9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_8TO9Layout.setVerticalGroup(
            TUESDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_8TO9Layout.createSequentialGroup()
                .addComponent(TUESDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY2_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_8TO9Layout = new javax.swing.GroupLayout(TUESDAY2_8TO9);
        TUESDAY2_8TO9.setLayout(TUESDAY2_8TO9Layout);
        TUESDAY2_8TO9Layout.setHorizontalGroup(
            TUESDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_8TO9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_8TO9Layout.setVerticalGroup(
            TUESDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_8TO9Layout.createSequentialGroup()
                .addComponent(TUESDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY1_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_8TO9LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_8TO9Layout = new javax.swing.GroupLayout(WEDNESDAY1_8TO9);
        WEDNESDAY1_8TO9.setLayout(WEDNESDAY1_8TO9Layout);
        WEDNESDAY1_8TO9Layout.setHorizontalGroup(
            WEDNESDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_8TO9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_8TO9Layout.setVerticalGroup(
            WEDNESDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_8TO9Layout.createSequentialGroup()
                .addComponent(WEDNESDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY2_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_8TO9LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_8TO9Layout = new javax.swing.GroupLayout(WEDNESDAY2_8TO9);
        WEDNESDAY2_8TO9.setLayout(WEDNESDAY2_8TO9Layout);
        WEDNESDAY2_8TO9Layout.setHorizontalGroup(
            WEDNESDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_8TO9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_8TO9Layout.setVerticalGroup(
            WEDNESDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_8TO9Layout.createSequentialGroup()
                .addComponent(WEDNESDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY1_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_8TO9LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_8TO9Layout = new javax.swing.GroupLayout(THURSDAY1_8TO9);
        THURSDAY1_8TO9.setLayout(THURSDAY1_8TO9Layout);
        THURSDAY1_8TO9Layout.setHorizontalGroup(
            THURSDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_8TO9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_8TO9Layout.setVerticalGroup(
            THURSDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_8TO9Layout.createSequentialGroup()
                .addComponent(THURSDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY2_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_8TO9LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_8TO9Layout = new javax.swing.GroupLayout(THURSDAY2_8TO9);
        THURSDAY2_8TO9.setLayout(THURSDAY2_8TO9Layout);
        THURSDAY2_8TO9Layout.setHorizontalGroup(
            THURSDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_8TO9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_8TO9Layout.setVerticalGroup(
            THURSDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_8TO9Layout.createSequentialGroup()
                .addComponent(THURSDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY1_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_8TO9LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_8TO9Layout = new javax.swing.GroupLayout(FRIDAY1_8TO9);
        FRIDAY1_8TO9.setLayout(FRIDAY1_8TO9Layout);
        FRIDAY1_8TO9Layout.setHorizontalGroup(
            FRIDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_8TO9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_8TO9Layout.setVerticalGroup(
            FRIDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_8TO9Layout.createSequentialGroup()
                .addComponent(FRIDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY2_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_8TO9LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_8TO9Layout = new javax.swing.GroupLayout(FRIDAY2_8TO9);
        FRIDAY2_8TO9.setLayout(FRIDAY2_8TO9Layout);
        FRIDAY2_8TO9Layout.setHorizontalGroup(
            FRIDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_8TO9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY2_8TO9Layout.setVerticalGroup(
            FRIDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_8TO9Layout.createSequentialGroup()
                .addComponent(FRIDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY1_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY1_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_8TO9LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_8TO9Layout = new javax.swing.GroupLayout(SATURDAY1_8TO9);
        SATURDAY1_8TO9.setLayout(SATURDAY1_8TO9Layout);
        SATURDAY1_8TO9Layout.setHorizontalGroup(
            SATURDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SATURDAY1_8TO9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(SATURDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );
        SATURDAY1_8TO9Layout.setVerticalGroup(
            SATURDAY1_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_8TO9Layout.createSequentialGroup()
                .addComponent(SATURDAY1_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY2_8TO9.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_8TO9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_8TO9.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_8TO9.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_8TO9LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_8TO9LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_8TO9LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_8TO9LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_8TO9Layout = new javax.swing.GroupLayout(SATURDAY2_8TO9);
        SATURDAY2_8TO9.setLayout(SATURDAY2_8TO9Layout);
        SATURDAY2_8TO9Layout.setHorizontalGroup(
            SATURDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_8TO9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_8TO9Layout.setVerticalGroup(
            SATURDAY2_8TO9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SATURDAY2_8TO9Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(SATURDAY2_8TO9LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        WEDNESDAY2_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_9TO10LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_9TO10Layout = new javax.swing.GroupLayout(WEDNESDAY2_9TO10);
        WEDNESDAY2_9TO10.setLayout(WEDNESDAY2_9TO10Layout);
        WEDNESDAY2_9TO10Layout.setHorizontalGroup(
            WEDNESDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_9TO10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_9TO10Layout.setVerticalGroup(
            WEDNESDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_9TO10Layout.createSequentialGroup()
                .addComponent(WEDNESDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY2_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_9TO10Layout = new javax.swing.GroupLayout(TUESDAY2_9TO10);
        TUESDAY2_9TO10.setLayout(TUESDAY2_9TO10Layout);
        TUESDAY2_9TO10Layout.setHorizontalGroup(
            TUESDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_9TO10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_9TO10Layout.setVerticalGroup(
            TUESDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_9TO10Layout.createSequentialGroup()
                .addComponent(TUESDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY1_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_9TO10LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_9TO10Layout = new javax.swing.GroupLayout(THURSDAY1_9TO10);
        THURSDAY1_9TO10.setLayout(THURSDAY1_9TO10Layout);
        THURSDAY1_9TO10Layout.setHorizontalGroup(
            THURSDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_9TO10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_9TO10Layout.setVerticalGroup(
            THURSDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_9TO10Layout.createSequentialGroup()
                .addComponent(THURSDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY2_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_9TO10LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_9TO10Layout = new javax.swing.GroupLayout(FRIDAY2_9TO10);
        FRIDAY2_9TO10.setLayout(FRIDAY2_9TO10Layout);
        FRIDAY2_9TO10Layout.setHorizontalGroup(
            FRIDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_9TO10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY2_9TO10Layout.setVerticalGroup(
            FRIDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_9TO10Layout.createSequentialGroup()
                .addComponent(FRIDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY2_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_9TO10LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_9TO10Layout = new javax.swing.GroupLayout(THURSDAY2_9TO10);
        THURSDAY2_9TO10.setLayout(THURSDAY2_9TO10Layout);
        THURSDAY2_9TO10Layout.setHorizontalGroup(
            THURSDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_9TO10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_9TO10Layout.setVerticalGroup(
            THURSDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_9TO10Layout.createSequentialGroup()
                .addComponent(THURSDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY2_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_9TO10LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_9TO10Layout = new javax.swing.GroupLayout(SATURDAY2_9TO10);
        SATURDAY2_9TO10.setLayout(SATURDAY2_9TO10Layout);
        SATURDAY2_9TO10Layout.setHorizontalGroup(
            SATURDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_9TO10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_9TO10Layout.setVerticalGroup(
            SATURDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_9TO10Layout.createSequentialGroup()
                .addComponent(SATURDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        jPanel18.setBackground(new java.awt.Color(255, 255, 255));
        jPanel18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel18.setForeground(new java.awt.Color(0, 0, 0));
        jPanel18.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 0));
        jLabel18.setText("9:00-10:00");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel18)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel18)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        SATURDAY1_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY1_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_9TO10LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_9TO10Layout = new javax.swing.GroupLayout(SATURDAY1_9TO10);
        SATURDAY1_9TO10.setLayout(SATURDAY1_9TO10Layout);
        SATURDAY1_9TO10Layout.setHorizontalGroup(
            SATURDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_9TO10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY1_9TO10Layout.setVerticalGroup(
            SATURDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_9TO10Layout.createSequentialGroup()
                .addComponent(SATURDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY1_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_9TO10LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_9TO10Layout = new javax.swing.GroupLayout(FRIDAY1_9TO10);
        FRIDAY1_9TO10.setLayout(FRIDAY1_9TO10Layout);
        FRIDAY1_9TO10Layout.setHorizontalGroup(
            FRIDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_9TO10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_9TO10Layout.setVerticalGroup(
            FRIDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_9TO10Layout.createSequentialGroup()
                .addComponent(FRIDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY1_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_9TO10LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_9TO10Layout = new javax.swing.GroupLayout(WEDNESDAY1_9TO10);
        WEDNESDAY1_9TO10.setLayout(WEDNESDAY1_9TO10Layout);
        WEDNESDAY1_9TO10Layout.setHorizontalGroup(
            WEDNESDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_9TO10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_9TO10Layout.setVerticalGroup(
            WEDNESDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_9TO10Layout.createSequentialGroup()
                .addComponent(WEDNESDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY1_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_9TO10Layout = new javax.swing.GroupLayout(TUESDAY1_9TO10);
        TUESDAY1_9TO10.setLayout(TUESDAY1_9TO10Layout);
        TUESDAY1_9TO10Layout.setHorizontalGroup(
            TUESDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_9TO10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_9TO10Layout.setVerticalGroup(
            TUESDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_9TO10Layout.createSequentialGroup()
                .addComponent(TUESDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY1_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_9TO10LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_9TO10Layout = new javax.swing.GroupLayout(MONDAY1_9TO10);
        MONDAY1_9TO10.setLayout(MONDAY1_9TO10Layout);
        MONDAY1_9TO10Layout.setHorizontalGroup(
            MONDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY1_9TO10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY1_9TO10Layout.setVerticalGroup(
            MONDAY1_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_9TO10Layout.createSequentialGroup()
                .addComponent(MONDAY1_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        MONDAY2_9TO10.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_9TO10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_9TO10.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_9TO10.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_9TO10LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_9TO10LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_9TO10LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_9TO10LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_9TO10Layout = new javax.swing.GroupLayout(MONDAY2_9TO10);
        MONDAY2_9TO10.setLayout(MONDAY2_9TO10Layout);
        MONDAY2_9TO10Layout.setHorizontalGroup(
            MONDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_9TO10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY2_9TO10Layout.setVerticalGroup(
            MONDAY2_9TO10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_9TO10Layout.createSequentialGroup()
                .addComponent(MONDAY2_9TO10LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TUESDAY2_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_10TO11Layout = new javax.swing.GroupLayout(TUESDAY2_10TO11);
        TUESDAY2_10TO11.setLayout(TUESDAY2_10TO11Layout);
        TUESDAY2_10TO11Layout.setHorizontalGroup(
            TUESDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_10TO11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_10TO11Layout.setVerticalGroup(
            TUESDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_10TO11Layout.createSequentialGroup()
                .addComponent(TUESDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY2_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_10TO11LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_10TO11Layout = new javax.swing.GroupLayout(WEDNESDAY2_10TO11);
        WEDNESDAY2_10TO11.setLayout(WEDNESDAY2_10TO11Layout);
        WEDNESDAY2_10TO11Layout.setHorizontalGroup(
            WEDNESDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_10TO11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_10TO11Layout.setVerticalGroup(
            WEDNESDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_10TO11Layout.createSequentialGroup()
                .addComponent(WEDNESDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY2_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_10TO11LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        jLabel93.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel93.setForeground(new java.awt.Color(0, 0, 0));
        jLabel93.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel93.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_10TO11Layout = new javax.swing.GroupLayout(FRIDAY2_10TO11);
        FRIDAY2_10TO11.setLayout(FRIDAY2_10TO11Layout);
        FRIDAY2_10TO11Layout.setHorizontalGroup(
            FRIDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_10TO11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(FRIDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(FRIDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel93, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY2_10TO11Layout.setVerticalGroup(
            FRIDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_10TO11Layout.createSequentialGroup()
                .addComponent(FRIDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel93, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        SATURDAY1_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY1_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_10TO11LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_10TO11Layout = new javax.swing.GroupLayout(SATURDAY1_10TO11);
        SATURDAY1_10TO11.setLayout(SATURDAY1_10TO11Layout);
        SATURDAY1_10TO11Layout.setHorizontalGroup(
            SATURDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_10TO11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY1_10TO11Layout.setVerticalGroup(
            SATURDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SATURDAY1_10TO11Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(SATURDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        MONDAY2_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_10TO11LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_10TO11Layout = new javax.swing.GroupLayout(MONDAY2_10TO11);
        MONDAY2_10TO11.setLayout(MONDAY2_10TO11Layout);
        MONDAY2_10TO11Layout.setHorizontalGroup(
            MONDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_10TO11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY2_10TO11Layout.setVerticalGroup(
            MONDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_10TO11Layout.createSequentialGroup()
                .addComponent(MONDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        THURSDAY1_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_10TO11LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_10TO11Layout = new javax.swing.GroupLayout(THURSDAY1_10TO11);
        THURSDAY1_10TO11.setLayout(THURSDAY1_10TO11Layout);
        THURSDAY1_10TO11Layout.setHorizontalGroup(
            THURSDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_10TO11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_10TO11Layout.setVerticalGroup(
            THURSDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_10TO11Layout.createSequentialGroup()
                .addComponent(THURSDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY2_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_10TO11LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_10TO11Layout = new javax.swing.GroupLayout(THURSDAY2_10TO11);
        THURSDAY2_10TO11.setLayout(THURSDAY2_10TO11Layout);
        THURSDAY2_10TO11Layout.setHorizontalGroup(
            THURSDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_10TO11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_10TO11Layout.setVerticalGroup(
            THURSDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_10TO11Layout.createSequentialGroup()
                .addComponent(THURSDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY1_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_10TO11LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_10TO11Layout = new javax.swing.GroupLayout(FRIDAY1_10TO11);
        FRIDAY1_10TO11.setLayout(FRIDAY1_10TO11Layout);
        FRIDAY1_10TO11Layout.setHorizontalGroup(
            FRIDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_10TO11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_10TO11Layout.setVerticalGroup(
            FRIDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_10TO11Layout.createSequentialGroup()
                .addComponent(FRIDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY1_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_10TO11Layout = new javax.swing.GroupLayout(TUESDAY1_10TO11);
        TUESDAY1_10TO11.setLayout(TUESDAY1_10TO11Layout);
        TUESDAY1_10TO11Layout.setHorizontalGroup(
            TUESDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_10TO11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_10TO11Layout.setVerticalGroup(
            TUESDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_10TO11Layout.createSequentialGroup()
                .addComponent(TUESDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY1_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_10TO11LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_10TO11Layout = new javax.swing.GroupLayout(WEDNESDAY1_10TO11);
        WEDNESDAY1_10TO11.setLayout(WEDNESDAY1_10TO11Layout);
        WEDNESDAY1_10TO11Layout.setHorizontalGroup(
            WEDNESDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_10TO11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_10TO11Layout.setVerticalGroup(
            WEDNESDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_10TO11Layout.createSequentialGroup()
                .addComponent(WEDNESDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY2_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_10TO11LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_10TO11Layout = new javax.swing.GroupLayout(SATURDAY2_10TO11);
        SATURDAY2_10TO11.setLayout(SATURDAY2_10TO11Layout);
        SATURDAY2_10TO11Layout.setHorizontalGroup(
            SATURDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_10TO11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_10TO11Layout.setVerticalGroup(
            SATURDAY2_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_10TO11Layout.createSequentialGroup()
                .addComponent(SATURDAY2_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY1_10TO11.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_10TO11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_10TO11.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_10TO11.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_10TO11LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_10TO11LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_10TO11LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_10TO11LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_10TO11Layout = new javax.swing.GroupLayout(MONDAY1_10TO11);
        MONDAY1_10TO11.setLayout(MONDAY1_10TO11Layout);
        MONDAY1_10TO11Layout.setHorizontalGroup(
            MONDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY1_10TO11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY1_10TO11Layout.setVerticalGroup(
            MONDAY1_10TO11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_10TO11Layout.createSequentialGroup()
                .addComponent(MONDAY1_10TO11LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel62.setBackground(new java.awt.Color(255, 255, 255));
        jPanel62.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel62.setForeground(new java.awt.Color(0, 0, 0));
        jPanel62.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 0));
        jLabel19.setText("10:00-11:00");

        javax.swing.GroupLayout jPanel62Layout = new javax.swing.GroupLayout(jPanel62);
        jPanel62.setLayout(jPanel62Layout);
        jPanel62Layout.setHorizontalGroup(
            jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel62Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel19)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel62Layout.setVerticalGroup(
            jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel62Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel19)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        FRIDAY2_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_11TO12LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_11TO12Layout = new javax.swing.GroupLayout(FRIDAY2_11TO12);
        FRIDAY2_11TO12.setLayout(FRIDAY2_11TO12Layout);
        FRIDAY2_11TO12Layout.setHorizontalGroup(
            FRIDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, FRIDAY2_11TO12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(FRIDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        FRIDAY2_11TO12Layout.setVerticalGroup(
            FRIDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_11TO12Layout.createSequentialGroup()
                .addComponent(FRIDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        jPanel64.setBackground(new java.awt.Color(255, 255, 255));
        jPanel64.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel64.setForeground(new java.awt.Color(0, 0, 0));
        jPanel64.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel20.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 0));
        jLabel20.setText("11:00-12:00");

        javax.swing.GroupLayout jPanel64Layout = new javax.swing.GroupLayout(jPanel64);
        jPanel64.setLayout(jPanel64Layout);
        jPanel64Layout.setHorizontalGroup(
            jPanel64Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel64Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel20)
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanel64Layout.setVerticalGroup(
            jPanel64Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel64Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel20)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        TUESDAY2_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_11TO12Layout = new javax.swing.GroupLayout(TUESDAY2_11TO12);
        TUESDAY2_11TO12.setLayout(TUESDAY2_11TO12Layout);
        TUESDAY2_11TO12Layout.setHorizontalGroup(
            TUESDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_11TO12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_11TO12Layout.setVerticalGroup(
            TUESDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_11TO12Layout.createSequentialGroup()
                .addComponent(TUESDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY1_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_11TO12LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_11TO12Layout = new javax.swing.GroupLayout(FRIDAY1_11TO12);
        FRIDAY1_11TO12.setLayout(FRIDAY1_11TO12Layout);
        FRIDAY1_11TO12Layout.setHorizontalGroup(
            FRIDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_11TO12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_11TO12Layout.setVerticalGroup(
            FRIDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_11TO12Layout.createSequentialGroup()
                .addComponent(FRIDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY2_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_11TO12LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_11TO12Layout = new javax.swing.GroupLayout(WEDNESDAY2_11TO12);
        WEDNESDAY2_11TO12.setLayout(WEDNESDAY2_11TO12Layout);
        WEDNESDAY2_11TO12Layout.setHorizontalGroup(
            WEDNESDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_11TO12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_11TO12Layout.setVerticalGroup(
            WEDNESDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WEDNESDAY2_11TO12Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(WEDNESDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        THURSDAY2_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_11TO12LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_11TO12Layout = new javax.swing.GroupLayout(THURSDAY2_11TO12);
        THURSDAY2_11TO12.setLayout(THURSDAY2_11TO12Layout);
        THURSDAY2_11TO12Layout.setHorizontalGroup(
            THURSDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_11TO12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_11TO12Layout.setVerticalGroup(
            THURSDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_11TO12Layout.createSequentialGroup()
                .addComponent(THURSDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY1_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY1_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_11TO12LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_11TO12Layout = new javax.swing.GroupLayout(SATURDAY1_11TO12);
        SATURDAY1_11TO12.setLayout(SATURDAY1_11TO12Layout);
        SATURDAY1_11TO12Layout.setHorizontalGroup(
            SATURDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_11TO12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY1_11TO12Layout.setVerticalGroup(
            SATURDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_11TO12Layout.createSequentialGroup()
                .addComponent(SATURDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY1_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_11TO12Layout = new javax.swing.GroupLayout(TUESDAY1_11TO12);
        TUESDAY1_11TO12.setLayout(TUESDAY1_11TO12Layout);
        TUESDAY1_11TO12Layout.setHorizontalGroup(
            TUESDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_11TO12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_11TO12Layout.setVerticalGroup(
            TUESDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_11TO12Layout.createSequentialGroup()
                .addComponent(TUESDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY1_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_11TO12LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_11TO12Layout = new javax.swing.GroupLayout(MONDAY1_11TO12);
        MONDAY1_11TO12.setLayout(MONDAY1_11TO12Layout);
        MONDAY1_11TO12Layout.setHorizontalGroup(
            MONDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY1_11TO12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY1_11TO12Layout.setVerticalGroup(
            MONDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_11TO12Layout.createSequentialGroup()
                .addComponent(MONDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        THURSDAY1_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_11TO12LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_11TO12Layout = new javax.swing.GroupLayout(THURSDAY1_11TO12);
        THURSDAY1_11TO12.setLayout(THURSDAY1_11TO12Layout);
        THURSDAY1_11TO12Layout.setHorizontalGroup(
            THURSDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_11TO12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_11TO12Layout.setVerticalGroup(
            THURSDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_11TO12Layout.createSequentialGroup()
                .addComponent(THURSDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY2_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_11TO12LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_11TO12Layout = new javax.swing.GroupLayout(MONDAY2_11TO12);
        MONDAY2_11TO12.setLayout(MONDAY2_11TO12Layout);
        MONDAY2_11TO12Layout.setHorizontalGroup(
            MONDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_11TO12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY2_11TO12Layout.setVerticalGroup(
            MONDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_11TO12Layout.createSequentialGroup()
                .addComponent(MONDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        WEDNESDAY1_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_11TO12LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_11TO12Layout = new javax.swing.GroupLayout(WEDNESDAY1_11TO12);
        WEDNESDAY1_11TO12.setLayout(WEDNESDAY1_11TO12Layout);
        WEDNESDAY1_11TO12Layout.setHorizontalGroup(
            WEDNESDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_11TO12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_11TO12Layout.setVerticalGroup(
            WEDNESDAY1_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WEDNESDAY1_11TO12Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(WEDNESDAY1_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        SATURDAY2_11TO12.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_11TO12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_11TO12.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_11TO12.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_11TO12LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_11TO12LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_11TO12LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_11TO12LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_11TO12Layout = new javax.swing.GroupLayout(SATURDAY2_11TO12);
        SATURDAY2_11TO12.setLayout(SATURDAY2_11TO12Layout);
        SATURDAY2_11TO12Layout.setHorizontalGroup(
            SATURDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_11TO12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_11TO12Layout.setVerticalGroup(
            SATURDAY2_11TO12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_11TO12Layout.createSequentialGroup()
                .addComponent(SATURDAY2_11TO12LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY1_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_12TO1LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_12TO1Layout = new javax.swing.GroupLayout(FRIDAY1_12TO1);
        FRIDAY1_12TO1.setLayout(FRIDAY1_12TO1Layout);
        FRIDAY1_12TO1Layout.setHorizontalGroup(
            FRIDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_12TO1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_12TO1Layout.setVerticalGroup(
            FRIDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_12TO1Layout.createSequentialGroup()
                .addComponent(FRIDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY1_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY1_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_12TO1LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_12TO1Layout = new javax.swing.GroupLayout(SATURDAY1_12TO1);
        SATURDAY1_12TO1.setLayout(SATURDAY1_12TO1Layout);
        SATURDAY1_12TO1Layout.setHorizontalGroup(
            SATURDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_12TO1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY1_12TO1Layout.setVerticalGroup(
            SATURDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SATURDAY1_12TO1Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(SATURDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        THURSDAY2_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_12TO1LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_12TO1Layout = new javax.swing.GroupLayout(THURSDAY2_12TO1);
        THURSDAY2_12TO1.setLayout(THURSDAY2_12TO1Layout);
        THURSDAY2_12TO1Layout.setHorizontalGroup(
            THURSDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_12TO1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_12TO1Layout.setVerticalGroup(
            THURSDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_12TO1Layout.createSequentialGroup()
                .addComponent(THURSDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY2_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_12TO1LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_12TO1Layout = new javax.swing.GroupLayout(FRIDAY2_12TO1);
        FRIDAY2_12TO1.setLayout(FRIDAY2_12TO1Layout);
        FRIDAY2_12TO1Layout.setHorizontalGroup(
            FRIDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_12TO1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY2_12TO1Layout.setVerticalGroup(
            FRIDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_12TO1Layout.createSequentialGroup()
                .addComponent(FRIDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY2_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_12TO1LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_12TO1Layout = new javax.swing.GroupLayout(MONDAY2_12TO1);
        MONDAY2_12TO1.setLayout(MONDAY2_12TO1Layout);
        MONDAY2_12TO1Layout.setHorizontalGroup(
            MONDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_12TO1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY2_12TO1Layout.setVerticalGroup(
            MONDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_12TO1Layout.createSequentialGroup()
                .addComponent(MONDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        MONDAY1_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_12TO1LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_12TO1Layout = new javax.swing.GroupLayout(MONDAY1_12TO1);
        MONDAY1_12TO1.setLayout(MONDAY1_12TO1Layout);
        MONDAY1_12TO1Layout.setHorizontalGroup(
            MONDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY1_12TO1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY1_12TO1Layout.setVerticalGroup(
            MONDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_12TO1Layout.createSequentialGroup()
                .addComponent(MONDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        WEDNESDAY2_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_12TO1LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_12TO1Layout = new javax.swing.GroupLayout(WEDNESDAY2_12TO1);
        WEDNESDAY2_12TO1.setLayout(WEDNESDAY2_12TO1Layout);
        WEDNESDAY2_12TO1Layout.setHorizontalGroup(
            WEDNESDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_12TO1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_12TO1Layout.setVerticalGroup(
            WEDNESDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WEDNESDAY2_12TO1Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(WEDNESDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel83.setBackground(new java.awt.Color(255, 255, 255));
        jPanel83.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel83.setForeground(new java.awt.Color(0, 0, 0));
        jPanel83.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel21.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 0));
        jLabel21.setText("12:00-1:00");

        javax.swing.GroupLayout jPanel83Layout = new javax.swing.GroupLayout(jPanel83);
        jPanel83.setLayout(jPanel83Layout);
        jPanel83Layout.setHorizontalGroup(
            jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel83Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel21)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel83Layout.setVerticalGroup(
            jPanel83Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel83Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel21)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        SATURDAY2_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_12TO1LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_12TO1Layout = new javax.swing.GroupLayout(SATURDAY2_12TO1);
        SATURDAY2_12TO1.setLayout(SATURDAY2_12TO1Layout);
        SATURDAY2_12TO1Layout.setHorizontalGroup(
            SATURDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_12TO1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_12TO1Layout.setVerticalGroup(
            SATURDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_12TO1Layout.createSequentialGroup()
                .addComponent(SATURDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY2_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_12TO1Layout = new javax.swing.GroupLayout(TUESDAY2_12TO1);
        TUESDAY2_12TO1.setLayout(TUESDAY2_12TO1Layout);
        TUESDAY2_12TO1Layout.setHorizontalGroup(
            TUESDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_12TO1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_12TO1Layout.setVerticalGroup(
            TUESDAY2_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_12TO1Layout.createSequentialGroup()
                .addComponent(TUESDAY2_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY1_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_12TO1LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_12TO1Layout = new javax.swing.GroupLayout(WEDNESDAY1_12TO1);
        WEDNESDAY1_12TO1.setLayout(WEDNESDAY1_12TO1Layout);
        WEDNESDAY1_12TO1Layout.setHorizontalGroup(
            WEDNESDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_12TO1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_12TO1Layout.setVerticalGroup(
            WEDNESDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_12TO1Layout.createSequentialGroup()
                .addComponent(WEDNESDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY1_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_12TO1LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_12TO1Layout = new javax.swing.GroupLayout(THURSDAY1_12TO1);
        THURSDAY1_12TO1.setLayout(THURSDAY1_12TO1Layout);
        THURSDAY1_12TO1Layout.setHorizontalGroup(
            THURSDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_12TO1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_12TO1Layout.setVerticalGroup(
            THURSDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_12TO1Layout.createSequentialGroup()
                .addComponent(THURSDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY1_12TO1.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_12TO1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_12TO1.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_12TO1.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_12TO1LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_12TO1LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_12TO1LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_12TO1Layout = new javax.swing.GroupLayout(TUESDAY1_12TO1);
        TUESDAY1_12TO1.setLayout(TUESDAY1_12TO1Layout);
        TUESDAY1_12TO1Layout.setHorizontalGroup(
            TUESDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_12TO1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_12TO1Layout.setVerticalGroup(
            TUESDAY1_12TO1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_12TO1Layout.createSequentialGroup()
                .addComponent(TUESDAY1_12TO1LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY1_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY1_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_1TO2LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_1TO2Layout = new javax.swing.GroupLayout(SATURDAY1_1TO2);
        SATURDAY1_1TO2.setLayout(SATURDAY1_1TO2Layout);
        SATURDAY1_1TO2Layout.setHorizontalGroup(
            SATURDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_1TO2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY1_1TO2Layout.setVerticalGroup(
            SATURDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SATURDAY1_1TO2Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(SATURDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        TUESDAY2_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_1TO2Layout = new javax.swing.GroupLayout(TUESDAY2_1TO2);
        TUESDAY2_1TO2.setLayout(TUESDAY2_1TO2Layout);
        TUESDAY2_1TO2Layout.setHorizontalGroup(
            TUESDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_1TO2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_1TO2Layout.setVerticalGroup(
            TUESDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_1TO2Layout.createSequentialGroup()
                .addComponent(TUESDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY2_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_1TO2LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_1TO2Layout = new javax.swing.GroupLayout(MONDAY2_1TO2);
        MONDAY2_1TO2.setLayout(MONDAY2_1TO2Layout);
        MONDAY2_1TO2Layout.setHorizontalGroup(
            MONDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_1TO2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY2_1TO2Layout.setVerticalGroup(
            MONDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_1TO2Layout.createSequentialGroup()
                .addComponent(MONDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        WEDNESDAY1_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_1TO2LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_1TO2Layout = new javax.swing.GroupLayout(WEDNESDAY1_1TO2);
        WEDNESDAY1_1TO2.setLayout(WEDNESDAY1_1TO2Layout);
        WEDNESDAY1_1TO2Layout.setHorizontalGroup(
            WEDNESDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_1TO2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_1TO2Layout.setVerticalGroup(
            WEDNESDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_1TO2Layout.createSequentialGroup()
                .addComponent(WEDNESDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY1_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_1TO2LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_1TO2Layout = new javax.swing.GroupLayout(FRIDAY1_1TO2);
        FRIDAY1_1TO2.setLayout(FRIDAY1_1TO2Layout);
        FRIDAY1_1TO2Layout.setHorizontalGroup(
            FRIDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_1TO2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_1TO2Layout.setVerticalGroup(
            FRIDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_1TO2Layout.createSequentialGroup()
                .addComponent(FRIDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY2_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_1TO2LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_1TO2Layout = new javax.swing.GroupLayout(FRIDAY2_1TO2);
        FRIDAY2_1TO2.setLayout(FRIDAY2_1TO2Layout);
        FRIDAY2_1TO2Layout.setHorizontalGroup(
            FRIDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_1TO2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY2_1TO2Layout.setVerticalGroup(
            FRIDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_1TO2Layout.createSequentialGroup()
                .addComponent(FRIDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY1_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_1TO2LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_1TO2Layout = new javax.swing.GroupLayout(THURSDAY1_1TO2);
        THURSDAY1_1TO2.setLayout(THURSDAY1_1TO2Layout);
        THURSDAY1_1TO2Layout.setHorizontalGroup(
            THURSDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_1TO2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_1TO2Layout.setVerticalGroup(
            THURSDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_1TO2Layout.createSequentialGroup()
                .addComponent(THURSDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY2_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_1TO2LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_1TO2Layout = new javax.swing.GroupLayout(SATURDAY2_1TO2);
        SATURDAY2_1TO2.setLayout(SATURDAY2_1TO2Layout);
        SATURDAY2_1TO2Layout.setHorizontalGroup(
            SATURDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_1TO2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_1TO2Layout.setVerticalGroup(
            SATURDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SATURDAY2_1TO2Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(SATURDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        TUESDAY1_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_1TO2Layout = new javax.swing.GroupLayout(TUESDAY1_1TO2);
        TUESDAY1_1TO2.setLayout(TUESDAY1_1TO2Layout);
        TUESDAY1_1TO2Layout.setHorizontalGroup(
            TUESDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_1TO2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_1TO2Layout.setVerticalGroup(
            TUESDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_1TO2Layout.createSequentialGroup()
                .addComponent(TUESDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        jPanel98.setBackground(new java.awt.Color(255, 255, 255));
        jPanel98.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel98.setForeground(new java.awt.Color(0, 0, 0));
        jPanel98.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 0, 0));
        jLabel22.setText("1:00-2:00");

        javax.swing.GroupLayout jPanel98Layout = new javax.swing.GroupLayout(jPanel98);
        jPanel98.setLayout(jPanel98Layout);
        jPanel98Layout.setHorizontalGroup(
            jPanel98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel98Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel22)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel98Layout.setVerticalGroup(
            jPanel98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel98Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel22)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        MONDAY1_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_1TO2LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_1TO2Layout = new javax.swing.GroupLayout(MONDAY1_1TO2);
        MONDAY1_1TO2.setLayout(MONDAY1_1TO2Layout);
        MONDAY1_1TO2Layout.setHorizontalGroup(
            MONDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY1_1TO2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY1_1TO2Layout.setVerticalGroup(
            MONDAY1_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_1TO2Layout.createSequentialGroup()
                .addComponent(MONDAY1_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        THURSDAY2_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_1TO2LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_1TO2Layout = new javax.swing.GroupLayout(THURSDAY2_1TO2);
        THURSDAY2_1TO2.setLayout(THURSDAY2_1TO2Layout);
        THURSDAY2_1TO2Layout.setHorizontalGroup(
            THURSDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_1TO2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_1TO2Layout.setVerticalGroup(
            THURSDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_1TO2Layout.createSequentialGroup()
                .addComponent(THURSDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY2_1TO2.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_1TO2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_1TO2.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_1TO2.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_1TO2LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_1TO2LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_1TO2LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_1TO2LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_1TO2Layout = new javax.swing.GroupLayout(WEDNESDAY2_1TO2);
        WEDNESDAY2_1TO2.setLayout(WEDNESDAY2_1TO2Layout);
        WEDNESDAY2_1TO2Layout.setHorizontalGroup(
            WEDNESDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_1TO2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_1TO2Layout.setVerticalGroup(
            WEDNESDAY2_1TO2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_1TO2Layout.createSequentialGroup()
                .addComponent(WEDNESDAY2_1TO2LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY2_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_2TO3Layout = new javax.swing.GroupLayout(TUESDAY2_2TO3);
        TUESDAY2_2TO3.setLayout(TUESDAY2_2TO3Layout);
        TUESDAY2_2TO3Layout.setHorizontalGroup(
            TUESDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_2TO3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_2TO3Layout.setVerticalGroup(
            TUESDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_2TO3Layout.createSequentialGroup()
                .addComponent(TUESDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY2_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_2TO3LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_2TO3Layout = new javax.swing.GroupLayout(WEDNESDAY2_2TO3);
        WEDNESDAY2_2TO3.setLayout(WEDNESDAY2_2TO3Layout);
        WEDNESDAY2_2TO3Layout.setHorizontalGroup(
            WEDNESDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_2TO3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_2TO3Layout.setVerticalGroup(
            WEDNESDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_2TO3Layout.createSequentialGroup()
                .addComponent(WEDNESDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY2_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_2TO3LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_2TO3Layout = new javax.swing.GroupLayout(FRIDAY2_2TO3);
        FRIDAY2_2TO3.setLayout(FRIDAY2_2TO3Layout);
        FRIDAY2_2TO3Layout.setHorizontalGroup(
            FRIDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_2TO3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY2_2TO3Layout.setVerticalGroup(
            FRIDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_2TO3Layout.createSequentialGroup()
                .addComponent(FRIDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        jPanel105.setBackground(new java.awt.Color(255, 255, 255));
        jPanel105.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel105.setForeground(new java.awt.Color(0, 0, 0));
        jPanel105.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 0, 0));
        jLabel23.setText("2:00-3:00");

        javax.swing.GroupLayout jPanel105Layout = new javax.swing.GroupLayout(jPanel105);
        jPanel105.setLayout(jPanel105Layout);
        jPanel105Layout.setHorizontalGroup(
            jPanel105Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel105Layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(jLabel23)
                .addGap(23, 23, 23))
        );
        jPanel105Layout.setVerticalGroup(
            jPanel105Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel105Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel23)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        SATURDAY1_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY1_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_2TO3LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_2TO3Layout = new javax.swing.GroupLayout(SATURDAY1_2TO3);
        SATURDAY1_2TO3.setLayout(SATURDAY1_2TO3Layout);
        SATURDAY1_2TO3Layout.setHorizontalGroup(
            SATURDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_2TO3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY1_2TO3Layout.setVerticalGroup(
            SATURDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_2TO3Layout.createSequentialGroup()
                .addComponent(SATURDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY1_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_2TO3LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_2TO3Layout = new javax.swing.GroupLayout(MONDAY1_2TO3);
        MONDAY1_2TO3.setLayout(MONDAY1_2TO3Layout);
        MONDAY1_2TO3Layout.setHorizontalGroup(
            MONDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY1_2TO3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY1_2TO3Layout.setVerticalGroup(
            MONDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_2TO3Layout.createSequentialGroup()
                .addComponent(MONDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        SATURDAY2_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_2TO3LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_2TO3Layout = new javax.swing.GroupLayout(SATURDAY2_2TO3);
        SATURDAY2_2TO3.setLayout(SATURDAY2_2TO3Layout);
        SATURDAY2_2TO3Layout.setHorizontalGroup(
            SATURDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_2TO3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_2TO3Layout.setVerticalGroup(
            SATURDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_2TO3Layout.createSequentialGroup()
                .addComponent(SATURDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY1_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_2TO3Layout = new javax.swing.GroupLayout(TUESDAY1_2TO3);
        TUESDAY1_2TO3.setLayout(TUESDAY1_2TO3Layout);
        TUESDAY1_2TO3Layout.setHorizontalGroup(
            TUESDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_2TO3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_2TO3Layout.setVerticalGroup(
            TUESDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_2TO3Layout.createSequentialGroup()
                .addComponent(TUESDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY1_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_2TO3LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_2TO3Layout = new javax.swing.GroupLayout(WEDNESDAY1_2TO3);
        WEDNESDAY1_2TO3.setLayout(WEDNESDAY1_2TO3Layout);
        WEDNESDAY1_2TO3Layout.setHorizontalGroup(
            WEDNESDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_2TO3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_2TO3Layout.setVerticalGroup(
            WEDNESDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WEDNESDAY1_2TO3Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(WEDNESDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        FRIDAY1_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_2TO3LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_2TO3Layout = new javax.swing.GroupLayout(FRIDAY1_2TO3);
        FRIDAY1_2TO3.setLayout(FRIDAY1_2TO3Layout);
        FRIDAY1_2TO3Layout.setHorizontalGroup(
            FRIDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_2TO3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_2TO3Layout.setVerticalGroup(
            FRIDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_2TO3Layout.createSequentialGroup()
                .addComponent(FRIDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY1_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_2TO3LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_2TO3Layout = new javax.swing.GroupLayout(THURSDAY1_2TO3);
        THURSDAY1_2TO3.setLayout(THURSDAY1_2TO3Layout);
        THURSDAY1_2TO3Layout.setHorizontalGroup(
            THURSDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_2TO3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_2TO3Layout.setVerticalGroup(
            THURSDAY1_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_2TO3Layout.createSequentialGroup()
                .addComponent(THURSDAY1_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY2_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_2TO3LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_2TO3Layout = new javax.swing.GroupLayout(THURSDAY2_2TO3);
        THURSDAY2_2TO3.setLayout(THURSDAY2_2TO3Layout);
        THURSDAY2_2TO3Layout.setHorizontalGroup(
            THURSDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_2TO3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_2TO3Layout.setVerticalGroup(
            THURSDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_2TO3Layout.createSequentialGroup()
                .addComponent(THURSDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY2_2TO3.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_2TO3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_2TO3.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_2TO3.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_2TO3LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_2TO3LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_2TO3LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_2TO3LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_2TO3Layout = new javax.swing.GroupLayout(MONDAY2_2TO3);
        MONDAY2_2TO3.setLayout(MONDAY2_2TO3Layout);
        MONDAY2_2TO3Layout.setHorizontalGroup(
            MONDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_2TO3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY2_2TO3Layout.setVerticalGroup(
            MONDAY2_2TO3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_2TO3Layout.createSequentialGroup()
                .addComponent(MONDAY2_2TO3LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TUESDAY2_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_3TO4Layout = new javax.swing.GroupLayout(TUESDAY2_3TO4);
        TUESDAY2_3TO4.setLayout(TUESDAY2_3TO4Layout);
        TUESDAY2_3TO4Layout.setHorizontalGroup(
            TUESDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_3TO4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_3TO4Layout.setVerticalGroup(
            TUESDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_3TO4Layout.createSequentialGroup()
                .addComponent(TUESDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY2_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_3TO4LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_3TO4Layout = new javax.swing.GroupLayout(FRIDAY2_3TO4);
        FRIDAY2_3TO4.setLayout(FRIDAY2_3TO4Layout);
        FRIDAY2_3TO4Layout.setHorizontalGroup(
            FRIDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_3TO4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY2_3TO4Layout.setVerticalGroup(
            FRIDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_3TO4Layout.createSequentialGroup()
                .addComponent(FRIDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        jPanel117.setBackground(new java.awt.Color(255, 255, 255));
        jPanel117.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel117.setForeground(new java.awt.Color(0, 0, 0));
        jPanel117.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel24.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 0, 0));
        jLabel24.setText("3:00-4:00");

        javax.swing.GroupLayout jPanel117Layout = new javax.swing.GroupLayout(jPanel117);
        jPanel117.setLayout(jPanel117Layout);
        jPanel117Layout.setHorizontalGroup(
            jPanel117Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel117Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel24)
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel117Layout.setVerticalGroup(
            jPanel117Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel117Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel24)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        THURSDAY2_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_3TO4LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_3TO4Layout = new javax.swing.GroupLayout(THURSDAY2_3TO4);
        THURSDAY2_3TO4.setLayout(THURSDAY2_3TO4Layout);
        THURSDAY2_3TO4Layout.setHorizontalGroup(
            THURSDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_3TO4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_3TO4Layout.setVerticalGroup(
            THURSDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_3TO4Layout.createSequentialGroup()
                .addComponent(THURSDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY1_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_3TO4Layout = new javax.swing.GroupLayout(TUESDAY1_3TO4);
        TUESDAY1_3TO4.setLayout(TUESDAY1_3TO4Layout);
        TUESDAY1_3TO4Layout.setHorizontalGroup(
            TUESDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_3TO4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_3TO4Layout.setVerticalGroup(
            TUESDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_3TO4Layout.createSequentialGroup()
                .addComponent(TUESDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY1_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_3TO4LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_3TO4Layout = new javax.swing.GroupLayout(FRIDAY1_3TO4);
        FRIDAY1_3TO4.setLayout(FRIDAY1_3TO4Layout);
        FRIDAY1_3TO4Layout.setHorizontalGroup(
            FRIDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_3TO4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_3TO4Layout.setVerticalGroup(
            FRIDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_3TO4Layout.createSequentialGroup()
                .addComponent(FRIDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY1_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_3TO4LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_3TO4Layout = new javax.swing.GroupLayout(MONDAY1_3TO4);
        MONDAY1_3TO4.setLayout(MONDAY1_3TO4Layout);
        MONDAY1_3TO4Layout.setHorizontalGroup(
            MONDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY1_3TO4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY1_3TO4Layout.setVerticalGroup(
            MONDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_3TO4Layout.createSequentialGroup()
                .addComponent(MONDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        SATURDAY2_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_3TO4LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_3TO4Layout = new javax.swing.GroupLayout(SATURDAY2_3TO4);
        SATURDAY2_3TO4.setLayout(SATURDAY2_3TO4Layout);
        SATURDAY2_3TO4Layout.setHorizontalGroup(
            SATURDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_3TO4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_3TO4Layout.setVerticalGroup(
            SATURDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_3TO4Layout.createSequentialGroup()
                .addComponent(SATURDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY2_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_3TO4LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_3TO4Layout = new javax.swing.GroupLayout(MONDAY2_3TO4);
        MONDAY2_3TO4.setLayout(MONDAY2_3TO4Layout);
        MONDAY2_3TO4Layout.setHorizontalGroup(
            MONDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_3TO4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY2_3TO4Layout.setVerticalGroup(
            MONDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_3TO4Layout.createSequentialGroup()
                .addComponent(MONDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        SATURDAY1_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY1_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_3TO4LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_3TO4Layout = new javax.swing.GroupLayout(SATURDAY1_3TO4);
        SATURDAY1_3TO4.setLayout(SATURDAY1_3TO4Layout);
        SATURDAY1_3TO4Layout.setHorizontalGroup(
            SATURDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_3TO4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY1_3TO4Layout.setVerticalGroup(
            SATURDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_3TO4Layout.createSequentialGroup()
                .addComponent(SATURDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY1_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_3TO4LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_3TO4Layout = new javax.swing.GroupLayout(WEDNESDAY1_3TO4);
        WEDNESDAY1_3TO4.setLayout(WEDNESDAY1_3TO4Layout);
        WEDNESDAY1_3TO4Layout.setHorizontalGroup(
            WEDNESDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_3TO4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_3TO4Layout.setVerticalGroup(
            WEDNESDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_3TO4Layout.createSequentialGroup()
                .addComponent(WEDNESDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY1_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_3TO4LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_3TO4Layout = new javax.swing.GroupLayout(THURSDAY1_3TO4);
        THURSDAY1_3TO4.setLayout(THURSDAY1_3TO4Layout);
        THURSDAY1_3TO4Layout.setHorizontalGroup(
            THURSDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_3TO4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_3TO4Layout.setVerticalGroup(
            THURSDAY1_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_3TO4Layout.createSequentialGroup()
                .addComponent(THURSDAY1_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY2_3TO4.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_3TO4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_3TO4.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_3TO4.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_3TO4LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_3TO4LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_3TO4LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_3TO4LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_3TO4Layout = new javax.swing.GroupLayout(WEDNESDAY2_3TO4);
        WEDNESDAY2_3TO4.setLayout(WEDNESDAY2_3TO4Layout);
        WEDNESDAY2_3TO4Layout.setHorizontalGroup(
            WEDNESDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_3TO4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_3TO4Layout.setVerticalGroup(
            WEDNESDAY2_3TO4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_3TO4Layout.createSequentialGroup()
                .addComponent(WEDNESDAY2_3TO4LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY2_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_4TO5LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_4TO5Layout = new javax.swing.GroupLayout(SATURDAY2_4TO5);
        SATURDAY2_4TO5.setLayout(SATURDAY2_4TO5Layout);
        SATURDAY2_4TO5Layout.setHorizontalGroup(
            SATURDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_4TO5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_4TO5Layout.setVerticalGroup(
            SATURDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_4TO5Layout.createSequentialGroup()
                .addComponent(SATURDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY1_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_4TO5LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_4TO5Layout = new javax.swing.GroupLayout(MONDAY1_4TO5);
        MONDAY1_4TO5.setLayout(MONDAY1_4TO5Layout);
        MONDAY1_4TO5Layout.setHorizontalGroup(
            MONDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY1_4TO5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY1_4TO5Layout.setVerticalGroup(
            MONDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_4TO5Layout.createSequentialGroup()
                .addComponent(MONDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TUESDAY1_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_4TO5Layout = new javax.swing.GroupLayout(TUESDAY1_4TO5);
        TUESDAY1_4TO5.setLayout(TUESDAY1_4TO5Layout);
        TUESDAY1_4TO5Layout.setHorizontalGroup(
            TUESDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_4TO5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_4TO5Layout.setVerticalGroup(
            TUESDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_4TO5Layout.createSequentialGroup()
                .addComponent(TUESDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY2_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_4TO5LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_4TO5Layout = new javax.swing.GroupLayout(THURSDAY2_4TO5);
        THURSDAY2_4TO5.setLayout(THURSDAY2_4TO5Layout);
        THURSDAY2_4TO5Layout.setHorizontalGroup(
            THURSDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_4TO5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_4TO5Layout.setVerticalGroup(
            THURSDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_4TO5Layout.createSequentialGroup()
                .addComponent(THURSDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY2_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_4TO5LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_4TO5Layout = new javax.swing.GroupLayout(FRIDAY2_4TO5);
        FRIDAY2_4TO5.setLayout(FRIDAY2_4TO5Layout);
        FRIDAY2_4TO5Layout.setHorizontalGroup(
            FRIDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_4TO5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY2_4TO5Layout.setVerticalGroup(
            FRIDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_4TO5Layout.createSequentialGroup()
                .addComponent(FRIDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY1_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY1_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_4TO5LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_4TO5Layout = new javax.swing.GroupLayout(SATURDAY1_4TO5);
        SATURDAY1_4TO5.setLayout(SATURDAY1_4TO5Layout);
        SATURDAY1_4TO5Layout.setHorizontalGroup(
            SATURDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_4TO5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY1_4TO5Layout.setVerticalGroup(
            SATURDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_4TO5Layout.createSequentialGroup()
                .addComponent(SATURDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY1_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_4TO5LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_4TO5Layout = new javax.swing.GroupLayout(THURSDAY1_4TO5);
        THURSDAY1_4TO5.setLayout(THURSDAY1_4TO5Layout);
        THURSDAY1_4TO5Layout.setHorizontalGroup(
            THURSDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_4TO5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_4TO5Layout.setVerticalGroup(
            THURSDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_4TO5Layout.createSequentialGroup()
                .addComponent(THURSDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY2_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_4TO5LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_4TO5Layout = new javax.swing.GroupLayout(WEDNESDAY2_4TO5);
        WEDNESDAY2_4TO5.setLayout(WEDNESDAY2_4TO5Layout);
        WEDNESDAY2_4TO5Layout.setHorizontalGroup(
            WEDNESDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_4TO5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_4TO5Layout.setVerticalGroup(
            WEDNESDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_4TO5Layout.createSequentialGroup()
                .addComponent(WEDNESDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY1_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_4TO5LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_4TO5Layout = new javax.swing.GroupLayout(WEDNESDAY1_4TO5);
        WEDNESDAY1_4TO5.setLayout(WEDNESDAY1_4TO5Layout);
        WEDNESDAY1_4TO5Layout.setHorizontalGroup(
            WEDNESDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_4TO5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_4TO5Layout.setVerticalGroup(
            WEDNESDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_4TO5Layout.createSequentialGroup()
                .addComponent(WEDNESDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY2_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_4TO5Layout = new javax.swing.GroupLayout(TUESDAY2_4TO5);
        TUESDAY2_4TO5.setLayout(TUESDAY2_4TO5Layout);
        TUESDAY2_4TO5Layout.setHorizontalGroup(
            TUESDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_4TO5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_4TO5Layout.setVerticalGroup(
            TUESDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_4TO5Layout.createSequentialGroup()
                .addComponent(TUESDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        jPanel138.setBackground(new java.awt.Color(255, 255, 255));
        jPanel138.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel138.setForeground(new java.awt.Color(0, 0, 0));
        jPanel138.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel25.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(0, 0, 0));
        jLabel25.setText("4:00-5:00");

        javax.swing.GroupLayout jPanel138Layout = new javax.swing.GroupLayout(jPanel138);
        jPanel138.setLayout(jPanel138Layout);
        jPanel138Layout.setHorizontalGroup(
            jPanel138Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel138Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel25)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel138Layout.setVerticalGroup(
            jPanel138Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel138Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel25)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        MONDAY2_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_4TO5LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_4TO5Layout = new javax.swing.GroupLayout(MONDAY2_4TO5);
        MONDAY2_4TO5.setLayout(MONDAY2_4TO5Layout);
        MONDAY2_4TO5Layout.setHorizontalGroup(
            MONDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_4TO5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY2_4TO5Layout.setVerticalGroup(
            MONDAY2_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_4TO5Layout.createSequentialGroup()
                .addComponent(MONDAY2_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        FRIDAY1_4TO5.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_4TO5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_4TO5.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_4TO5.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_4TO5LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_4TO5LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_4TO5LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_4TO5LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_4TO5Layout = new javax.swing.GroupLayout(FRIDAY1_4TO5);
        FRIDAY1_4TO5.setLayout(FRIDAY1_4TO5Layout);
        FRIDAY1_4TO5Layout.setHorizontalGroup(
            FRIDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_4TO5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_4TO5Layout.setVerticalGroup(
            FRIDAY1_4TO5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, FRIDAY1_4TO5Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(FRIDAY1_4TO5LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        THURSDAY2_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_5TO6LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_5TO6Layout = new javax.swing.GroupLayout(THURSDAY2_5TO6);
        THURSDAY2_5TO6.setLayout(THURSDAY2_5TO6Layout);
        THURSDAY2_5TO6Layout.setHorizontalGroup(
            THURSDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_5TO6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_5TO6Layout.setVerticalGroup(
            THURSDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_5TO6Layout.createSequentialGroup()
                .addComponent(THURSDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY1_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_5TO6LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_5TO6Layout = new javax.swing.GroupLayout(MONDAY1_5TO6);
        MONDAY1_5TO6.setLayout(MONDAY1_5TO6Layout);
        MONDAY1_5TO6Layout.setHorizontalGroup(
            MONDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY1_5TO6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY1_5TO6Layout.setVerticalGroup(
            MONDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_5TO6Layout.createSequentialGroup()
                .addComponent(MONDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        SATURDAY2_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_5TO6LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_5TO6Layout = new javax.swing.GroupLayout(SATURDAY2_5TO6);
        SATURDAY2_5TO6.setLayout(SATURDAY2_5TO6Layout);
        SATURDAY2_5TO6Layout.setHorizontalGroup(
            SATURDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_5TO6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_5TO6Layout.setVerticalGroup(
            SATURDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_5TO6Layout.createSequentialGroup()
                .addComponent(SATURDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY1_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_5TO6Layout = new javax.swing.GroupLayout(TUESDAY1_5TO6);
        TUESDAY1_5TO6.setLayout(TUESDAY1_5TO6Layout);
        TUESDAY1_5TO6Layout.setHorizontalGroup(
            TUESDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_5TO6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_5TO6Layout.setVerticalGroup(
            TUESDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_5TO6Layout.createSequentialGroup()
                .addComponent(TUESDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY1_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_5TO6LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_5TO6Layout = new javax.swing.GroupLayout(WEDNESDAY1_5TO6);
        WEDNESDAY1_5TO6.setLayout(WEDNESDAY1_5TO6Layout);
        WEDNESDAY1_5TO6Layout.setHorizontalGroup(
            WEDNESDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_5TO6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_5TO6Layout.setVerticalGroup(
            WEDNESDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_5TO6Layout.createSequentialGroup()
                .addComponent(WEDNESDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY1_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_5TO6LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_5TO6Layout = new javax.swing.GroupLayout(FRIDAY1_5TO6);
        FRIDAY1_5TO6.setLayout(FRIDAY1_5TO6Layout);
        FRIDAY1_5TO6Layout.setHorizontalGroup(
            FRIDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_5TO6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_5TO6Layout.setVerticalGroup(
            FRIDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_5TO6Layout.createSequentialGroup()
                .addComponent(FRIDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY2_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_5TO6LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_5TO6Layout = new javax.swing.GroupLayout(WEDNESDAY2_5TO6);
        WEDNESDAY2_5TO6.setLayout(WEDNESDAY2_5TO6Layout);
        WEDNESDAY2_5TO6Layout.setHorizontalGroup(
            WEDNESDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_5TO6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_5TO6Layout.setVerticalGroup(
            WEDNESDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_5TO6Layout.createSequentialGroup()
                .addComponent(WEDNESDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        jPanel148.setBackground(new java.awt.Color(255, 255, 255));
        jPanel148.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel148.setForeground(new java.awt.Color(0, 0, 0));
        jPanel148.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel26.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(0, 0, 0));
        jLabel26.setText("5:00-6:00");

        javax.swing.GroupLayout jPanel148Layout = new javax.swing.GroupLayout(jPanel148);
        jPanel148.setLayout(jPanel148Layout);
        jPanel148Layout.setHorizontalGroup(
            jPanel148Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel148Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel26)
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel148Layout.setVerticalGroup(
            jPanel148Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel148Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel26)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        TUESDAY2_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_5TO6Layout = new javax.swing.GroupLayout(TUESDAY2_5TO6);
        TUESDAY2_5TO6.setLayout(TUESDAY2_5TO6Layout);
        TUESDAY2_5TO6Layout.setHorizontalGroup(
            TUESDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_5TO6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_5TO6Layout.setVerticalGroup(
            TUESDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_5TO6Layout.createSequentialGroup()
                .addComponent(TUESDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY2_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_5TO6LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_5TO6Layout = new javax.swing.GroupLayout(MONDAY2_5TO6);
        MONDAY2_5TO6.setLayout(MONDAY2_5TO6Layout);
        MONDAY2_5TO6Layout.setHorizontalGroup(
            MONDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_5TO6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY2_5TO6Layout.setVerticalGroup(
            MONDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_5TO6Layout.createSequentialGroup()
                .addComponent(MONDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        SATURDAY1_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY1_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_5TO6LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_5TO6Layout = new javax.swing.GroupLayout(SATURDAY1_5TO6);
        SATURDAY1_5TO6.setLayout(SATURDAY1_5TO6Layout);
        SATURDAY1_5TO6Layout.setHorizontalGroup(
            SATURDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_5TO6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY1_5TO6Layout.setVerticalGroup(
            SATURDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SATURDAY1_5TO6Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(SATURDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        FRIDAY2_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_5TO6LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_5TO6Layout = new javax.swing.GroupLayout(FRIDAY2_5TO6);
        FRIDAY2_5TO6.setLayout(FRIDAY2_5TO6Layout);
        FRIDAY2_5TO6Layout.setHorizontalGroup(
            FRIDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_5TO6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY2_5TO6Layout.setVerticalGroup(
            FRIDAY2_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_5TO6Layout.createSequentialGroup()
                .addComponent(FRIDAY2_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY1_5TO6.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_5TO6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_5TO6.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_5TO6.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_5TO6LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_5TO6LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_5TO6LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_5TO6LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_5TO6Layout = new javax.swing.GroupLayout(THURSDAY1_5TO6);
        THURSDAY1_5TO6.setLayout(THURSDAY1_5TO6Layout);
        THURSDAY1_5TO6Layout.setHorizontalGroup(
            THURSDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_5TO6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_5TO6Layout.setVerticalGroup(
            THURSDAY1_5TO6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_5TO6Layout.createSequentialGroup()
                .addComponent(THURSDAY1_5TO6LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        WEDNESDAY1_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY1_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY1_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY1_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY1_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY1_6TO7LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY1_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY1_6TO7Layout = new javax.swing.GroupLayout(WEDNESDAY1_6TO7);
        WEDNESDAY1_6TO7.setLayout(WEDNESDAY1_6TO7Layout);
        WEDNESDAY1_6TO7Layout.setHorizontalGroup(
            WEDNESDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_6TO7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY1_6TO7Layout.setVerticalGroup(
            WEDNESDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY1_6TO7Layout.createSequentialGroup()
                .addComponent(WEDNESDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        THURSDAY2_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY2_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY2_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY2_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY2_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY2_6TO7LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY2_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY2_6TO7Layout = new javax.swing.GroupLayout(THURSDAY2_6TO7);
        THURSDAY2_6TO7.setLayout(THURSDAY2_6TO7Layout);
        THURSDAY2_6TO7Layout.setHorizontalGroup(
            THURSDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY2_6TO7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY2_6TO7Layout.setVerticalGroup(
            THURSDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY2_6TO7Layout.createSequentialGroup()
                .addComponent(THURSDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        jPanel156.setBackground(new java.awt.Color(255, 255, 255));
        jPanel156.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel156.setForeground(new java.awt.Color(0, 0, 0));
        jPanel156.setPreferredSize(new java.awt.Dimension(125, 56));

        jLabel27.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(0, 0, 0));
        jLabel27.setText("6:00-7:00");

        javax.swing.GroupLayout jPanel156Layout = new javax.swing.GroupLayout(jPanel156);
        jPanel156.setLayout(jPanel156Layout);
        jPanel156Layout.setHorizontalGroup(
            jPanel156Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel156Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel27)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel156Layout.setVerticalGroup(
            jPanel156Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel156Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel27)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        SATURDAY1_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY1_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY1_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY1_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY1_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY1_6TO7LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY1_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY1_6TO7Layout = new javax.swing.GroupLayout(SATURDAY1_6TO7);
        SATURDAY1_6TO7.setLayout(SATURDAY1_6TO7Layout);
        SATURDAY1_6TO7Layout.setHorizontalGroup(
            SATURDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_6TO7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY1_6TO7Layout.setVerticalGroup(
            SATURDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY1_6TO7Layout.createSequentialGroup()
                .addComponent(SATURDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY1_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY1_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY1_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY1_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY1_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY1_6TO7LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY1_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY1_6TO7Layout = new javax.swing.GroupLayout(MONDAY1_6TO7);
        MONDAY1_6TO7.setLayout(MONDAY1_6TO7Layout);
        MONDAY1_6TO7Layout.setHorizontalGroup(
            MONDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY1_6TO7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY1_6TO7Layout.setVerticalGroup(
            MONDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY1_6TO7Layout.createSequentialGroup()
                .addComponent(MONDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        FRIDAY2_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY2_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY2_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY2_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY2_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY2_6TO7LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY2_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY2_6TO7Layout = new javax.swing.GroupLayout(FRIDAY2_6TO7);
        FRIDAY2_6TO7.setLayout(FRIDAY2_6TO7Layout);
        FRIDAY2_6TO7Layout.setHorizontalGroup(
            FRIDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_6TO7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY2_6TO7Layout.setVerticalGroup(
            FRIDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY2_6TO7Layout.createSequentialGroup()
                .addComponent(FRIDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        SATURDAY2_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        SATURDAY2_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SATURDAY2_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        SATURDAY2_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SATURDAY2_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        SATURDAY2_6TO7LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SATURDAY2_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout SATURDAY2_6TO7Layout = new javax.swing.GroupLayout(SATURDAY2_6TO7);
        SATURDAY2_6TO7.setLayout(SATURDAY2_6TO7Layout);
        SATURDAY2_6TO7Layout.setHorizontalGroup(
            SATURDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SATURDAY2_6TO7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SATURDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SATURDAY2_6TO7Layout.setVerticalGroup(
            SATURDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SATURDAY2_6TO7Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(SATURDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        WEDNESDAY2_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        WEDNESDAY2_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        WEDNESDAY2_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        WEDNESDAY2_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        WEDNESDAY2_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        WEDNESDAY2_6TO7LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        WEDNESDAY2_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout WEDNESDAY2_6TO7Layout = new javax.swing.GroupLayout(WEDNESDAY2_6TO7);
        WEDNESDAY2_6TO7.setLayout(WEDNESDAY2_6TO7Layout);
        WEDNESDAY2_6TO7Layout.setHorizontalGroup(
            WEDNESDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_6TO7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(WEDNESDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WEDNESDAY2_6TO7Layout.setVerticalGroup(
            WEDNESDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(WEDNESDAY2_6TO7Layout.createSequentialGroup()
                .addComponent(WEDNESDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY1_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY1_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY1_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY1_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY1_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY1_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY1_6TO7Layout = new javax.swing.GroupLayout(TUESDAY1_6TO7);
        TUESDAY1_6TO7.setLayout(TUESDAY1_6TO7Layout);
        TUESDAY1_6TO7Layout.setHorizontalGroup(
            TUESDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY1_6TO7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY1_6TO7Layout.setVerticalGroup(
            TUESDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY1_6TO7Layout.createSequentialGroup()
                .addComponent(TUESDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        TUESDAY2_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        TUESDAY2_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TUESDAY2_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        TUESDAY2_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TUESDAY2_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        TUESDAY2_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout TUESDAY2_6TO7Layout = new javax.swing.GroupLayout(TUESDAY2_6TO7);
        TUESDAY2_6TO7.setLayout(TUESDAY2_6TO7Layout);
        TUESDAY2_6TO7Layout.setHorizontalGroup(
            TUESDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TUESDAY2_6TO7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TUESDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        TUESDAY2_6TO7Layout.setVerticalGroup(
            TUESDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TUESDAY2_6TO7Layout.createSequentialGroup()
                .addComponent(TUESDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        MONDAY2_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        MONDAY2_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MONDAY2_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        MONDAY2_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MONDAY2_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        MONDAY2_6TO7LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MONDAY2_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout MONDAY2_6TO7Layout = new javax.swing.GroupLayout(MONDAY2_6TO7);
        MONDAY2_6TO7.setLayout(MONDAY2_6TO7Layout);
        MONDAY2_6TO7Layout.setHorizontalGroup(
            MONDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MONDAY2_6TO7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MONDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        MONDAY2_6TO7Layout.setVerticalGroup(
            MONDAY2_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MONDAY2_6TO7Layout.createSequentialGroup()
                .addComponent(MONDAY2_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        THURSDAY1_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        THURSDAY1_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        THURSDAY1_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        THURSDAY1_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        THURSDAY1_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        THURSDAY1_6TO7LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        THURSDAY1_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout THURSDAY1_6TO7Layout = new javax.swing.GroupLayout(THURSDAY1_6TO7);
        THURSDAY1_6TO7.setLayout(THURSDAY1_6TO7Layout);
        THURSDAY1_6TO7Layout.setHorizontalGroup(
            THURSDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, THURSDAY1_6TO7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(THURSDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        THURSDAY1_6TO7Layout.setVerticalGroup(
            THURSDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(THURSDAY1_6TO7Layout.createSequentialGroup()
                .addComponent(THURSDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        FRIDAY1_6TO7.setBackground(new java.awt.Color(255, 255, 255));
        FRIDAY1_6TO7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FRIDAY1_6TO7.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_6TO7.setPreferredSize(new java.awt.Dimension(125, 28));

        FRIDAY1_6TO7LABEL.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FRIDAY1_6TO7LABEL.setForeground(new java.awt.Color(0, 0, 0));
        FRIDAY1_6TO7LABEL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FRIDAY1_6TO7LABEL.setPreferredSize(new java.awt.Dimension(111, 25));

        javax.swing.GroupLayout FRIDAY1_6TO7Layout = new javax.swing.GroupLayout(FRIDAY1_6TO7);
        FRIDAY1_6TO7.setLayout(FRIDAY1_6TO7Layout);
        FRIDAY1_6TO7Layout.setHorizontalGroup(
            FRIDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_6TO7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FRIDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        FRIDAY1_6TO7Layout.setVerticalGroup(
            FRIDAY1_6TO7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FRIDAY1_6TO7Layout.createSequentialGroup()
                .addComponent(FRIDAY1_6TO7LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jPanel51, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(125, 125, 125)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(MONDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MONDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MONDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MONDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MONDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MONDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MONDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MONDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MONDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MONDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MONDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(MONDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel62, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel64, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel83, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel98, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel105, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel117, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel138, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel148, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jPanel156, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(MONDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(TUESDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(WEDNESDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(THURSDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(FRIDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(SATURDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel51, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_7TO8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_8TO9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_9TO10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel62, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_10TO11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel64, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_11TO12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel83, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_12TO1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel98, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_1TO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel105, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_2TO3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel117, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_3TO4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel138, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_4TO5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel148, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_5TO6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, 0)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel156, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(MONDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(MONDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY1_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TUESDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(WEDNESDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(THURSDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRIDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SATURDAY2_6TO7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 190, 880, 740));

        curvedPanel2.setBackground(new java.awt.Color(0, 102, 204));
        curvedPanel2.setRoundBottomLeft(15);
        curvedPanel2.setRoundBottomRight(15);
        curvedPanel2.setRoundTopLeft(15);
        curvedPanel2.setRoundTopRight(15);

        jLabel36.setFont(new java.awt.Font("Bauhaus 93", 1, 24)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 0));
        jLabel36.setText("Current Time:");

        LiveTime.setBackground(new java.awt.Color(0, 102, 204));
        LiveTime.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 52)); // NOI18N
        LiveTime.setForeground(new java.awt.Color(255, 255, 255));
        LiveTime.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LiveTime.setText("00:00AM");

        LiveDate.setBackground(new java.awt.Color(0, 102, 204));
        LiveDate.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 30)); // NOI18N
        LiveDate.setForeground(new java.awt.Color(255, 255, 255));
        LiveDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LiveDate.setText("00/00/00");

        javax.swing.GroupLayout curvedPanel2Layout = new javax.swing.GroupLayout(curvedPanel2);
        curvedPanel2.setLayout(curvedPanel2Layout);
        curvedPanel2Layout.setHorizontalGroup(
            curvedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(curvedPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(curvedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(curvedPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(LiveTime, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(curvedPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel36)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(LiveDate, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        curvedPanel2Layout.setVerticalGroup(
            curvedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(curvedPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(curvedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel36)
                    .addComponent(LiveDate, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LiveTime)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(curvedPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 390, 110));

        KeyGetter.setBackground(new java.awt.Color(255, 255, 255));
        KeyGetter.setForeground(new java.awt.Color(255, 255, 255));
        KeyGetter.setBorder(null);
        KeyGetter.setCaretColor(new java.awt.Color(255, 255, 255));
        KeyGetter.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        KeyGetter.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        KeyGetter.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        KeyGetter.setSelectionColor(new java.awt.Color(255, 255, 255));
        KeyGetter.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                KeyGetterKeyPressed(evt);
            }
        });
        jPanel2.add(KeyGetter, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 10, 140, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 1670, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setBounds(0, 0, 1670, 960);
    }// </editor-fold>//GEN-END:initComponents



    private void KeyGetterKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_KeyGetterKeyPressed
      if(evt.getKeyCode()== KeyEvent.VK_ENTER){
            StudentInfo();
        }
    }//GEN-LAST:event_KeyGetterKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel FRIDAY1_10TO11;
    private javax.swing.JLabel FRIDAY1_10TO11LABEL;
    private javax.swing.JPanel FRIDAY1_11TO12;
    private javax.swing.JLabel FRIDAY1_11TO12LABEL;
    private javax.swing.JPanel FRIDAY1_12TO1;
    private javax.swing.JLabel FRIDAY1_12TO1LABEL;
    private javax.swing.JPanel FRIDAY1_1TO2;
    private javax.swing.JLabel FRIDAY1_1TO2LABEL;
    private javax.swing.JPanel FRIDAY1_2TO3;
    private javax.swing.JLabel FRIDAY1_2TO3LABEL;
    private javax.swing.JPanel FRIDAY1_3TO4;
    private javax.swing.JLabel FRIDAY1_3TO4LABEL;
    private javax.swing.JPanel FRIDAY1_4TO5;
    private javax.swing.JLabel FRIDAY1_4TO5LABEL;
    private javax.swing.JPanel FRIDAY1_5TO6;
    private javax.swing.JLabel FRIDAY1_5TO6LABEL;
    private javax.swing.JPanel FRIDAY1_6TO7;
    private javax.swing.JLabel FRIDAY1_6TO7LABEL;
    private javax.swing.JPanel FRIDAY1_7TO8;
    private javax.swing.JLabel FRIDAY1_7TO8LABEL;
    private javax.swing.JPanel FRIDAY1_8TO9;
    private javax.swing.JLabel FRIDAY1_8TO9LABEL;
    private javax.swing.JPanel FRIDAY1_9TO10;
    private javax.swing.JLabel FRIDAY1_9TO10LABEL;
    private javax.swing.JPanel FRIDAY2_10TO11;
    private javax.swing.JLabel FRIDAY2_10TO11LABEL;
    private javax.swing.JPanel FRIDAY2_11TO12;
    private javax.swing.JLabel FRIDAY2_11TO12LABEL;
    private javax.swing.JPanel FRIDAY2_12TO1;
    private javax.swing.JLabel FRIDAY2_12TO1LABEL;
    private javax.swing.JPanel FRIDAY2_1TO2;
    private javax.swing.JLabel FRIDAY2_1TO2LABEL;
    private javax.swing.JPanel FRIDAY2_2TO3;
    private javax.swing.JLabel FRIDAY2_2TO3LABEL;
    private javax.swing.JPanel FRIDAY2_3TO4;
    private javax.swing.JLabel FRIDAY2_3TO4LABEL;
    private javax.swing.JPanel FRIDAY2_4TO5;
    private javax.swing.JLabel FRIDAY2_4TO5LABEL;
    private javax.swing.JPanel FRIDAY2_5TO6;
    private javax.swing.JLabel FRIDAY2_5TO6LABEL;
    private javax.swing.JPanel FRIDAY2_6TO7;
    private javax.swing.JLabel FRIDAY2_6TO7LABEL;
    private javax.swing.JPanel FRIDAY2_7TO8;
    private javax.swing.JLabel FRIDAY2_7TO8LABEL;
    private javax.swing.JPanel FRIDAY2_8TO9;
    private javax.swing.JLabel FRIDAY2_8TO9LABEL;
    private javax.swing.JPanel FRIDAY2_9TO10;
    private javax.swing.JLabel FRIDAY2_9TO10LABEL;
    private javax.swing.JLabel FirstNameInputLabel;
    private javax.swing.JLabel GenderInputLabel;
    private javax.swing.JLabel ImageProfile;
    private javax.swing.JTextField KeyGetter;
    private javax.swing.JLabel LastNameInputLabel;
    private javax.swing.JLabel LiveDate;
    private javax.swing.JLabel LiveTime;
    private CustomElements.CurvedPanel LoginButton2;
    private CustomElements.CurvedPanel LoginButton3;
    private javax.swing.JPanel MONDAY1_10TO11;
    private javax.swing.JLabel MONDAY1_10TO11LABEL;
    private javax.swing.JPanel MONDAY1_11TO12;
    private javax.swing.JLabel MONDAY1_11TO12LABEL;
    private javax.swing.JPanel MONDAY1_12TO1;
    private javax.swing.JLabel MONDAY1_12TO1LABEL;
    private javax.swing.JPanel MONDAY1_1TO2;
    private javax.swing.JLabel MONDAY1_1TO2LABEL;
    private javax.swing.JPanel MONDAY1_2TO3;
    private javax.swing.JLabel MONDAY1_2TO3LABEL;
    private javax.swing.JPanel MONDAY1_3TO4;
    private javax.swing.JLabel MONDAY1_3TO4LABEL;
    private javax.swing.JPanel MONDAY1_4TO5;
    private javax.swing.JLabel MONDAY1_4TO5LABEL;
    private javax.swing.JPanel MONDAY1_5TO6;
    private javax.swing.JLabel MONDAY1_5TO6LABEL;
    private javax.swing.JPanel MONDAY1_6TO7;
    private javax.swing.JLabel MONDAY1_6TO7LABEL;
    private javax.swing.JPanel MONDAY1_7TO8;
    private javax.swing.JLabel MONDAY1_7TO8LABEL;
    private javax.swing.JPanel MONDAY1_8TO9;
    private javax.swing.JLabel MONDAY1_8TO9LABEL;
    private javax.swing.JPanel MONDAY1_9TO10;
    private javax.swing.JLabel MONDAY1_9TO10LABEL;
    private javax.swing.JPanel MONDAY2_10TO11;
    private javax.swing.JLabel MONDAY2_10TO11LABEL;
    private javax.swing.JPanel MONDAY2_11TO12;
    private javax.swing.JLabel MONDAY2_11TO12LABEL;
    private javax.swing.JPanel MONDAY2_12TO1;
    private javax.swing.JLabel MONDAY2_12TO1LABEL;
    private javax.swing.JPanel MONDAY2_1TO2;
    private javax.swing.JLabel MONDAY2_1TO2LABEL;
    private javax.swing.JPanel MONDAY2_2TO3;
    private javax.swing.JLabel MONDAY2_2TO3LABEL;
    private javax.swing.JPanel MONDAY2_3TO4;
    private javax.swing.JLabel MONDAY2_3TO4LABEL;
    private javax.swing.JPanel MONDAY2_4TO5;
    private javax.swing.JLabel MONDAY2_4TO5LABEL;
    private javax.swing.JPanel MONDAY2_5TO6;
    private javax.swing.JLabel MONDAY2_5TO6LABEL;
    private javax.swing.JPanel MONDAY2_6TO7;
    private javax.swing.JLabel MONDAY2_6TO7LABEL;
    private javax.swing.JPanel MONDAY2_7TO8;
    private javax.swing.JLabel MONDAY2_7TO8LABEL;
    private javax.swing.JPanel MONDAY2_8TO9;
    private javax.swing.JLabel MONDAY2_8TO9LABEL;
    private javax.swing.JPanel MONDAY2_9TO10;
    private javax.swing.JLabel MONDAY2_9TO10LABEL;
    private javax.swing.JPanel SATURDAY1_10TO11;
    private javax.swing.JLabel SATURDAY1_10TO11LABEL;
    private javax.swing.JPanel SATURDAY1_11TO12;
    private javax.swing.JLabel SATURDAY1_11TO12LABEL;
    private javax.swing.JPanel SATURDAY1_12TO1;
    private javax.swing.JLabel SATURDAY1_12TO1LABEL;
    private javax.swing.JPanel SATURDAY1_1TO2;
    private javax.swing.JLabel SATURDAY1_1TO2LABEL;
    private javax.swing.JPanel SATURDAY1_2TO3;
    private javax.swing.JLabel SATURDAY1_2TO3LABEL;
    private javax.swing.JPanel SATURDAY1_3TO4;
    private javax.swing.JLabel SATURDAY1_3TO4LABEL;
    private javax.swing.JPanel SATURDAY1_4TO5;
    private javax.swing.JLabel SATURDAY1_4TO5LABEL;
    private javax.swing.JPanel SATURDAY1_5TO6;
    private javax.swing.JLabel SATURDAY1_5TO6LABEL;
    private javax.swing.JPanel SATURDAY1_6TO7;
    private javax.swing.JLabel SATURDAY1_6TO7LABEL;
    private javax.swing.JPanel SATURDAY1_7TO8;
    private javax.swing.JLabel SATURDAY1_7TO8LABEL;
    private javax.swing.JPanel SATURDAY1_8TO9;
    private javax.swing.JLabel SATURDAY1_8TO9LABEL;
    private javax.swing.JPanel SATURDAY1_9TO10;
    private javax.swing.JLabel SATURDAY1_9TO10LABEL;
    private javax.swing.JPanel SATURDAY2_10TO11;
    private javax.swing.JLabel SATURDAY2_10TO11LABEL;
    private javax.swing.JPanel SATURDAY2_11TO12;
    private javax.swing.JLabel SATURDAY2_11TO12LABEL;
    private javax.swing.JPanel SATURDAY2_12TO1;
    private javax.swing.JLabel SATURDAY2_12TO1LABEL;
    private javax.swing.JPanel SATURDAY2_1TO2;
    private javax.swing.JLabel SATURDAY2_1TO2LABEL;
    private javax.swing.JPanel SATURDAY2_2TO3;
    private javax.swing.JLabel SATURDAY2_2TO3LABEL;
    private javax.swing.JPanel SATURDAY2_3TO4;
    private javax.swing.JLabel SATURDAY2_3TO4LABEL;
    private javax.swing.JPanel SATURDAY2_4TO5;
    private javax.swing.JLabel SATURDAY2_4TO5LABEL;
    private javax.swing.JPanel SATURDAY2_5TO6;
    private javax.swing.JLabel SATURDAY2_5TO6LABEL;
    private javax.swing.JPanel SATURDAY2_6TO7;
    private javax.swing.JLabel SATURDAY2_6TO7LABEL;
    private javax.swing.JPanel SATURDAY2_7TO8;
    private javax.swing.JLabel SATURDAY2_7TO8LABEL;
    private javax.swing.JPanel SATURDAY2_8TO9;
    private javax.swing.JLabel SATURDAY2_8TO9LABEL;
    private javax.swing.JPanel SATURDAY2_9TO10;
    private javax.swing.JLabel SATURDAY2_9TO10LABEL;
    private javax.swing.JPanel THURSDAY1_10TO11;
    private javax.swing.JLabel THURSDAY1_10TO11LABEL;
    private javax.swing.JPanel THURSDAY1_11TO12;
    private javax.swing.JLabel THURSDAY1_11TO12LABEL;
    private javax.swing.JPanel THURSDAY1_12TO1;
    private javax.swing.JLabel THURSDAY1_12TO1LABEL;
    private javax.swing.JPanel THURSDAY1_1TO2;
    private javax.swing.JLabel THURSDAY1_1TO2LABEL;
    private javax.swing.JPanel THURSDAY1_2TO3;
    private javax.swing.JLabel THURSDAY1_2TO3LABEL;
    private javax.swing.JPanel THURSDAY1_3TO4;
    private javax.swing.JLabel THURSDAY1_3TO4LABEL;
    private javax.swing.JPanel THURSDAY1_4TO5;
    private javax.swing.JLabel THURSDAY1_4TO5LABEL;
    private javax.swing.JPanel THURSDAY1_5TO6;
    private javax.swing.JLabel THURSDAY1_5TO6LABEL;
    private javax.swing.JPanel THURSDAY1_6TO7;
    private javax.swing.JLabel THURSDAY1_6TO7LABEL;
    private javax.swing.JPanel THURSDAY1_7TO8;
    private javax.swing.JLabel THURSDAY1_7TO8LABEL;
    private javax.swing.JPanel THURSDAY1_8TO9;
    private javax.swing.JLabel THURSDAY1_8TO9LABEL;
    private javax.swing.JPanel THURSDAY1_9TO10;
    private javax.swing.JLabel THURSDAY1_9TO10LABEL;
    private javax.swing.JPanel THURSDAY2_10TO11;
    private javax.swing.JLabel THURSDAY2_10TO11LABEL;
    private javax.swing.JPanel THURSDAY2_11TO12;
    private javax.swing.JLabel THURSDAY2_11TO12LABEL;
    private javax.swing.JPanel THURSDAY2_12TO1;
    private javax.swing.JLabel THURSDAY2_12TO1LABEL;
    private javax.swing.JPanel THURSDAY2_1TO2;
    private javax.swing.JLabel THURSDAY2_1TO2LABEL;
    private javax.swing.JPanel THURSDAY2_2TO3;
    private javax.swing.JLabel THURSDAY2_2TO3LABEL;
    private javax.swing.JPanel THURSDAY2_3TO4;
    private javax.swing.JLabel THURSDAY2_3TO4LABEL;
    private javax.swing.JPanel THURSDAY2_4TO5;
    private javax.swing.JLabel THURSDAY2_4TO5LABEL;
    private javax.swing.JPanel THURSDAY2_5TO6;
    private javax.swing.JLabel THURSDAY2_5TO6LABEL;
    private javax.swing.JPanel THURSDAY2_6TO7;
    private javax.swing.JLabel THURSDAY2_6TO7LABEL;
    private javax.swing.JPanel THURSDAY2_7TO8;
    private javax.swing.JLabel THURSDAY2_7TO8LABEL;
    private javax.swing.JPanel THURSDAY2_8TO9;
    private javax.swing.JLabel THURSDAY2_8TO9LABEL;
    private javax.swing.JPanel THURSDAY2_9TO10;
    private javax.swing.JLabel THURSDAY2_9TO10LABEL;
    private javax.swing.JPanel TUESDAY1_10TO11;
    private javax.swing.JLabel TUESDAY1_10TO11LABEL;
    private javax.swing.JPanel TUESDAY1_11TO12;
    private javax.swing.JLabel TUESDAY1_11TO12LABEL;
    private javax.swing.JPanel TUESDAY1_12TO1;
    private javax.swing.JLabel TUESDAY1_12TO1LABEL;
    private javax.swing.JPanel TUESDAY1_1TO2;
    private javax.swing.JLabel TUESDAY1_1TO2LABEL;
    private javax.swing.JPanel TUESDAY1_2TO3;
    private javax.swing.JLabel TUESDAY1_2TO3LABEL;
    private javax.swing.JPanel TUESDAY1_3TO4;
    private javax.swing.JLabel TUESDAY1_3TO4LABEL;
    private javax.swing.JPanel TUESDAY1_4TO5;
    private javax.swing.JLabel TUESDAY1_4TO5LABEL;
    private javax.swing.JPanel TUESDAY1_5TO6;
    private javax.swing.JLabel TUESDAY1_5TO6LABEL;
    private javax.swing.JPanel TUESDAY1_6TO7;
    private javax.swing.JLabel TUESDAY1_6TO7LABEL;
    private javax.swing.JPanel TUESDAY1_7TO8;
    private javax.swing.JLabel TUESDAY1_7TO8LABEL;
    private javax.swing.JPanel TUESDAY1_8TO9;
    private javax.swing.JLabel TUESDAY1_8TO9LABEL;
    private javax.swing.JPanel TUESDAY1_9TO10;
    private javax.swing.JLabel TUESDAY1_9TO10LABEL;
    private javax.swing.JPanel TUESDAY2_10TO11;
    private javax.swing.JLabel TUESDAY2_10TO11LABEL;
    private javax.swing.JPanel TUESDAY2_11TO12;
    private javax.swing.JLabel TUESDAY2_11TO12LABEL;
    private javax.swing.JPanel TUESDAY2_12TO1;
    private javax.swing.JLabel TUESDAY2_12TO1LABEL;
    private javax.swing.JPanel TUESDAY2_1TO2;
    private javax.swing.JLabel TUESDAY2_1TO2LABEL;
    private javax.swing.JPanel TUESDAY2_2TO3;
    private javax.swing.JLabel TUESDAY2_2TO3LABEL;
    private javax.swing.JPanel TUESDAY2_3TO4;
    private javax.swing.JLabel TUESDAY2_3TO4LABEL;
    private javax.swing.JPanel TUESDAY2_4TO5;
    private javax.swing.JLabel TUESDAY2_4TO5LABEL;
    private javax.swing.JPanel TUESDAY2_5TO6;
    private javax.swing.JLabel TUESDAY2_5TO6LABEL;
    private javax.swing.JPanel TUESDAY2_6TO7;
    private javax.swing.JLabel TUESDAY2_6TO7LABEL;
    private javax.swing.JPanel TUESDAY2_7TO8;
    private javax.swing.JLabel TUESDAY2_7TO8LABEL;
    private javax.swing.JPanel TUESDAY2_8TO9;
    private javax.swing.JLabel TUESDAY2_8TO9LABEL;
    private javax.swing.JPanel TUESDAY2_9TO10;
    private javax.swing.JLabel TUESDAY2_9TO10LABEL;
    private javax.swing.JPanel WEDNESDAY1_10TO11;
    private javax.swing.JLabel WEDNESDAY1_10TO11LABEL;
    private javax.swing.JPanel WEDNESDAY1_11TO12;
    private javax.swing.JLabel WEDNESDAY1_11TO12LABEL;
    private javax.swing.JPanel WEDNESDAY1_12TO1;
    private javax.swing.JLabel WEDNESDAY1_12TO1LABEL;
    private javax.swing.JPanel WEDNESDAY1_1TO2;
    private javax.swing.JLabel WEDNESDAY1_1TO2LABEL;
    private javax.swing.JPanel WEDNESDAY1_2TO3;
    private javax.swing.JLabel WEDNESDAY1_2TO3LABEL;
    private javax.swing.JPanel WEDNESDAY1_3TO4;
    private javax.swing.JLabel WEDNESDAY1_3TO4LABEL;
    private javax.swing.JPanel WEDNESDAY1_4TO5;
    private javax.swing.JLabel WEDNESDAY1_4TO5LABEL;
    private javax.swing.JPanel WEDNESDAY1_5TO6;
    private javax.swing.JLabel WEDNESDAY1_5TO6LABEL;
    private javax.swing.JPanel WEDNESDAY1_6TO7;
    private javax.swing.JLabel WEDNESDAY1_6TO7LABEL;
    private javax.swing.JPanel WEDNESDAY1_7TO8;
    private javax.swing.JLabel WEDNESDAY1_7TO8LABEL;
    private javax.swing.JPanel WEDNESDAY1_8TO9;
    private javax.swing.JLabel WEDNESDAY1_8TO9LABEL;
    private javax.swing.JPanel WEDNESDAY1_9TO10;
    private javax.swing.JLabel WEDNESDAY1_9TO10LABEL;
    private javax.swing.JPanel WEDNESDAY2_10TO11;
    private javax.swing.JLabel WEDNESDAY2_10TO11LABEL;
    private javax.swing.JPanel WEDNESDAY2_11TO12;
    private javax.swing.JLabel WEDNESDAY2_11TO12LABEL;
    private javax.swing.JPanel WEDNESDAY2_12TO1;
    private javax.swing.JLabel WEDNESDAY2_12TO1LABEL;
    private javax.swing.JPanel WEDNESDAY2_1TO2;
    private javax.swing.JLabel WEDNESDAY2_1TO2LABEL;
    private javax.swing.JPanel WEDNESDAY2_2TO3;
    private javax.swing.JLabel WEDNESDAY2_2TO3LABEL;
    private javax.swing.JPanel WEDNESDAY2_3TO4;
    private javax.swing.JLabel WEDNESDAY2_3TO4LABEL;
    private javax.swing.JPanel WEDNESDAY2_4TO5;
    private javax.swing.JLabel WEDNESDAY2_4TO5LABEL;
    private javax.swing.JPanel WEDNESDAY2_5TO6;
    private javax.swing.JLabel WEDNESDAY2_5TO6LABEL;
    private javax.swing.JPanel WEDNESDAY2_6TO7;
    private javax.swing.JLabel WEDNESDAY2_6TO7LABEL;
    private javax.swing.JPanel WEDNESDAY2_7TO8;
    private javax.swing.JLabel WEDNESDAY2_7TO8LABEL;
    private javax.swing.JPanel WEDNESDAY2_8TO9;
    private javax.swing.JLabel WEDNESDAY2_8TO9LABEL;
    private javax.swing.JPanel WEDNESDAY2_9TO10;
    private javax.swing.JLabel WEDNESDAY2_9TO10LABEL;
    private CustomElements.CurvedPanel curvedPanel1;
    private CustomElements.CurvedPanel curvedPanel2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel105;
    private javax.swing.JPanel jPanel117;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel138;
    private javax.swing.JPanel jPanel148;
    private javax.swing.JPanel jPanel156;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel83;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanel98;
    // End of variables declaration//GEN-END:variables
       public void ClearMondaySched(){
        MONDAY1_7TO8LABEL.setText("");
        MONDAY2_7TO8LABEL.setText("");
        MONDAY1_8TO9LABEL.setText("");
        MONDAY2_8TO9LABEL.setText("");
        MONDAY1_9TO10LABEL.setText("");
        MONDAY2_9TO10LABEL.setText("");
        MONDAY1_10TO11LABEL.setText("");
        MONDAY2_10TO11LABEL.setText("");
        MONDAY1_11TO12LABEL.setText("");
        MONDAY2_11TO12LABEL.setText("");
        MONDAY1_12TO1LABEL.setText("");
        MONDAY2_12TO1LABEL.setText("");
        MONDAY1_1TO2LABEL.setText("");
        MONDAY2_1TO2LABEL.setText("");
        MONDAY1_2TO3LABEL.setText("");
        MONDAY2_2TO3LABEL.setText("");
        MONDAY1_3TO4LABEL.setText("");
        MONDAY2_3TO4LABEL.setText("");
        MONDAY1_4TO5LABEL.setText("");
        MONDAY2_4TO5LABEL.setText("");
        MONDAY1_5TO6LABEL.setText("");
        MONDAY2_5TO6LABEL.setText("");
        MONDAY1_6TO7LABEL.setText("");
        MONDAY2_6TO7LABEL.setText("");
        
        MONDAY1_7TO8.setBackground(white);
        MONDAY2_7TO8.setBackground(white);
        MONDAY1_8TO9.setBackground(white);
        MONDAY2_8TO9.setBackground(white);
        MONDAY1_9TO10.setBackground(white);
        MONDAY2_9TO10.setBackground(white);
        MONDAY1_10TO11.setBackground(white);
        MONDAY2_10TO11.setBackground(white);
        MONDAY1_11TO12.setBackground(white);
        MONDAY2_11TO12.setBackground(white);
        MONDAY1_12TO1.setBackground(white);
        MONDAY2_12TO1.setBackground(white);
        MONDAY1_1TO2.setBackground(white);
        MONDAY2_1TO2.setBackground(white);
        MONDAY1_2TO3.setBackground(white);
        MONDAY2_2TO3.setBackground(white);
        MONDAY1_3TO4.setBackground(white);
        MONDAY2_3TO4.setBackground(white);
        MONDAY1_4TO5.setBackground(white);
        MONDAY2_4TO5.setBackground(white);
        MONDAY1_5TO6.setBackground(white);
        MONDAY2_5TO6.setBackground(white);
        MONDAY1_6TO7.setBackground(white);
        MONDAY2_6TO7.setBackground(white);
    }
    public void ClearTuesdaySched(){
        TUESDAY1_7TO8LABEL.setText("");
        TUESDAY2_7TO8LABEL.setText("");
        TUESDAY1_8TO9LABEL.setText("");
        TUESDAY2_8TO9LABEL.setText("");
        TUESDAY1_9TO10LABEL.setText("");
        TUESDAY2_9TO10LABEL.setText("");
        TUESDAY1_10TO11LABEL.setText("");
        TUESDAY2_10TO11LABEL.setText("");
        TUESDAY1_11TO12LABEL.setText("");
        TUESDAY2_11TO12LABEL.setText("");
        TUESDAY1_12TO1LABEL.setText("");
        TUESDAY2_12TO1LABEL.setText("");
        TUESDAY1_1TO2LABEL.setText("");
        TUESDAY2_1TO2LABEL.setText("");
        TUESDAY1_2TO3LABEL.setText("");
        TUESDAY2_2TO3LABEL.setText("");
        TUESDAY1_3TO4LABEL.setText("");
        TUESDAY2_3TO4LABEL.setText("");
        TUESDAY1_4TO5LABEL.setText("");
        TUESDAY2_4TO5LABEL.setText("");
        TUESDAY1_5TO6LABEL.setText("");
        TUESDAY2_5TO6LABEL.setText("");
        TUESDAY1_6TO7LABEL.setText("");
        TUESDAY2_6TO7LABEL.setText("");
        
        TUESDAY1_7TO8.setBackground(white);
        TUESDAY2_7TO8.setBackground(white);
        TUESDAY1_8TO9.setBackground(white);
        TUESDAY2_8TO9.setBackground(white);
        TUESDAY1_9TO10.setBackground(white);
        TUESDAY2_9TO10.setBackground(white);
        TUESDAY1_10TO11.setBackground(white);
        TUESDAY2_10TO11.setBackground(white);
        TUESDAY1_11TO12.setBackground(white);
        TUESDAY2_11TO12.setBackground(white);
        TUESDAY1_12TO1.setBackground(white);
        TUESDAY2_12TO1.setBackground(white);
        TUESDAY1_1TO2.setBackground(white);
        TUESDAY2_1TO2.setBackground(white);
        TUESDAY1_2TO3.setBackground(white);
        TUESDAY2_2TO3.setBackground(white);
        TUESDAY1_3TO4.setBackground(white);
        TUESDAY2_3TO4.setBackground(white);
        TUESDAY1_4TO5.setBackground(white);
        TUESDAY2_4TO5.setBackground(white);
        TUESDAY1_5TO6.setBackground(white);
        TUESDAY2_5TO6.setBackground(white);
        TUESDAY1_6TO7.setBackground(white);
        TUESDAY2_6TO7.setBackground(white);
    }
    public void ClearWednesdaySched(){
        WEDNESDAY1_7TO8LABEL.setText("");
        WEDNESDAY2_7TO8LABEL.setText("");
        WEDNESDAY1_8TO9LABEL.setText("");
        WEDNESDAY2_8TO9LABEL.setText("");
        WEDNESDAY1_9TO10LABEL.setText("");
        WEDNESDAY2_9TO10LABEL.setText("");
        WEDNESDAY1_10TO11LABEL.setText("");
        WEDNESDAY2_10TO11LABEL.setText("");
        WEDNESDAY1_11TO12LABEL.setText("");
        WEDNESDAY2_11TO12LABEL.setText("");
        WEDNESDAY1_12TO1LABEL.setText("");
        WEDNESDAY2_12TO1LABEL.setText("");
        WEDNESDAY1_1TO2LABEL.setText("");
        WEDNESDAY2_1TO2LABEL.setText("");
        WEDNESDAY1_2TO3LABEL.setText("");
        WEDNESDAY2_2TO3LABEL.setText("");
        WEDNESDAY1_3TO4LABEL.setText("");
        WEDNESDAY2_3TO4LABEL.setText("");
        WEDNESDAY1_4TO5LABEL.setText("");
        WEDNESDAY2_4TO5LABEL.setText("");
        WEDNESDAY1_5TO6LABEL.setText("");
        WEDNESDAY2_5TO6LABEL.setText("");
        WEDNESDAY1_6TO7LABEL.setText("");
        WEDNESDAY2_6TO7LABEL.setText("");
        
        WEDNESDAY1_7TO8.setBackground(white);
        WEDNESDAY2_7TO8.setBackground(white);
        WEDNESDAY1_8TO9.setBackground(white);
        WEDNESDAY2_8TO9.setBackground(white);
        WEDNESDAY1_9TO10.setBackground(white);
        WEDNESDAY2_9TO10.setBackground(white);
        WEDNESDAY1_10TO11.setBackground(white);
        WEDNESDAY2_10TO11.setBackground(white);
        WEDNESDAY1_11TO12.setBackground(white);
        WEDNESDAY2_11TO12.setBackground(white);
        WEDNESDAY1_12TO1.setBackground(white);
        WEDNESDAY2_12TO1.setBackground(white);
        WEDNESDAY1_1TO2.setBackground(white);
        WEDNESDAY2_1TO2.setBackground(white);
        WEDNESDAY1_2TO3.setBackground(white);
        WEDNESDAY2_2TO3.setBackground(white);
        WEDNESDAY1_3TO4.setBackground(white);
        WEDNESDAY2_3TO4.setBackground(white);
        WEDNESDAY1_4TO5.setBackground(white);
        WEDNESDAY2_4TO5.setBackground(white);
        WEDNESDAY1_5TO6.setBackground(white);
        WEDNESDAY2_5TO6.setBackground(white);
        WEDNESDAY1_6TO7.setBackground(white);
        WEDNESDAY2_6TO7.setBackground(white);
    }
    public void ClearThursdaySched(){
        THURSDAY1_7TO8LABEL.setText("");
        THURSDAY2_7TO8LABEL.setText("");
        THURSDAY1_8TO9LABEL.setText("");
        THURSDAY2_8TO9LABEL.setText("");
        THURSDAY1_9TO10LABEL.setText("");
        THURSDAY2_9TO10LABEL.setText("");
        THURSDAY1_10TO11LABEL.setText("");
        THURSDAY2_10TO11LABEL.setText("");
        THURSDAY1_11TO12LABEL.setText("");
        THURSDAY2_11TO12LABEL.setText("");
        THURSDAY1_12TO1LABEL.setText("");
        THURSDAY2_12TO1LABEL.setText("");
        THURSDAY1_1TO2LABEL.setText("");
        THURSDAY2_1TO2LABEL.setText("");
        THURSDAY1_2TO3LABEL.setText("");
        THURSDAY2_2TO3LABEL.setText("");
        THURSDAY1_3TO4LABEL.setText("");
        THURSDAY2_3TO4LABEL.setText("");
        THURSDAY1_4TO5LABEL.setText("");
        THURSDAY2_4TO5LABEL.setText("");
        THURSDAY1_5TO6LABEL.setText("");
        THURSDAY2_5TO6LABEL.setText("");
        THURSDAY1_6TO7LABEL.setText("");
        THURSDAY2_6TO7LABEL.setText("");
        
        THURSDAY1_7TO8.setBackground(white);
        THURSDAY2_7TO8.setBackground(white);
        THURSDAY1_8TO9.setBackground(white);
        THURSDAY2_8TO9.setBackground(white);
        THURSDAY1_9TO10.setBackground(white);
        THURSDAY2_9TO10.setBackground(white);
        THURSDAY1_10TO11.setBackground(white);
        THURSDAY2_10TO11.setBackground(white);
        THURSDAY1_11TO12.setBackground(white);
        THURSDAY2_11TO12.setBackground(white);
        THURSDAY1_12TO1.setBackground(white);
        THURSDAY2_12TO1.setBackground(white);
        THURSDAY1_1TO2.setBackground(white);
        THURSDAY2_1TO2.setBackground(white);
        THURSDAY1_2TO3.setBackground(white);
        THURSDAY2_2TO3.setBackground(white);
        THURSDAY1_3TO4.setBackground(white);
        THURSDAY2_3TO4.setBackground(white);
        THURSDAY1_4TO5.setBackground(white);
        THURSDAY2_4TO5.setBackground(white);
        THURSDAY1_5TO6.setBackground(white);
        THURSDAY2_5TO6.setBackground(white);
        THURSDAY1_6TO7.setBackground(white);
        THURSDAY2_6TO7.setBackground(white);
    }
    public void ClearFridaySched(){
        FRIDAY1_7TO8LABEL.setText("");
        FRIDAY2_7TO8LABEL.setText("");
        FRIDAY1_8TO9LABEL.setText("");
        FRIDAY2_8TO9LABEL.setText("");
        FRIDAY1_9TO10LABEL.setText("");
        FRIDAY2_9TO10LABEL.setText("");
        FRIDAY1_10TO11LABEL.setText("");
        FRIDAY2_10TO11LABEL.setText("");
        FRIDAY1_11TO12LABEL.setText("");
        FRIDAY2_11TO12LABEL.setText("");
        FRIDAY1_12TO1LABEL.setText("");
        FRIDAY2_12TO1LABEL.setText("");
        FRIDAY1_1TO2LABEL.setText("");
        FRIDAY2_1TO2LABEL.setText("");
        FRIDAY1_2TO3LABEL.setText("");
        FRIDAY2_2TO3LABEL.setText("");
        FRIDAY1_3TO4LABEL.setText("");
        FRIDAY2_3TO4LABEL.setText("");
        FRIDAY1_4TO5LABEL.setText("");
        FRIDAY2_4TO5LABEL.setText("");
        FRIDAY1_5TO6LABEL.setText("");
        FRIDAY2_5TO6LABEL.setText("");
        FRIDAY1_6TO7LABEL.setText("");
        FRIDAY2_6TO7LABEL.setText("");
        
        FRIDAY1_7TO8.setBackground(white);
        FRIDAY2_7TO8.setBackground(white);
        FRIDAY1_8TO9.setBackground(white);
        FRIDAY2_8TO9.setBackground(white);
        FRIDAY1_9TO10.setBackground(white);
        FRIDAY2_9TO10.setBackground(white);
        FRIDAY1_10TO11.setBackground(white);
        FRIDAY2_10TO11.setBackground(white);
        FRIDAY1_11TO12.setBackground(white);
        FRIDAY2_11TO12.setBackground(white);
        FRIDAY1_12TO1.setBackground(white);
        FRIDAY2_12TO1.setBackground(white);
        FRIDAY1_1TO2.setBackground(white);
        FRIDAY2_1TO2.setBackground(white);
        FRIDAY1_2TO3.setBackground(white);
        FRIDAY2_2TO3.setBackground(white);
        FRIDAY1_3TO4.setBackground(white);
        FRIDAY2_3TO4.setBackground(white);
        FRIDAY1_4TO5.setBackground(white);
        FRIDAY2_4TO5.setBackground(white);
        FRIDAY1_5TO6.setBackground(white);
        FRIDAY2_5TO6.setBackground(white);
        FRIDAY1_6TO7.setBackground(white);
        FRIDAY2_6TO7.setBackground(white);
    }
    public void ClearSaturdaySched(){
        SATURDAY1_7TO8LABEL.setText("");
        SATURDAY2_7TO8LABEL.setText("");
        SATURDAY1_8TO9LABEL.setText("");
        SATURDAY2_8TO9LABEL.setText("");
        SATURDAY1_9TO10LABEL.setText("");
        SATURDAY2_9TO10LABEL.setText("");
        SATURDAY1_10TO11LABEL.setText("");
        SATURDAY2_10TO11LABEL.setText("");
        SATURDAY1_11TO12LABEL.setText("");
        SATURDAY2_11TO12LABEL.setText("");
        SATURDAY1_12TO1LABEL.setText("");
        SATURDAY2_12TO1LABEL.setText("");
        SATURDAY1_1TO2LABEL.setText("");
        SATURDAY2_1TO2LABEL.setText("");
        SATURDAY1_2TO3LABEL.setText("");
        SATURDAY2_2TO3LABEL.setText("");
        SATURDAY1_3TO4LABEL.setText("");
        SATURDAY2_3TO4LABEL.setText("");
        SATURDAY1_4TO5LABEL.setText("");
        SATURDAY2_4TO5LABEL.setText("");
        SATURDAY1_5TO6LABEL.setText("");
        SATURDAY2_5TO6LABEL.setText("");
        SATURDAY1_6TO7LABEL.setText("");
        SATURDAY2_6TO7LABEL.setText("");
        
        SATURDAY1_7TO8.setBackground(white);
        SATURDAY2_7TO8.setBackground(white);
        SATURDAY1_8TO9.setBackground(white);
        SATURDAY2_8TO9.setBackground(white);
        SATURDAY1_9TO10.setBackground(white);
        SATURDAY2_9TO10.setBackground(white);
        SATURDAY1_10TO11.setBackground(white);
        SATURDAY2_10TO11.setBackground(white);
        SATURDAY1_11TO12.setBackground(white);
        SATURDAY2_11TO12.setBackground(white);
        SATURDAY1_12TO1.setBackground(white);
        SATURDAY2_12TO1.setBackground(white);
        SATURDAY1_1TO2.setBackground(white);
        SATURDAY2_1TO2.setBackground(white);
        SATURDAY1_2TO3.setBackground(white);
        SATURDAY2_2TO3.setBackground(white);
        SATURDAY1_3TO4.setBackground(white);
        SATURDAY2_3TO4.setBackground(white);
        SATURDAY1_4TO5.setBackground(white);
        SATURDAY2_4TO5.setBackground(white);
        SATURDAY1_5TO6.setBackground(white);
        SATURDAY2_5TO6.setBackground(white);
        SATURDAY1_6TO7.setBackground(white);
        SATURDAY2_6TO7.setBackground(white);
    }
    public void SetBorder(){
        MONDAY1_7TO8.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_7TO8.setBorder(new MatteBorder(0,1,1,1, black));  
        MONDAY1_8TO9.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_8TO9.setBorder(new MatteBorder(0,1,1,1, black));       
        MONDAY1_9TO10.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_9TO10.setBorder(new MatteBorder(0,1,1,1, black));       
        MONDAY1_10TO11.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_10TO11.setBorder(new MatteBorder(0,1,1,1, black));       
        MONDAY1_11TO12.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_11TO12.setBorder(new MatteBorder(0,1,1,1, black));        
        MONDAY1_12TO1.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_12TO1.setBorder(new MatteBorder(0,1,1,1, black));        
        MONDAY1_1TO2.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_1TO2.setBorder(new MatteBorder(0,1,1,1, black));
        MONDAY1_2TO3.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_2TO3.setBorder(new MatteBorder(0,1,1,1, black));
        MONDAY1_3TO4.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_3TO4.setBorder(new MatteBorder(0,1,1,1, black));
        MONDAY1_4TO5.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_4TO5.setBorder(new MatteBorder(0,1,1,1, black));
        MONDAY1_5TO6.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_5TO6.setBorder(new MatteBorder(0,1,1,1, black));
        MONDAY1_6TO7.setBorder(new MatteBorder(1,1,0,1, black));
        MONDAY2_6TO7.setBorder(new MatteBorder(0,1,1,1, black));
        
        TUESDAY1_7TO8.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_7TO8.setBorder(new MatteBorder(0,1,1,1, black));  
        TUESDAY1_8TO9.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_8TO9.setBorder(new MatteBorder(0,1,1,1, black));
        TUESDAY1_9TO10.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_9TO10.setBorder(new MatteBorder(0,1,1,1, black));
        TUESDAY1_10TO11.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_10TO11.setBorder(new MatteBorder(0,1,1,1, black));
        TUESDAY1_11TO12.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_11TO12.setBorder(new MatteBorder(0,1,1,1, black));
        TUESDAY1_12TO1.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_12TO1.setBorder(new MatteBorder(0,1,1,1, black));
        TUESDAY1_1TO2.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_1TO2.setBorder(new MatteBorder(0,1,1,1, black));
        TUESDAY1_2TO3.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_2TO3.setBorder(new MatteBorder(0,1,1,1, black));
        TUESDAY1_3TO4.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_3TO4.setBorder(new MatteBorder(0,1,1,1, black));
        TUESDAY1_4TO5.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_4TO5.setBorder(new MatteBorder(0,1,1,1, black)); 
        TUESDAY1_5TO6.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_5TO6.setBorder(new MatteBorder(0,1,1,1, black));
        TUESDAY1_6TO7.setBorder(new MatteBorder(1,1,0,1, black));
        TUESDAY2_6TO7.setBorder(new MatteBorder(0,1,1,1, black));
        
        WEDNESDAY1_7TO8.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_7TO8.setBorder(new MatteBorder(0,1,1,1, black));  
        WEDNESDAY1_8TO9.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_8TO9.setBorder(new MatteBorder(0,1,1,1, black));
        WEDNESDAY1_9TO10.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_9TO10.setBorder(new MatteBorder(0,1,1,1, black));
        WEDNESDAY1_10TO11.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_10TO11.setBorder(new MatteBorder(0,1,1,1, black));
        WEDNESDAY1_11TO12.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_11TO12.setBorder(new MatteBorder(0,1,1,1, black));
        WEDNESDAY1_12TO1.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_12TO1.setBorder(new MatteBorder(0,1,1,1, black));
        WEDNESDAY1_1TO2.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_1TO2.setBorder(new MatteBorder(0,1,1,1, black));
        WEDNESDAY1_2TO3.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_2TO3.setBorder(new MatteBorder(0,1,1,1, black));
        WEDNESDAY1_3TO4.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_3TO4.setBorder(new MatteBorder(0,1,1,1, black));
        WEDNESDAY1_4TO5.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_4TO5.setBorder(new MatteBorder(0,1,1,1, black)); 
        WEDNESDAY1_5TO6.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_5TO6.setBorder(new MatteBorder(0,1,1,1, black));
        WEDNESDAY1_6TO7.setBorder(new MatteBorder(1,1,0,1, black));
        WEDNESDAY2_6TO7.setBorder(new MatteBorder(0,1,1,1, black));
        
        THURSDAY1_7TO8.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_7TO8.setBorder(new MatteBorder(0,1,1,1, black));  
        THURSDAY1_8TO9.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_8TO9.setBorder(new MatteBorder(0,1,1,1, black));
        THURSDAY1_9TO10.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_9TO10.setBorder(new MatteBorder(0,1,1,1, black));
        THURSDAY1_10TO11.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_10TO11.setBorder(new MatteBorder(0,1,1,1, black));
        THURSDAY1_11TO12.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_11TO12.setBorder(new MatteBorder(0,1,1,1, black));
        THURSDAY1_12TO1.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_12TO1.setBorder(new MatteBorder(0,1,1,1, black));
        THURSDAY1_1TO2.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_1TO2.setBorder(new MatteBorder(0,1,1,1, black));
        THURSDAY1_2TO3.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_2TO3.setBorder(new MatteBorder(0,1,1,1, black));
        THURSDAY1_3TO4.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_3TO4.setBorder(new MatteBorder(0,1,1,1, black));
        THURSDAY1_4TO5.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_4TO5.setBorder(new MatteBorder(0,1,1,1, black)); 
        THURSDAY1_5TO6.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_5TO6.setBorder(new MatteBorder(0,1,1,1, black));
        THURSDAY1_6TO7.setBorder(new MatteBorder(1,1,0,1, black));
        THURSDAY2_6TO7.setBorder(new MatteBorder(0,1,1,1, black));
        
        FRIDAY1_7TO8.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_7TO8.setBorder(new MatteBorder(0,1,1,1, black));  
        FRIDAY1_8TO9.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_8TO9.setBorder(new MatteBorder(0,1,1,1, black));
        FRIDAY1_9TO10.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_9TO10.setBorder(new MatteBorder(0,1,1,1, black));
        FRIDAY1_10TO11.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_10TO11.setBorder(new MatteBorder(0,1,1,1, black));
        FRIDAY1_11TO12.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_11TO12.setBorder(new MatteBorder(0,1,1,1, black));
        FRIDAY1_12TO1.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_12TO1.setBorder(new MatteBorder(0,1,1,1, black));
        FRIDAY1_1TO2.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_1TO2.setBorder(new MatteBorder(0,1,1,1, black));
        FRIDAY1_2TO3.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_2TO3.setBorder(new MatteBorder(0,1,1,1, black));
        FRIDAY1_3TO4.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_3TO4.setBorder(new MatteBorder(0,1,1,1, black));
        FRIDAY1_4TO5.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_4TO5.setBorder(new MatteBorder(0,1,1,1, black)); 
        FRIDAY1_5TO6.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_5TO6.setBorder(new MatteBorder(0,1,1,1, black));
        FRIDAY1_6TO7.setBorder(new MatteBorder(1,1,0,1, black));
        FRIDAY2_6TO7.setBorder(new MatteBorder(0,1,1,1, black));
        
        SATURDAY1_7TO8.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_7TO8.setBorder(new MatteBorder(0,1,1,1, black));  
        SATURDAY1_8TO9.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_8TO9.setBorder(new MatteBorder(0,1,1,1, black));
        SATURDAY1_9TO10.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_9TO10.setBorder(new MatteBorder(0,1,1,1, black));
        SATURDAY1_10TO11.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_10TO11.setBorder(new MatteBorder(0,1,1,1, black));
        SATURDAY1_11TO12.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_11TO12.setBorder(new MatteBorder(0,1,1,1, black));
        SATURDAY1_12TO1.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_12TO1.setBorder(new MatteBorder(0,1,1,1, black));
        SATURDAY1_1TO2.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_1TO2.setBorder(new MatteBorder(0,1,1,1, black));
        SATURDAY1_2TO3.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_2TO3.setBorder(new MatteBorder(0,1,1,1, black));
        SATURDAY1_3TO4.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_3TO4.setBorder(new MatteBorder(0,1,1,1, black));
        SATURDAY1_4TO5.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_4TO5.setBorder(new MatteBorder(0,1,1,1, black)); 
        SATURDAY1_5TO6.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_5TO6.setBorder(new MatteBorder(0,1,1,1, black));
        SATURDAY1_6TO7.setBorder(new MatteBorder(1,1,0,1, black));
        SATURDAY2_6TO7.setBorder(new MatteBorder(0,1,1,1, black));
    }
    public void timerget(){
        System.out.print(LiveTime.getText());
    }
    public void MondaySchd(){
       try{ Connect();
            Statement st = connect.createStatement();
            String SMONDAY1_7TO8 = null,SMONDAY2_7TO8 = null, SMONDAY1_8TO9 = null, SMONDAY2_8TO9 = null, SMONDAY1_9TO10= null, SMONDAY2_9TO10= null;
            String SMONDAY1_10TO11 = null, SMONDAY2_10TO11= null, SMONDAY1_11TO12= null, SMONDAY2_11TO12= null, SMONDAY1_12TO1= null, SMONDAY2_12TO1= null;
            String SMONDAY1_1TO2 = null, SMONDAY2_1TO2= null, SMONDAY1_2TO3 = null, SMONDAY2_2TO3 = null, SMONDAY1_3TO4 = null, SMONDAY2_3TO4 = null;
            String SMONDAY1_4TO5 = null, SMONDAY2_4TO5 = null, SMONDAY1_5TO6 = null, SMONDAY2_5TO6 = null, SMONDAY1_6TO7 = null, SMONDAY2_6TO7 = null;  
            
            String query = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='7TO8H1'";
            String query1 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='7TO8H2'";
            String query2 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='8TO9H1'";
            String query3 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='8TO9H2'";
            String query4 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='9TO10H1'";
            String query5 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='9TO10H2'";
            String query6 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='10TO11H1'";
            String query7 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='10TO11H2'";
            String query8 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='11TO12H1'";
            String query9 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='11TO12H2'";
            String query10 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='12TO1H1'";
            String query11 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='12TO1H2'";
            String query12 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='1TO2H1'";
            String query13 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='1TO2H2'";
            String query14 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='2TO3H1'";
            String query15 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='2TO3H2'";
            String query16 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='3TO4H1'";
            String query17 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='3TO4H2'";
            String query18 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='4TO5H1'";
            String query19 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='4TO5H2'";
            String query20 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='5TO6H1'";
            String query21 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='5TO6H2'";
            String query22 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='6TO7H1'";
            String query23 = "SELECT Monday FROM "+section1+"_SCHED WHERE Time='6TO7H2'";
            
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                SMONDAY1_7TO8 = rs.getString(1);             
            }
            if(SMONDAY1_7TO8 == "" || SMONDAY1_7TO8 == null){    
                MONDAY1_7TO8.setBackground(white);
            }
            else{ 
                MONDAY1_7TO8.setBackground(green);
                MONDAY1_7TO8LABEL.setText(SMONDAY1_7TO8);
            }           
            rs = st.executeQuery(query1);
            while(rs.next()){
                SMONDAY2_7TO8 = rs.getString(1);             
            }          
            if(SMONDAY2_7TO8 == "" || SMONDAY2_7TO8 == null){
                MONDAY2_7TO8.setBackground(white); 
            }
            else{
                MONDAY2_7TO8.setBackground(green);
                MONDAY2_7TO8LABEL.setText(SMONDAY2_7TO8);
            }
            rs = st.executeQuery(query2);
            while(rs.next()){
                SMONDAY1_8TO9 = rs.getString(1);             
            }          
            if(SMONDAY1_8TO9 == "" || SMONDAY1_8TO9 == null){
                MONDAY1_8TO9.setBackground(white);   
            }
            else{
                MONDAY1_8TO9.setBackground(green); 
                MONDAY1_8TO9LABEL.setText(SMONDAY1_8TO9);   
            }
            rs = st.executeQuery(query3);
            while(rs.next()){
                SMONDAY2_8TO9 = rs.getString(1);             
            }          
            if(SMONDAY2_8TO9 == "" || SMONDAY2_8TO9 == null){
                MONDAY2_8TO9.setBackground(white);   
            }
            else{ 
                MONDAY2_8TO9.setBackground(green);
                MONDAY2_8TO9LABEL.setText(SMONDAY2_8TO9);              
            }
            rs = st.executeQuery(query4);
            while(rs.next()){
                SMONDAY1_9TO10 = rs.getString(1);             
            }          
            if(SMONDAY1_9TO10 == "" || SMONDAY1_9TO10 == null){
                MONDAY1_9TO10.setBackground(white);           
            }
            else{
                MONDAY1_9TO10.setBackground(green); 
                MONDAY1_9TO10LABEL.setText(SMONDAY1_9TO10);
            }
            rs = st.executeQuery(query5);
            while(rs.next()){
                SMONDAY2_9TO10 = rs.getString(1);             
            }          
            if(SMONDAY2_9TO10 == "" || SMONDAY2_9TO10 == null){
                MONDAY2_9TO10.setBackground(white);
               
            }
            else{
                MONDAY2_9TO10.setBackground(green);
                MONDAY2_9TO10LABEL.setText(SMONDAY2_9TO10);
            }
            rs = st.executeQuery(query6);
            while(rs.next()){
                SMONDAY1_10TO11 = rs.getString(1);             
            }          
            if(SMONDAY1_10TO11 == "" || SMONDAY1_10TO11 == null){
                MONDAY1_10TO11.setBackground(white);  
            }
            else{
                MONDAY1_10TO11.setBackground(green);
                MONDAY1_10TO11LABEL.setText(SMONDAY1_10TO11);
            }
            rs = st.executeQuery(query7);
            while(rs.next()){
                SMONDAY2_10TO11 = rs.getString(1);             
            }          
            if(SMONDAY2_10TO11 == "" || SMONDAY2_10TO11 == null){
                MONDAY2_10TO11.setBackground(white); 
            }
            else{
                MONDAY2_10TO11.setBackground(green); 
                MONDAY2_10TO11LABEL.setText(SMONDAY2_10TO11);
            }
            rs = st.executeQuery(query8);
            while(rs.next()){
                SMONDAY1_11TO12 = rs.getString(1);             
            }          
            if(SMONDAY1_11TO12 == "" || SMONDAY1_11TO12 == null){
                MONDAY1_11TO12.setBackground(white);
            }
            else{
                MONDAY1_11TO12.setBackground(green);
                MONDAY1_11TO12LABEL.setText(SMONDAY1_11TO12);
            }
            rs = st.executeQuery(query9);
            while(rs.next()){
                SMONDAY2_11TO12 = rs.getString(1);             
            }          
            if(SMONDAY2_11TO12 == "" || SMONDAY2_11TO12 == null){
                MONDAY2_11TO12.setBackground(white);
            }
            else{
                MONDAY2_11TO12.setBackground(green);
                MONDAY2_11TO12LABEL.setText(SMONDAY2_11TO12);
            }
            rs = st.executeQuery(query10);
            while(rs.next()){
                SMONDAY1_12TO1 = rs.getString(1);             
            }          
            if(SMONDAY1_12TO1 == "" || SMONDAY1_12TO1 == null){
                MONDAY1_12TO1.setBackground(white);
            }
            else{
                MONDAY1_12TO1.setBackground(green);
                MONDAY1_12TO1LABEL.setText(SMONDAY1_12TO1);
            }
            rs = st.executeQuery(query11);
            while(rs.next()){
                SMONDAY2_12TO1 = rs.getString(1);             
            }          
            if(SMONDAY2_12TO1 == "" || SMONDAY2_12TO1 == null){
                MONDAY2_12TO1.setBackground(white);
            }
            else{
                MONDAY2_12TO1.setBackground(green);
                MONDAY2_12TO1LABEL.setText(SMONDAY2_12TO1);
            }
            rs = st.executeQuery(query12);
            while(rs.next()){
                SMONDAY1_1TO2 = rs.getString(1);             
            }          
            if(SMONDAY1_1TO2 == "" || SMONDAY1_1TO2 == null){
                MONDAY1_1TO2.setBackground(white);
            }
            else{
                MONDAY1_1TO2.setBackground(green);
                MONDAY1_1TO2LABEL.setText(SMONDAY1_1TO2);
            }
            rs = st.executeQuery(query13);
            while(rs.next()){
                SMONDAY2_1TO2 = rs.getString(1);             
            }          
            if(SMONDAY2_1TO2 == "" || SMONDAY2_1TO2 == null){
                MONDAY2_1TO2.setBackground(white);
            }
            else{
                MONDAY2_1TO2.setBackground(green);
                MONDAY2_1TO2LABEL.setText(SMONDAY2_1TO2);
            }
            rs = st.executeQuery(query14);
            while(rs.next()){
                SMONDAY1_2TO3 = rs.getString(1);             
            }          
            if(SMONDAY1_2TO3 == "" || SMONDAY1_2TO3 == null){
                MONDAY1_2TO3.setBackground(white);
            }
            else{
                MONDAY1_2TO3.setBackground(green);
                MONDAY1_2TO3LABEL.setText(SMONDAY1_2TO3);
            }
            rs = st.executeQuery(query15);
            while(rs.next()){
                SMONDAY2_2TO3 = rs.getString(1);             
            }          
            if(SMONDAY2_2TO3 == "" || SMONDAY2_2TO3 == null){
                MONDAY2_2TO3.setBackground(white);
            }
            else{
                MONDAY2_2TO3.setBackground(green);
                MONDAY2_2TO3LABEL.setText(SMONDAY2_2TO3);
            }
            rs = st.executeQuery(query16);
            while(rs.next()){
                SMONDAY1_3TO4 = rs.getString(1);             
            }          
            if(SMONDAY1_3TO4 == "" || SMONDAY1_3TO4 == null){
                MONDAY1_3TO4.setBackground(white);
            }
            else{
                MONDAY1_3TO4.setBackground(green);
                MONDAY1_3TO4LABEL.setText(SMONDAY1_3TO4);
            }
            
            rs = st.executeQuery(query17);
            while(rs.next()){
                SMONDAY2_3TO4 = rs.getString(1);             
            } 
            if(SMONDAY2_3TO4 == "" || SMONDAY2_3TO4 == null){
                MONDAY2_3TO4.setBackground(white);
            }
            else{
                MONDAY2_3TO4.setBackground(green);
                MONDAY2_3TO4LABEL.setText(SMONDAY2_3TO4);
            }
            
            rs = st.executeQuery(query18);
            while(rs.next()){
                SMONDAY1_4TO5 = rs.getString(1);             
            }          
            if(SMONDAY1_4TO5 == "" || SMONDAY1_4TO5 == null){
                MONDAY1_4TO5.setBackground(white);
            }
            else{
                MONDAY1_4TO5.setBackground(green);
                MONDAY1_4TO5LABEL.setText(SMONDAY1_4TO5);
            }
            rs = st.executeQuery(query19);
            while(rs.next()){
                SMONDAY2_4TO5 = rs.getString(1);             
            }          
            if(SMONDAY2_4TO5 == "" || SMONDAY2_4TO5 == null){
                MONDAY2_4TO5.setBackground(white);
            }
            else{
                MONDAY2_4TO5.setBackground(green);
                MONDAY2_4TO5LABEL.setText(SMONDAY2_4TO5);
            }
            rs = st.executeQuery(query20);
            while(rs.next()){
                SMONDAY1_5TO6 = rs.getString(1);             
            }          
            if(SMONDAY1_5TO6 == "" || SMONDAY1_5TO6 == null){
                MONDAY1_5TO6.setBackground(white);
            }
            else{
                MONDAY1_5TO6.setBackground(green);
                MONDAY1_5TO6LABEL.setText(SMONDAY1_5TO6);
            }
            rs = st.executeQuery(query21);
            while(rs.next()){
                SMONDAY2_5TO6 = rs.getString(1);             
            }          
            if(SMONDAY2_5TO6 == "" || SMONDAY2_5TO6 == null){
                MONDAY2_5TO6.setBackground(white);
            }
            else{
                MONDAY2_5TO6.setBackground(green);
                MONDAY2_5TO6LABEL.setText(SMONDAY2_5TO6);
            }
            rs = st.executeQuery(query22);
            while(rs.next()){
                SMONDAY1_6TO7 = rs.getString(1);             
            }          
            if(SMONDAY1_6TO7 == "" || SMONDAY1_6TO7 == null){
                MONDAY1_6TO7.setBackground(white);
            }
            else{
                MONDAY1_6TO7.setBackground(green);
                MONDAY1_6TO7LABEL.setText(SMONDAY1_6TO7);
            }
            rs = st.executeQuery(query23);
            while(rs.next()){
                SMONDAY2_6TO7 = rs.getString(1);             
            }          
            if(SMONDAY2_6TO7 == "" || SMONDAY2_6TO7 == null){
                MONDAY2_6TO7.setBackground(white);
            }
            else{
                MONDAY2_6TO7.setBackground(green);
                MONDAY2_6TO7LABEL.setText(SMONDAY2_6TO7);
            }
            
            }
        catch(Exception e){
            System.out.println(e);
        } 
   }
    public void TuesdaySchd(){
       try{ Connect();
            Statement st = connect.createStatement();
            String STUESDAY1_7TO8 = null,STUESDAY2_7TO8 = null, STUESDAY1_8TO9 = null, STUESDAY2_8TO9 = null, STUESDAY1_9TO10= null, STUESDAY2_9TO10= null;
            String STUESDAY1_10TO11 = null, STUESDAY2_10TO11= null, STUESDAY1_11TO12= null, STUESDAY2_11TO12= null, STUESDAY1_12TO1= null, STUESDAY2_12TO1= null;
            String STUESDAY1_1TO2 = null, STUESDAY2_1TO2= null, STUESDAY1_2TO3 = null, STUESDAY2_2TO3 = null, STUESDAY1_3TO4 = null, STUESDAY2_3TO4 = null;
            String STUESDAY1_4TO5 = null, STUESDAY2_4TO5 = null, STUESDAY1_5TO6 = null, STUESDAY2_5TO6 = null, STUESDAY1_6TO7 = null, STUESDAY2_6TO7 = null;  
            
            String query = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='7TO8H1'";
            String query1 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='7TO8H2'";
            String query2 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='8TO9H1'";
            String query3 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='8TO9H2'";
            String query4 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='9TO10H1'";
            String query5 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='9TO10H2'";
            String query6 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='10TO11H1'";
            String query7 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='10TO11H2'";
            String query8 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='11TO12H1'";
            String query9 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='11TO12H2'";
            String query10 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='12TO1H1'";
            String query11 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='12TO1H2'";
            String query12 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='1TO2H1'";
            String query13 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='1TO2H2'";
            String query14 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='2TO3H1'";
            String query15 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='2TO3H2'";
            String query16 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='3TO4H1'";
            String query17 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='3TO4H2'";
            String query18 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='4TO5H1'";
            String query19 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='4TO5H2'";
            String query20 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='5TO6H1'";
            String query21 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='5TO6H2'";
            String query22 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='6TO7H1'";
            String query23 = "SELECT Tuesday FROM "+section1+"_SCHED WHERE Time='6TO7H2'";
            
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                STUESDAY1_7TO8 = rs.getString(1);             
            }
            if(STUESDAY1_7TO8 == "" || STUESDAY1_7TO8 == null){    
                TUESDAY1_7TO8.setBackground(white);
            }
            else{ 
                TUESDAY1_7TO8.setBackground(green);
                TUESDAY1_7TO8LABEL.setText(STUESDAY1_7TO8);
            }           
            rs = st.executeQuery(query1);
            while(rs.next()){
                STUESDAY2_7TO8 = rs.getString(1);             
            }          
            if(STUESDAY2_7TO8 == "" || STUESDAY2_7TO8 == null){
                TUESDAY2_7TO8.setBackground(white); 
            }
            else{
                TUESDAY2_7TO8.setBackground(green);
                TUESDAY2_7TO8LABEL.setText(STUESDAY2_7TO8);
            }
            rs = st.executeQuery(query2);
            while(rs.next()){
                STUESDAY1_8TO9 = rs.getString(1);             
            }          
            if(STUESDAY1_8TO9 == "" || STUESDAY1_8TO9 == null){
                TUESDAY1_8TO9.setBackground(white);   
            }
            else{
                TUESDAY1_8TO9.setBackground(green); 
                TUESDAY1_8TO9LABEL.setText(STUESDAY1_8TO9);   
            }
            rs = st.executeQuery(query3);
            while(rs.next()){
                STUESDAY2_8TO9 = rs.getString(1);             
            }          
            if(STUESDAY2_8TO9 == "" || STUESDAY2_8TO9 == null){
                TUESDAY2_8TO9.setBackground(white);   
            }
            else{ 
                TUESDAY2_8TO9.setBackground(green);
                TUESDAY2_8TO9LABEL.setText(STUESDAY2_8TO9);              
            }
            rs = st.executeQuery(query4);
            while(rs.next()){
                STUESDAY1_9TO10 = rs.getString(1);             
            }          
            if(STUESDAY1_9TO10 == "" || STUESDAY1_9TO10 == null){
                TUESDAY1_9TO10.setBackground(white);           
            }
            else{
                TUESDAY1_9TO10.setBackground(green); 
                TUESDAY1_9TO10LABEL.setText(STUESDAY1_9TO10);
            }
            rs = st.executeQuery(query5);
            while(rs.next()){
                STUESDAY2_9TO10 = rs.getString(1);             
            }          
            if(STUESDAY2_9TO10 == "" || STUESDAY2_9TO10 == null){
                TUESDAY2_9TO10.setBackground(white);
               
            }
            else{
                TUESDAY2_9TO10.setBackground(green);
                TUESDAY2_9TO10LABEL.setText(STUESDAY2_9TO10);
            }
            rs = st.executeQuery(query6);
            while(rs.next()){
                STUESDAY1_10TO11 = rs.getString(1);             
            }          
            if(STUESDAY1_10TO11 == "" || STUESDAY1_10TO11 == null){
                TUESDAY1_10TO11.setBackground(white);  
            }
            else{
                TUESDAY1_10TO11.setBackground(green);
                TUESDAY1_10TO11LABEL.setText(STUESDAY1_10TO11);
            }
            rs = st.executeQuery(query7);
            while(rs.next()){
                STUESDAY2_10TO11 = rs.getString(1);             
            }          
            if(STUESDAY2_10TO11 == "" || STUESDAY2_10TO11 == null){
                TUESDAY2_10TO11.setBackground(white); 
            }
            else{
                TUESDAY2_10TO11.setBackground(green); 
                TUESDAY2_10TO11LABEL.setText(STUESDAY2_10TO11);
            }
            rs = st.executeQuery(query8);
            while(rs.next()){
                STUESDAY1_11TO12 = rs.getString(1);             
            }          
            if(STUESDAY1_11TO12 == "" || STUESDAY1_11TO12 == null){
                TUESDAY1_11TO12.setBackground(white);
            }
            else{
                TUESDAY1_11TO12.setBackground(green);
                TUESDAY1_11TO12LABEL.setText(STUESDAY1_11TO12);
            }
            rs = st.executeQuery(query9);
            while(rs.next()){
                STUESDAY2_11TO12 = rs.getString(1);             
            }          
            if(STUESDAY2_11TO12 == "" || STUESDAY2_11TO12 == null){
                TUESDAY2_11TO12.setBackground(white);
            }
            else{
                TUESDAY2_11TO12.setBackground(green);
                TUESDAY2_11TO12LABEL.setText(STUESDAY2_11TO12);
            }
            rs = st.executeQuery(query10);
            while(rs.next()){
                STUESDAY1_12TO1 = rs.getString(1);             
            }          
            if(STUESDAY1_12TO1 == "" || STUESDAY1_12TO1 == null){
                TUESDAY1_12TO1.setBackground(white);
            }
            else{
                TUESDAY1_12TO1.setBackground(green);
                TUESDAY1_12TO1LABEL.setText(STUESDAY1_12TO1);
            }
            rs = st.executeQuery(query11);
            while(rs.next()){
                STUESDAY2_12TO1 = rs.getString(1);             
            }          
            if(STUESDAY2_12TO1 == "" || STUESDAY2_12TO1 == null){
                TUESDAY2_12TO1.setBackground(white);
            }
            else{
                TUESDAY2_12TO1.setBackground(green);
                TUESDAY2_12TO1LABEL.setText(STUESDAY2_12TO1);
            }
            rs = st.executeQuery(query12);
            while(rs.next()){
                STUESDAY1_1TO2 = rs.getString(1);             
            }          
            if(STUESDAY1_1TO2 == "" || STUESDAY1_1TO2 == null){
                TUESDAY1_1TO2.setBackground(white);
            }
            else{
                TUESDAY1_1TO2.setBackground(green);
                TUESDAY1_1TO2LABEL.setText(STUESDAY1_1TO2);
            }
            rs = st.executeQuery(query13);
            while(rs.next()){
                STUESDAY2_1TO2 = rs.getString(1);             
            }          
            if(STUESDAY2_1TO2 == "" || STUESDAY2_1TO2 == null){
                TUESDAY2_1TO2.setBackground(white);
            }
            else{
                TUESDAY2_1TO2.setBackground(green);
                TUESDAY2_1TO2LABEL.setText(STUESDAY2_1TO2);
            }
            rs = st.executeQuery(query14);
            while(rs.next()){
                STUESDAY1_2TO3 = rs.getString(1);             
            }          
            if(STUESDAY1_2TO3 == "" || STUESDAY1_2TO3 == null){
                TUESDAY1_2TO3.setBackground(white);
            }
            else{
                TUESDAY1_2TO3.setBackground(green);
                TUESDAY1_2TO3LABEL.setText(STUESDAY1_2TO3);
            }
            rs = st.executeQuery(query15);
            while(rs.next()){
                STUESDAY2_2TO3 = rs.getString(1);             
            }          
            if(STUESDAY2_2TO3 == "" || STUESDAY2_2TO3 == null){
                TUESDAY2_2TO3.setBackground(white);
            }
            else{
                TUESDAY2_2TO3.setBackground(green);
                TUESDAY2_2TO3LABEL.setText(STUESDAY2_2TO3);
            }
            rs = st.executeQuery(query16);
            while(rs.next()){
                STUESDAY1_3TO4 = rs.getString(1);             
            }          
            if(STUESDAY1_3TO4 == "" || STUESDAY1_3TO4 == null){
                TUESDAY1_3TO4.setBackground(white);
            }
            else{
                TUESDAY1_3TO4.setBackground(green);
                TUESDAY1_3TO4LABEL.setText(STUESDAY1_3TO4);
            }
            
            rs = st.executeQuery(query17);
            while(rs.next()){
                STUESDAY2_3TO4 = rs.getString(1);             
            } 
            if(STUESDAY2_3TO4 == "" || STUESDAY2_3TO4 == null){
                TUESDAY2_3TO4.setBackground(white);
            }
            else{
                TUESDAY2_3TO4.setBackground(green);
                TUESDAY2_3TO4LABEL.setText(STUESDAY2_3TO4);
            }
            
            rs = st.executeQuery(query18);
            while(rs.next()){
                STUESDAY1_4TO5 = rs.getString(1);             
            }          
            if(STUESDAY1_4TO5 == "" || STUESDAY1_4TO5 == null){
                TUESDAY1_4TO5.setBackground(white);
            }
            else{
                TUESDAY1_4TO5.setBackground(green);
                TUESDAY1_4TO5LABEL.setText(STUESDAY1_4TO5);
            }
            rs = st.executeQuery(query19);
            while(rs.next()){
                STUESDAY2_4TO5 = rs.getString(1);             
            }          
            if(STUESDAY2_4TO5 == "" || STUESDAY2_4TO5 == null){
                TUESDAY2_4TO5.setBackground(white);
            }
            else{
                TUESDAY2_4TO5.setBackground(green);
                TUESDAY2_4TO5LABEL.setText(STUESDAY2_4TO5);
            }
            rs = st.executeQuery(query20);
            while(rs.next()){
                STUESDAY1_5TO6 = rs.getString(1);             
            }          
            if(STUESDAY1_5TO6 == "" || STUESDAY1_5TO6 == null){
                TUESDAY1_5TO6.setBackground(white);
            }
            else{
                TUESDAY1_5TO6.setBackground(green);
                TUESDAY1_5TO6LABEL.setText(STUESDAY1_5TO6);
            }
            rs = st.executeQuery(query21);
            while(rs.next()){
                STUESDAY2_5TO6 = rs.getString(1);             
            }          
            if(STUESDAY2_5TO6 == "" || STUESDAY2_5TO6 == null){
                TUESDAY2_5TO6.setBackground(white);
            }
            else{
                TUESDAY2_5TO6.setBackground(green);
                TUESDAY2_5TO6LABEL.setText(STUESDAY2_5TO6);
            }
            rs = st.executeQuery(query22);
            while(rs.next()){
                STUESDAY1_6TO7 = rs.getString(1);             
            }          
            if(STUESDAY1_6TO7 == "" || STUESDAY1_6TO7 == null){
                TUESDAY1_6TO7.setBackground(white);
            }
            else{
                TUESDAY1_6TO7.setBackground(green);
                TUESDAY1_6TO7LABEL.setText(STUESDAY1_6TO7);
            }
            rs = st.executeQuery(query23);
            while(rs.next()){
                STUESDAY2_6TO7 = rs.getString(1);             
            }          
            if(STUESDAY2_6TO7 == "" || STUESDAY2_6TO7 == null){
                TUESDAY2_6TO7.setBackground(white);
            }
            else{
                TUESDAY2_6TO7.setBackground(green);
                TUESDAY2_6TO7LABEL.setText(STUESDAY2_6TO7);
            }
            
            }
        catch(Exception e){
            System.out.println(e);
        } 
   }
    public void WednesdaySchd(){
       try{ Connect();
            Statement st = connect.createStatement();
            String SWEDNESDAY1_7TO8 = null,SWEDNESDAY2_7TO8 = null, SWEDNESDAY1_8TO9 = null, SWEDNESDAY2_8TO9 = null, SWEDNESDAY1_9TO10= null, SWEDNESDAY2_9TO10= null;
            String SWEDNESDAY1_10TO11 = null, SWEDNESDAY2_10TO11= null, SWEDNESDAY1_11TO12= null, SWEDNESDAY2_11TO12= null, SWEDNESDAY1_12TO1= null, SWEDNESDAY2_12TO1= null;
            String SWEDNESDAY1_1TO2 = null, SWEDNESDAY2_1TO2= null, SWEDNESDAY1_2TO3 = null, SWEDNESDAY2_2TO3 = null, SWEDNESDAY1_3TO4 = null, SWEDNESDAY2_3TO4 = null;
            String SWEDNESDAY1_4TO5 = null, SWEDNESDAY2_4TO5 = null, SWEDNESDAY1_5TO6 = null, SWEDNESDAY2_5TO6 = null, SWEDNESDAY1_6TO7 = null, SWEDNESDAY2_6TO7 = null;  
            
            String query = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='7TO8H1'";
            String query1 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='7TO8H2'";
            String query2 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='8TO9H1'";
            String query3 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='8TO9H2'";
            String query4 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='9TO10H1'";
            String query5 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='9TO10H2'";
            String query6 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='10TO11H1'";
            String query7 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='10TO11H2'";
            String query8 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='11TO12H1'";
            String query9 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='11TO12H2'";
            String query10 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='12TO1H1'";
            String query11 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='12TO1H2'";
            String query12 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='1TO2H1'";
            String query13 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='1TO2H2'";
            String query14 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='2TO3H1'";
            String query15 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='2TO3H2'";
            String query16 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='3TO4H1'";
            String query17 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='3TO4H2'";
            String query18 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='4TO5H1'";
            String query19 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='4TO5H2'";
            String query20 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='5TO6H1'";
            String query21 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='5TO6H2'";
            String query22 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='6TO7H1'";
            String query23 = "SELECT Wednesday FROM "+section1+"_SCHED WHERE Time='6TO7H2'";
            
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                SWEDNESDAY1_7TO8 = rs.getString(1);             
            }
            if(SWEDNESDAY1_7TO8 == "" || SWEDNESDAY1_7TO8 == null){    
                WEDNESDAY1_7TO8.setBackground(white);
            }
            else{ 
                WEDNESDAY1_7TO8.setBackground(green);
                WEDNESDAY1_7TO8LABEL.setText(SWEDNESDAY1_7TO8);
            }           
            rs = st.executeQuery(query1);
            while(rs.next()){
                SWEDNESDAY2_7TO8 = rs.getString(1);             
            }          
            if(SWEDNESDAY2_7TO8 == "" || SWEDNESDAY2_7TO8 == null){
                WEDNESDAY2_7TO8.setBackground(white); 
            }
            else{
                WEDNESDAY2_7TO8.setBackground(green);
                WEDNESDAY2_7TO8LABEL.setText(SWEDNESDAY2_7TO8);
            }
            rs = st.executeQuery(query2);
            while(rs.next()){
                SWEDNESDAY1_8TO9 = rs.getString(1);             
            }          
            if(SWEDNESDAY1_8TO9 == "" || SWEDNESDAY1_8TO9 == null){
                WEDNESDAY1_8TO9.setBackground(white);   
            }
            else{
                WEDNESDAY1_8TO9.setBackground(green); 
                WEDNESDAY1_8TO9LABEL.setText(SWEDNESDAY1_8TO9);   
            }
            rs = st.executeQuery(query3);
            while(rs.next()){
                SWEDNESDAY2_8TO9 = rs.getString(1);             
            }          
            if(SWEDNESDAY2_8TO9 == "" || SWEDNESDAY2_8TO9 == null){
                WEDNESDAY2_8TO9.setBackground(white);   
            }
            else{ 
                WEDNESDAY2_8TO9.setBackground(green);
                WEDNESDAY2_8TO9LABEL.setText(SWEDNESDAY2_8TO9);              
            }
            rs = st.executeQuery(query4);
            while(rs.next()){
                SWEDNESDAY1_9TO10 = rs.getString(1);             
            }          
            if(SWEDNESDAY1_9TO10 == "" || SWEDNESDAY1_9TO10 == null){
                WEDNESDAY1_9TO10.setBackground(white);           
            }
            else{
                WEDNESDAY1_9TO10.setBackground(green); 
                WEDNESDAY1_9TO10LABEL.setText(SWEDNESDAY1_9TO10);
            }
            rs = st.executeQuery(query5);
            while(rs.next()){
                SWEDNESDAY2_9TO10 = rs.getString(1);             
            }          
            if(SWEDNESDAY2_9TO10 == "" || SWEDNESDAY2_9TO10 == null){
                WEDNESDAY2_9TO10.setBackground(white);
               
            }
            else{
                WEDNESDAY2_9TO10.setBackground(green);
                WEDNESDAY2_9TO10LABEL.setText(SWEDNESDAY2_9TO10);
            }
            rs = st.executeQuery(query6);
            while(rs.next()){
                SWEDNESDAY1_10TO11 = rs.getString(1);             
            }          
            if(SWEDNESDAY1_10TO11 == "" || SWEDNESDAY1_10TO11 == null){
                WEDNESDAY1_10TO11.setBackground(white);  
            }
            else{
                WEDNESDAY1_10TO11.setBackground(green);
                WEDNESDAY1_10TO11LABEL.setText(SWEDNESDAY1_10TO11);
            }
            rs = st.executeQuery(query7);
            while(rs.next()){
                SWEDNESDAY2_10TO11 = rs.getString(1);             
            }          
            if(SWEDNESDAY2_10TO11 == "" || SWEDNESDAY2_10TO11 == null){
                WEDNESDAY2_10TO11.setBackground(white); 
            }
            else{
                WEDNESDAY2_10TO11.setBackground(green); 
                WEDNESDAY2_10TO11LABEL.setText(SWEDNESDAY2_10TO11);
            }
            rs = st.executeQuery(query8);
            while(rs.next()){
                SWEDNESDAY1_11TO12 = rs.getString(1);             
            }          
            if(SWEDNESDAY1_11TO12 == "" || SWEDNESDAY1_11TO12 == null){
                WEDNESDAY1_11TO12.setBackground(white);
            }
            else{
                WEDNESDAY1_11TO12.setBackground(green);
                WEDNESDAY1_11TO12LABEL.setText(SWEDNESDAY1_11TO12);
            }
            rs = st.executeQuery(query9);
            while(rs.next()){
                SWEDNESDAY2_11TO12 = rs.getString(1);             
            }          
            if(SWEDNESDAY2_11TO12 == "" || SWEDNESDAY2_11TO12 == null){
                WEDNESDAY2_11TO12.setBackground(white);
            }
            else{
                WEDNESDAY2_11TO12.setBackground(green);
                WEDNESDAY2_11TO12LABEL.setText(SWEDNESDAY2_11TO12);
            }
            rs = st.executeQuery(query10);
            while(rs.next()){
                SWEDNESDAY1_12TO1 = rs.getString(1);             
            }          
            if(SWEDNESDAY1_12TO1 == "" || SWEDNESDAY1_12TO1 == null){
                WEDNESDAY1_12TO1.setBackground(white);
            }
            else{
                WEDNESDAY1_12TO1.setBackground(green);
                WEDNESDAY1_12TO1LABEL.setText(SWEDNESDAY1_12TO1);
            }
            rs = st.executeQuery(query11);
            while(rs.next()){
                SWEDNESDAY2_12TO1 = rs.getString(1);             
            }          
            if(SWEDNESDAY2_12TO1 == "" || SWEDNESDAY2_12TO1 == null){
                WEDNESDAY2_12TO1.setBackground(white);
            }
            else{
                WEDNESDAY2_12TO1.setBackground(green);
                WEDNESDAY2_12TO1LABEL.setText(SWEDNESDAY2_12TO1);
            }
            rs = st.executeQuery(query12);
            while(rs.next()){
                SWEDNESDAY1_1TO2 = rs.getString(1);             
            }          
            if(SWEDNESDAY1_1TO2 == "" || SWEDNESDAY1_1TO2 == null){
                WEDNESDAY1_1TO2.setBackground(white);
            }
            else{
                WEDNESDAY1_1TO2.setBackground(green);
                WEDNESDAY1_1TO2LABEL.setText(SWEDNESDAY1_1TO2);
            }
            rs = st.executeQuery(query13);
            while(rs.next()){
                SWEDNESDAY2_1TO2 = rs.getString(1);             
            }          
            if(SWEDNESDAY2_1TO2 == "" || SWEDNESDAY2_1TO2 == null){
                WEDNESDAY2_1TO2.setBackground(white);
            }
            else{
                WEDNESDAY2_1TO2.setBackground(green);
                WEDNESDAY2_1TO2LABEL.setText(SWEDNESDAY2_1TO2);
            }
            rs = st.executeQuery(query14);
            while(rs.next()){
                SWEDNESDAY1_2TO3 = rs.getString(1);             
            }          
            if(SWEDNESDAY1_2TO3 == "" || SWEDNESDAY1_2TO3 == null){
                WEDNESDAY1_2TO3.setBackground(white);
            }
            else{
                WEDNESDAY1_2TO3.setBackground(green);
                WEDNESDAY1_2TO3LABEL.setText(SWEDNESDAY1_2TO3);
            }
            rs = st.executeQuery(query15);
            while(rs.next()){
                SWEDNESDAY2_2TO3 = rs.getString(1);             
            }          
            if(SWEDNESDAY2_2TO3 == "" || SWEDNESDAY2_2TO3 == null){
                WEDNESDAY2_2TO3.setBackground(white);
            }
            else{
                WEDNESDAY2_2TO3.setBackground(green);
                WEDNESDAY2_2TO3LABEL.setText(SWEDNESDAY2_2TO3);
            }
            rs = st.executeQuery(query16);
            while(rs.next()){
                SWEDNESDAY1_3TO4 = rs.getString(1);             
            }          
            if(SWEDNESDAY1_3TO4 == "" || SWEDNESDAY1_3TO4 == null){
                WEDNESDAY1_3TO4.setBackground(white);
            }
            else{
                WEDNESDAY1_3TO4.setBackground(green);
                WEDNESDAY1_3TO4LABEL.setText(SWEDNESDAY1_3TO4);
            }
            
            rs = st.executeQuery(query17);
            while(rs.next()){
                SWEDNESDAY2_3TO4 = rs.getString(1);             
            } 
            if(SWEDNESDAY2_3TO4 == "" || SWEDNESDAY2_3TO4 == null){
                WEDNESDAY2_3TO4.setBackground(white);
            }
            else{
                WEDNESDAY2_3TO4.setBackground(green);
                WEDNESDAY2_3TO4LABEL.setText(SWEDNESDAY2_3TO4);
            }
            
            rs = st.executeQuery(query18);
            while(rs.next()){
                SWEDNESDAY1_4TO5 = rs.getString(1);             
            }          
            if(SWEDNESDAY1_4TO5 == "" || SWEDNESDAY1_4TO5 == null){
                WEDNESDAY1_4TO5.setBackground(white);
            }
            else{
                WEDNESDAY1_4TO5.setBackground(green);
                WEDNESDAY1_4TO5LABEL.setText(SWEDNESDAY1_4TO5);
            }
            rs = st.executeQuery(query19);
            while(rs.next()){
                SWEDNESDAY2_4TO5 = rs.getString(1);             
            }          
            if(SWEDNESDAY2_4TO5 == "" || SWEDNESDAY2_4TO5 == null){
                WEDNESDAY2_4TO5.setBackground(white);
            }
            else{
                WEDNESDAY2_4TO5.setBackground(green);
                WEDNESDAY2_4TO5LABEL.setText(SWEDNESDAY2_4TO5);
            }
            rs = st.executeQuery(query20);
            while(rs.next()){
                SWEDNESDAY1_5TO6 = rs.getString(1);             
            }          
            if(SWEDNESDAY1_5TO6 == "" || SWEDNESDAY1_5TO6 == null){
                WEDNESDAY1_5TO6.setBackground(white);
            }
            else{
                WEDNESDAY1_5TO6.setBackground(green);
                WEDNESDAY1_5TO6LABEL.setText(SWEDNESDAY1_5TO6);
            }
            rs = st.executeQuery(query21);
            while(rs.next()){
                SWEDNESDAY2_5TO6 = rs.getString(1);             
            }          
            if(SWEDNESDAY2_5TO6 == "" || SWEDNESDAY2_5TO6 == null){
                WEDNESDAY2_5TO6.setBackground(white);
            }
            else{
                WEDNESDAY2_5TO6.setBackground(green);
                WEDNESDAY2_5TO6LABEL.setText(SWEDNESDAY2_5TO6);
            }
            rs = st.executeQuery(query22);
            while(rs.next()){
                SWEDNESDAY1_6TO7 = rs.getString(1);             
            }          
            if(SWEDNESDAY1_6TO7 == "" || SWEDNESDAY1_6TO7 == null){
                WEDNESDAY1_6TO7.setBackground(white);
            }
            else{
                WEDNESDAY1_6TO7.setBackground(green);
                WEDNESDAY1_6TO7LABEL.setText(SWEDNESDAY1_6TO7);
            }
            rs = st.executeQuery(query23);
            while(rs.next()){
                SWEDNESDAY2_6TO7 = rs.getString(1);             
            }          
            if(SWEDNESDAY2_6TO7 == "" || SWEDNESDAY2_6TO7 == null){
                WEDNESDAY2_6TO7.setBackground(white);
            }
            else{
                WEDNESDAY2_6TO7.setBackground(green);
                WEDNESDAY2_6TO7LABEL.setText(SWEDNESDAY2_6TO7);
            }
            
            }
        catch(Exception e){
            System.out.println(e);
        } 
   }
    public void ThursdaySchd(){
       try{ Connect();
            Statement st = connect.createStatement();
            String STHURSDAY1_7TO8 = null,STHURSDAY2_7TO8 = null, STHURSDAY1_8TO9 = null, STHURSDAY2_8TO9 = null, STHURSDAY1_9TO10= null, STHURSDAY2_9TO10= null;
            String STHURSDAY1_10TO11 = null, STHURSDAY2_10TO11= null, STHURSDAY1_11TO12= null, STHURSDAY2_11TO12= null, STHURSDAY1_12TO1= null, STHURSDAY2_12TO1= null;
            String STHURSDAY1_1TO2 = null, STHURSDAY2_1TO2= null, STHURSDAY1_2TO3 = null, STHURSDAY2_2TO3 = null, STHURSDAY1_3TO4 = null, STHURSDAY2_3TO4 = null;
            String STHURSDAY1_4TO5 = null, STHURSDAY2_4TO5 = null, STHURSDAY1_5TO6 = null, STHURSDAY2_5TO6 = null, STHURSDAY1_6TO7 = null, STHURSDAY2_6TO7 = null;  
            
            String query = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='7TO8H1'";
            String query1 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='7TO8H2'";
            String query2 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='8TO9H1'";
            String query3 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='8TO9H2'";
            String query4 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='9TO10H1'";
            String query5 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='9TO10H2'";
            String query6 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='10TO11H1'";
            String query7 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='10TO11H2'";
            String query8 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='11TO12H1'";
            String query9 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='11TO12H2'";
            String query10 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='12TO1H1'";
            String query11 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='12TO1H2'";
            String query12 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='1TO2H1'";
            String query13 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='1TO2H2'";
            String query14 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='2TO3H1'";
            String query15 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='2TO3H2'";
            String query16 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='3TO4H1'";
            String query17 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='3TO4H2'";
            String query18 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='4TO5H1'";
            String query19 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='4TO5H2'";
            String query20 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='5TO6H1'";
            String query21 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='5TO6H2'";
            String query22 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='6TO7H1'";
            String query23 = "SELECT Thursday FROM "+section1+"_SCHED WHERE Time='6TO7H2'";
            
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                STHURSDAY1_7TO8 = rs.getString(1);             
            }
            if(STHURSDAY1_7TO8 == "" || STHURSDAY1_7TO8 == null){    
                THURSDAY1_7TO8.setBackground(white);
            }
            else{ 
                THURSDAY1_7TO8.setBackground(green);
                THURSDAY1_7TO8LABEL.setText(STHURSDAY1_7TO8);
            }           
            rs = st.executeQuery(query1);
            while(rs.next()){
                STHURSDAY2_7TO8 = rs.getString(1);             
            }          
            if(STHURSDAY2_7TO8 == "" || STHURSDAY2_7TO8 == null){
                THURSDAY2_7TO8.setBackground(white); 
            }
            else{
                THURSDAY2_7TO8.setBackground(green);
                THURSDAY2_7TO8LABEL.setText(STHURSDAY2_7TO8);
            }
            rs = st.executeQuery(query2);
            while(rs.next()){
                STHURSDAY1_8TO9 = rs.getString(1);             
            }          
            if(STHURSDAY1_8TO9 == "" || STHURSDAY1_8TO9 == null){
                THURSDAY1_8TO9.setBackground(white);   
            }
            else{
                THURSDAY1_8TO9.setBackground(green); 
                THURSDAY1_8TO9LABEL.setText(STHURSDAY1_8TO9);   
            }
            rs = st.executeQuery(query3);
            while(rs.next()){
                STHURSDAY2_8TO9 = rs.getString(1);             
            }          
            if(STHURSDAY2_8TO9 == "" || STHURSDAY2_8TO9 == null){
                THURSDAY2_8TO9.setBackground(white);   
            }
            else{ 
                THURSDAY2_8TO9.setBackground(green);
                THURSDAY2_8TO9LABEL.setText(STHURSDAY2_8TO9);              
            }
            rs = st.executeQuery(query4);
            while(rs.next()){
                STHURSDAY1_9TO10 = rs.getString(1);             
            }          
            if(STHURSDAY1_9TO10 == "" || STHURSDAY1_9TO10 == null){
                THURSDAY1_9TO10.setBackground(white);           
            }
            else{
                THURSDAY1_9TO10.setBackground(green); 
                THURSDAY1_9TO10LABEL.setText(STHURSDAY1_9TO10);
            }
            rs = st.executeQuery(query5);
            while(rs.next()){
                STHURSDAY2_9TO10 = rs.getString(1);             
            }          
            if(STHURSDAY2_9TO10 == "" || STHURSDAY2_9TO10 == null){
                THURSDAY2_9TO10.setBackground(white);
               
            }
            else{
                THURSDAY2_9TO10.setBackground(green);
                THURSDAY2_9TO10LABEL.setText(STHURSDAY2_9TO10);
            }
            rs = st.executeQuery(query6);
            while(rs.next()){
                STHURSDAY1_10TO11 = rs.getString(1);             
            }          
            if(STHURSDAY1_10TO11 == "" || STHURSDAY1_10TO11 == null){
                THURSDAY1_10TO11.setBackground(white);  
            }
            else{
                THURSDAY1_10TO11.setBackground(green);
                THURSDAY1_10TO11LABEL.setText(STHURSDAY1_10TO11);
            }
            rs = st.executeQuery(query7);
            while(rs.next()){
                STHURSDAY2_10TO11 = rs.getString(1);             
            }          
            if(STHURSDAY2_10TO11 == "" || STHURSDAY2_10TO11 == null){
                THURSDAY2_10TO11.setBackground(white); 
            }
            else{
                THURSDAY2_10TO11.setBackground(green); 
                THURSDAY2_10TO11LABEL.setText(STHURSDAY2_10TO11);
            }
            rs = st.executeQuery(query8);
            while(rs.next()){
                STHURSDAY1_11TO12 = rs.getString(1);             
            }          
            if(STHURSDAY1_11TO12 == "" || STHURSDAY1_11TO12 == null){
                THURSDAY1_11TO12.setBackground(white);
            }
            else{
                THURSDAY1_11TO12.setBackground(green);
                THURSDAY1_11TO12LABEL.setText(STHURSDAY1_11TO12);
            }
            rs = st.executeQuery(query9);
            while(rs.next()){
                STHURSDAY2_11TO12 = rs.getString(1);             
            }          
            if(STHURSDAY2_11TO12 == "" || STHURSDAY2_11TO12 == null){
                THURSDAY2_11TO12.setBackground(white);
            }
            else{
                THURSDAY2_11TO12.setBackground(green);
                THURSDAY2_11TO12LABEL.setText(STHURSDAY2_11TO12);
            }
            rs = st.executeQuery(query10);
            while(rs.next()){
                STHURSDAY1_12TO1 = rs.getString(1);             
            }          
            if(STHURSDAY1_12TO1 == "" || STHURSDAY1_12TO1 == null){
                THURSDAY1_12TO1.setBackground(white);
            }
            else{
                THURSDAY1_12TO1.setBackground(green);
                THURSDAY1_12TO1LABEL.setText(STHURSDAY1_12TO1);
            }
            rs = st.executeQuery(query11);
            while(rs.next()){
                STHURSDAY2_12TO1 = rs.getString(1);             
            }          
            if(STHURSDAY2_12TO1 == "" || STHURSDAY2_12TO1 == null){
                THURSDAY2_12TO1.setBackground(white);
            }
            else{
                THURSDAY2_12TO1.setBackground(green);
                THURSDAY2_12TO1LABEL.setText(STHURSDAY2_12TO1);
            }
            rs = st.executeQuery(query12);
            while(rs.next()){
                STHURSDAY1_1TO2 = rs.getString(1);             
            }          
            if(STHURSDAY1_1TO2 == "" || STHURSDAY1_1TO2 == null){
                THURSDAY1_1TO2.setBackground(white);
            }
            else{
                THURSDAY1_1TO2.setBackground(green);
                THURSDAY1_1TO2LABEL.setText(STHURSDAY1_1TO2);
            }
            rs = st.executeQuery(query13);
            while(rs.next()){
                STHURSDAY2_1TO2 = rs.getString(1);             
            }          
            if(STHURSDAY2_1TO2 == "" || STHURSDAY2_1TO2 == null){
                THURSDAY2_1TO2.setBackground(white);
            }
            else{
                THURSDAY2_1TO2.setBackground(green);
                THURSDAY2_1TO2LABEL.setText(STHURSDAY2_1TO2);
            }
            rs = st.executeQuery(query14);
            while(rs.next()){
                STHURSDAY1_2TO3 = rs.getString(1);             
            }          
            if(STHURSDAY1_2TO3 == "" || STHURSDAY1_2TO3 == null){
                THURSDAY1_2TO3.setBackground(white);
            }
            else{
                THURSDAY1_2TO3.setBackground(green);
                THURSDAY1_2TO3LABEL.setText(STHURSDAY1_2TO3);
            }
            rs = st.executeQuery(query15);
            while(rs.next()){
                STHURSDAY2_2TO3 = rs.getString(1);             
            }          
            if(STHURSDAY2_2TO3 == "" || STHURSDAY2_2TO3 == null){
                THURSDAY2_2TO3.setBackground(white);
            }
            else{
                THURSDAY2_2TO3.setBackground(green);
                THURSDAY2_2TO3LABEL.setText(STHURSDAY2_2TO3);
            }
            rs = st.executeQuery(query16);
            while(rs.next()){
                STHURSDAY1_3TO4 = rs.getString(1);             
            }          
            if(STHURSDAY1_3TO4 == "" || STHURSDAY1_3TO4 == null){
                THURSDAY1_3TO4.setBackground(white);
            }
            else{
                THURSDAY1_3TO4.setBackground(green);
                THURSDAY1_3TO4LABEL.setText(STHURSDAY1_3TO4);
            }
            
            rs = st.executeQuery(query17);
            while(rs.next()){
                STHURSDAY2_3TO4 = rs.getString(1);             
            } 
            if(STHURSDAY2_3TO4 == "" || STHURSDAY2_3TO4 == null){
                THURSDAY2_3TO4.setBackground(white);
            }
            else{
                THURSDAY2_3TO4.setBackground(green);
                THURSDAY2_3TO4LABEL.setText(STHURSDAY2_3TO4);
            }
            
            rs = st.executeQuery(query18);
            while(rs.next()){
                STHURSDAY1_4TO5 = rs.getString(1);             
            }          
            if(STHURSDAY1_4TO5 == "" || STHURSDAY1_4TO5 == null){
                THURSDAY1_4TO5.setBackground(white);
            }
            else{
                THURSDAY1_4TO5.setBackground(green);
                THURSDAY1_4TO5LABEL.setText(STHURSDAY1_4TO5);
            }
            rs = st.executeQuery(query19);
            while(rs.next()){
                STHURSDAY2_4TO5 = rs.getString(1);             
            }          
            if(STHURSDAY2_4TO5 == "" || STHURSDAY2_4TO5 == null){
                THURSDAY2_4TO5.setBackground(white);
            }
            else{
                THURSDAY2_4TO5.setBackground(green);
                THURSDAY2_4TO5LABEL.setText(STHURSDAY2_4TO5);
            }
            rs = st.executeQuery(query20);
            while(rs.next()){
                STHURSDAY1_5TO6 = rs.getString(1);             
            }          
            if(STHURSDAY1_5TO6 == "" || STHURSDAY1_5TO6 == null){
                THURSDAY1_5TO6.setBackground(white);
            }
            else{
                THURSDAY1_5TO6.setBackground(green);
                THURSDAY1_5TO6LABEL.setText(STHURSDAY1_5TO6);
            }
            rs = st.executeQuery(query21);
            while(rs.next()){
                STHURSDAY2_5TO6 = rs.getString(1);             
            }          
            if(STHURSDAY2_5TO6 == "" || STHURSDAY2_5TO6 == null){
                THURSDAY2_5TO6.setBackground(white);
            }
            else{
                THURSDAY2_5TO6.setBackground(green);
                THURSDAY2_5TO6LABEL.setText(STHURSDAY2_5TO6);
            }
            rs = st.executeQuery(query22);
            while(rs.next()){
                STHURSDAY1_6TO7 = rs.getString(1);             
            }          
            if(STHURSDAY1_6TO7 == "" || STHURSDAY1_6TO7 == null){
                THURSDAY1_6TO7.setBackground(white);
            }
            else{
                THURSDAY1_6TO7.setBackground(green);
                THURSDAY1_6TO7LABEL.setText(STHURSDAY1_6TO7);
            }
            rs = st.executeQuery(query23);
            while(rs.next()){
                STHURSDAY2_6TO7 = rs.getString(1);             
            }          
            if(STHURSDAY2_6TO7 == "" || STHURSDAY2_6TO7 == null){
                THURSDAY2_6TO7.setBackground(white);
            }
            else{
                THURSDAY2_6TO7.setBackground(green);
                THURSDAY2_6TO7LABEL.setText(STHURSDAY2_6TO7);
            }
            
            }
        catch(Exception e){
            System.out.println(e);
        } 
   }
    public void FridaySchd(){
       try{ Connect();
            Statement st = connect.createStatement();
            String SFRIDAY1_7TO8 = null,SFRIDAY2_7TO8 = null, SFRIDAY1_8TO9 = null, SFRIDAY2_8TO9 = null, SFRIDAY1_9TO10= null, SFRIDAY2_9TO10= null;
            String SFRIDAY1_10TO11 = null, SFRIDAY2_10TO11= null, SFRIDAY1_11TO12= null, SFRIDAY2_11TO12= null, SFRIDAY1_12TO1= null, SFRIDAY2_12TO1= null;
            String SFRIDAY1_1TO2 = null, SFRIDAY2_1TO2= null, SFRIDAY1_2TO3 = null, SFRIDAY2_2TO3 = null, SFRIDAY1_3TO4 = null, SFRIDAY2_3TO4 = null;
            String SFRIDAY1_4TO5 = null, SFRIDAY2_4TO5 = null, SFRIDAY1_5TO6 = null, SFRIDAY2_5TO6 = null, SFRIDAY1_6TO7 = null, SFRIDAY2_6TO7 = null;  
            
            String query = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='7TO8H1'";
            String query1 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='7TO8H2'";
            String query2 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='8TO9H1'";
            String query3 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='8TO9H2'";
            String query4 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='9TO10H1'";
            String query5 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='9TO10H2'";
            String query6 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='10TO11H1'";
            String query7 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='10TO11H2'";
            String query8 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='11TO12H1'";
            String query9 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='11TO12H2'";
            String query10 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='12TO1H1'";
            String query11 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='12TO1H2'";
            String query12 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='1TO2H1'";
            String query13 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='1TO2H2'";
            String query14 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='2TO3H1'";
            String query15 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='2TO3H2'";
            String query16 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='3TO4H1'";
            String query17 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='3TO4H2'";
            String query18 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='4TO5H1'";
            String query19 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='4TO5H2'";
            String query20 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='5TO6H1'";
            String query21 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='5TO6H2'";
            String query22 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='6TO7H1'";
            String query23 = "SELECT Friday FROM "+section1+"_SCHED WHERE Time='6TO7H2'";
            
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                SFRIDAY1_7TO8 = rs.getString(1);             
            }
            if(SFRIDAY1_7TO8 == "" || SFRIDAY1_7TO8 == null){    
                FRIDAY1_7TO8.setBackground(white);
            }
            else{ 
                FRIDAY1_7TO8.setBackground(green);
                FRIDAY1_7TO8LABEL.setText(SFRIDAY1_7TO8);
            }           
            rs = st.executeQuery(query1);
            while(rs.next()){
                SFRIDAY2_7TO8 = rs.getString(1);             
            }          
            if(SFRIDAY2_7TO8 == "" || SFRIDAY2_7TO8 == null){
                FRIDAY2_7TO8.setBackground(white); 
            }
            else{
                FRIDAY2_7TO8.setBackground(green);
                FRIDAY2_7TO8LABEL.setText(SFRIDAY2_7TO8);
            }
            rs = st.executeQuery(query2);
            while(rs.next()){
                SFRIDAY1_8TO9 = rs.getString(1);             
            }          
            if(SFRIDAY1_8TO9 == "" || SFRIDAY1_8TO9 == null){
                FRIDAY1_8TO9.setBackground(white);   
            }
            else{
                FRIDAY1_8TO9.setBackground(green); 
                FRIDAY1_8TO9LABEL.setText(SFRIDAY1_8TO9);   
            }
            rs = st.executeQuery(query3);
            while(rs.next()){
                SFRIDAY2_8TO9 = rs.getString(1);             
            }          
            if(SFRIDAY2_8TO9 == "" || SFRIDAY2_8TO9 == null){
                FRIDAY2_8TO9.setBackground(white);   
            }
            else{ 
                FRIDAY2_8TO9.setBackground(green);
                FRIDAY2_8TO9LABEL.setText(SFRIDAY2_8TO9);              
            }
            rs = st.executeQuery(query4);
            while(rs.next()){
                SFRIDAY1_9TO10 = rs.getString(1);             
            }          
            if(SFRIDAY1_9TO10 == "" || SFRIDAY1_9TO10 == null){
                FRIDAY1_9TO10.setBackground(white);           
            }
            else{
                FRIDAY1_9TO10.setBackground(green); 
                FRIDAY1_9TO10LABEL.setText(SFRIDAY1_9TO10);
            }
            rs = st.executeQuery(query5);
            while(rs.next()){
                SFRIDAY2_9TO10 = rs.getString(1);             
            }          
            if(SFRIDAY2_9TO10 == "" || SFRIDAY2_9TO10 == null){
                FRIDAY2_9TO10.setBackground(white);
               
            }
            else{
                FRIDAY2_9TO10.setBackground(green);
                FRIDAY2_9TO10LABEL.setText(SFRIDAY2_9TO10);
            }
            rs = st.executeQuery(query6);
            while(rs.next()){
                SFRIDAY1_10TO11 = rs.getString(1);             
            }          
            if(SFRIDAY1_10TO11 == "" || SFRIDAY1_10TO11 == null){
                FRIDAY1_10TO11.setBackground(white);  
            }
            else{
                FRIDAY1_10TO11.setBackground(green);
                FRIDAY1_10TO11LABEL.setText(SFRIDAY1_10TO11);
            }
            rs = st.executeQuery(query7);
            while(rs.next()){
                SFRIDAY2_10TO11 = rs.getString(1);             
            }          
            if(SFRIDAY2_10TO11 == "" || SFRIDAY2_10TO11 == null){
                FRIDAY2_10TO11.setBackground(white); 
            }
            else{
                FRIDAY2_10TO11.setBackground(green); 
                FRIDAY2_10TO11LABEL.setText(SFRIDAY2_10TO11);
            }
            rs = st.executeQuery(query8);
            while(rs.next()){
                SFRIDAY1_11TO12 = rs.getString(1);             
            }          
            if(SFRIDAY1_11TO12 == "" || SFRIDAY1_11TO12 == null){
                FRIDAY1_11TO12.setBackground(white);
            }
            else{
                FRIDAY1_11TO12.setBackground(green);
                FRIDAY1_11TO12LABEL.setText(SFRIDAY1_11TO12);
            }
            rs = st.executeQuery(query9);
            while(rs.next()){
                SFRIDAY2_11TO12 = rs.getString(1);             
            }          
            if(SFRIDAY2_11TO12 == "" || SFRIDAY2_11TO12 == null){
                FRIDAY2_11TO12.setBackground(white);
            }
            else{
                FRIDAY2_11TO12.setBackground(green);
                FRIDAY2_11TO12LABEL.setText(SFRIDAY2_11TO12);
            }
            rs = st.executeQuery(query10);
            while(rs.next()){
                SFRIDAY1_12TO1 = rs.getString(1);             
            }          
            if(SFRIDAY1_12TO1 == "" || SFRIDAY1_12TO1 == null){
                FRIDAY1_12TO1.setBackground(white);
            }
            else{
                FRIDAY1_12TO1.setBackground(green);
                FRIDAY1_12TO1LABEL.setText(SFRIDAY1_12TO1);
            }
            rs = st.executeQuery(query11);
            while(rs.next()){
                SFRIDAY2_12TO1 = rs.getString(1);             
            }          
            if(SFRIDAY2_12TO1 == "" || SFRIDAY2_12TO1 == null){
                FRIDAY2_12TO1.setBackground(white);
            }
            else{
                FRIDAY2_12TO1.setBackground(green);
                FRIDAY2_12TO1LABEL.setText(SFRIDAY2_12TO1);
            }
            rs = st.executeQuery(query12);
            while(rs.next()){
                SFRIDAY1_1TO2 = rs.getString(1);             
            }          
            if(SFRIDAY1_1TO2 == "" || SFRIDAY1_1TO2 == null){
                FRIDAY1_1TO2.setBackground(white);
            }
            else{
                FRIDAY1_1TO2.setBackground(green);
                FRIDAY1_1TO2LABEL.setText(SFRIDAY1_1TO2);
            }
            rs = st.executeQuery(query13);
            while(rs.next()){
                SFRIDAY2_1TO2 = rs.getString(1);             
            }          
            if(SFRIDAY2_1TO2 == "" || SFRIDAY2_1TO2 == null){
                FRIDAY2_1TO2.setBackground(white);
            }
            else{
                FRIDAY2_1TO2.setBackground(green);
                FRIDAY2_1TO2LABEL.setText(SFRIDAY2_1TO2);
            }
            rs = st.executeQuery(query14);
            while(rs.next()){
                SFRIDAY1_2TO3 = rs.getString(1);             
            }          
            if(SFRIDAY1_2TO3 == "" || SFRIDAY1_2TO3 == null){
                FRIDAY1_2TO3.setBackground(white);
            }
            else{
                FRIDAY1_2TO3.setBackground(green);
                FRIDAY1_2TO3LABEL.setText(SFRIDAY1_2TO3);
            }
            rs = st.executeQuery(query15);
            while(rs.next()){
                SFRIDAY2_2TO3 = rs.getString(1);             
            }          
            if(SFRIDAY2_2TO3 == "" || SFRIDAY2_2TO3 == null){
                FRIDAY2_2TO3.setBackground(white);
            }
            else{
                FRIDAY2_2TO3.setBackground(green);
                FRIDAY2_2TO3LABEL.setText(SFRIDAY2_2TO3);
            }
            rs = st.executeQuery(query16);
            while(rs.next()){
                SFRIDAY1_3TO4 = rs.getString(1);             
            }          
            if(SFRIDAY1_3TO4 == "" || SFRIDAY1_3TO4 == null){
                FRIDAY1_3TO4.setBackground(white);
            }
            else{
                FRIDAY1_3TO4.setBackground(green);
                FRIDAY1_3TO4LABEL.setText(SFRIDAY1_3TO4);
            }
            
            rs = st.executeQuery(query17);
            while(rs.next()){
                SFRIDAY2_3TO4 = rs.getString(1);             
            } 
            if(SFRIDAY2_3TO4 == "" || SFRIDAY2_3TO4 == null){
                FRIDAY2_3TO4.setBackground(white);
            }
            else{
                FRIDAY2_3TO4.setBackground(green);
                FRIDAY2_3TO4LABEL.setText(SFRIDAY2_3TO4);
            }
            
            rs = st.executeQuery(query18);
            while(rs.next()){
                SFRIDAY1_4TO5 = rs.getString(1);             
            }          
            if(SFRIDAY1_4TO5 == "" || SFRIDAY1_4TO5 == null){
                FRIDAY1_4TO5.setBackground(white);
            }
            else{
                FRIDAY1_4TO5.setBackground(green);
                FRIDAY1_4TO5LABEL.setText(SFRIDAY1_4TO5);
            }
            rs = st.executeQuery(query19);
            while(rs.next()){
                SFRIDAY2_4TO5 = rs.getString(1);             
            }          
            if(SFRIDAY2_4TO5 == "" || SFRIDAY2_4TO5 == null){
                FRIDAY2_4TO5.setBackground(white);
            }
            else{
                FRIDAY2_4TO5.setBackground(green);
                FRIDAY2_4TO5LABEL.setText(SFRIDAY2_4TO5);
            }
            rs = st.executeQuery(query20);
            while(rs.next()){
                SFRIDAY1_5TO6 = rs.getString(1);             
            }          
            if(SFRIDAY1_5TO6 == "" || SFRIDAY1_5TO6 == null){
                FRIDAY1_5TO6.setBackground(white);
            }
            else{
                FRIDAY1_5TO6.setBackground(green);
                FRIDAY1_5TO6LABEL.setText(SFRIDAY1_5TO6);
            }
            rs = st.executeQuery(query21);
            while(rs.next()){
                SFRIDAY2_5TO6 = rs.getString(1);             
            }          
            if(SFRIDAY2_5TO6 == "" || SFRIDAY2_5TO6 == null){
                FRIDAY2_5TO6.setBackground(white);
            }
            else{
                FRIDAY2_5TO6.setBackground(green);
                FRIDAY2_5TO6LABEL.setText(SFRIDAY2_5TO6);
            }
            rs = st.executeQuery(query22);
            while(rs.next()){
                SFRIDAY1_6TO7 = rs.getString(1);             
            }          
            if(SFRIDAY1_6TO7 == "" || SFRIDAY1_6TO7 == null){
                FRIDAY1_6TO7.setBackground(white);
            }
            else{
                FRIDAY1_6TO7.setBackground(green);
                FRIDAY1_6TO7LABEL.setText(SFRIDAY1_6TO7);
            }
            rs = st.executeQuery(query23);
            while(rs.next()){
                SFRIDAY2_6TO7 = rs.getString(1);             
            }          
            if(SFRIDAY2_6TO7 == "" || SFRIDAY2_6TO7 == null){
                FRIDAY2_6TO7.setBackground(white);
            }
            else{
                FRIDAY2_6TO7.setBackground(green);
                FRIDAY2_6TO7LABEL.setText(SFRIDAY2_6TO7);
            }
            
            }
        catch(Exception e){
            System.out.println(e);
        } 
   }
    public void SaturdaySchd(){
       try{ Connect();
            Statement st = connect.createStatement();
            String SSATURDAY1_7TO8 = null,SSATURDAY2_7TO8 = null, SSATURDAY1_8TO9 = null, SSATURDAY2_8TO9 = null, SSATURDAY1_9TO10= null, SSATURDAY2_9TO10= null;
            String SSATURDAY1_10TO11 = null, SSATURDAY2_10TO11= null, SSATURDAY1_11TO12= null, SSATURDAY2_11TO12= null, SSATURDAY1_12TO1= null, SSATURDAY2_12TO1= null;
            String SSATURDAY1_1TO2 = null, SSATURDAY2_1TO2= null, SSATURDAY1_2TO3 = null, SSATURDAY2_2TO3 = null, SSATURDAY1_3TO4 = null, SSATURDAY2_3TO4 = null;
            String SSATURDAY1_4TO5 = null, SSATURDAY2_4TO5 = null, SSATURDAY1_5TO6 = null, SSATURDAY2_5TO6 = null, SSATURDAY1_6TO7 = null, SSATURDAY2_6TO7 = null;  
            
            String query = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='7TO8H1'";
            String query1 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='7TO8H2'";
            String query2 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='8TO9H1'";
            String query3 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='8TO9H2'";
            String query4 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='9TO10H1'";
            String query5 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='9TO10H2'";
            String query6 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='10TO11H1'";
            String query7 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='10TO11H2'";
            String query8 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='11TO12H1'";
            String query9 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='11TO12H2'";
            String query10 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='12TO1H1'";
            String query11 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='12TO1H2'";
            String query12 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='1TO2H1'";
            String query13 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='1TO2H2'";
            String query14 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='2TO3H1'";
            String query15 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='2TO3H2'";
            String query16 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='3TO4H1'";
            String query17 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='3TO4H2'";
            String query18 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='4TO5H1'";
            String query19 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='4TO5H2'";
            String query20 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='5TO6H1'";
            String query21 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='5TO6H2'";
            String query22 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='6TO7H1'";
            String query23 = "SELECT Saturday FROM "+section1+"_SCHED WHERE Time='6TO7H2'";
            
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                SSATURDAY1_7TO8 = rs.getString(1);             
            }
            if(SSATURDAY1_7TO8 == "" || SSATURDAY1_7TO8 == null){    
                SATURDAY1_7TO8.setBackground(white);
            }
            else{ 
                SATURDAY1_7TO8.setBackground(green);
                SATURDAY1_7TO8LABEL.setText(SSATURDAY1_7TO8);
            }           
            rs = st.executeQuery(query1);
            while(rs.next()){
                SSATURDAY2_7TO8 = rs.getString(1);             
            }          
            if(SSATURDAY2_7TO8 == "" || SSATURDAY2_7TO8 == null){
                SATURDAY2_7TO8.setBackground(white); 
            }
            else{
                SATURDAY2_7TO8.setBackground(green);
                SATURDAY2_7TO8LABEL.setText(SSATURDAY2_7TO8);
            }
            rs = st.executeQuery(query2);
            while(rs.next()){
                SSATURDAY1_8TO9 = rs.getString(1);             
            }          
            if(SSATURDAY1_8TO9 == "" || SSATURDAY1_8TO9 == null){
                SATURDAY1_8TO9.setBackground(white);   
            }
            else{
                SATURDAY1_8TO9.setBackground(green); 
                SATURDAY1_8TO9LABEL.setText(SSATURDAY1_8TO9);   
            }
            rs = st.executeQuery(query3);
            while(rs.next()){
                SSATURDAY2_8TO9 = rs.getString(1);             
            }          
            if(SSATURDAY2_8TO9 == "" || SSATURDAY2_8TO9 == null){
                SATURDAY2_8TO9.setBackground(white);   
            }
            else{ 
                SATURDAY2_8TO9.setBackground(green);
                SATURDAY2_8TO9LABEL.setText(SSATURDAY2_8TO9);              
            }
            rs = st.executeQuery(query4);
            while(rs.next()){
                SSATURDAY1_9TO10 = rs.getString(1);             
            }          
            if(SSATURDAY1_9TO10 == "" || SSATURDAY1_9TO10 == null){
                SATURDAY1_9TO10.setBackground(white);           
            }
            else{
                SATURDAY1_9TO10.setBackground(green); 
                SATURDAY1_9TO10LABEL.setText(SSATURDAY1_9TO10);
            }
            rs = st.executeQuery(query5);
            while(rs.next()){
                SSATURDAY2_9TO10 = rs.getString(1);             
            }          
            if(SSATURDAY2_9TO10 == "" || SSATURDAY2_9TO10 == null){
                SATURDAY2_9TO10.setBackground(white);
               
            }
            else{
                SATURDAY2_9TO10.setBackground(green);
                SATURDAY2_9TO10LABEL.setText(SSATURDAY2_9TO10);
            }
            rs = st.executeQuery(query6);
            while(rs.next()){
                SSATURDAY1_10TO11 = rs.getString(1);             
            }          
            if(SSATURDAY1_10TO11 == "" || SSATURDAY1_10TO11 == null){
                SATURDAY1_10TO11.setBackground(white);  
            }
            else{
                SATURDAY1_10TO11.setBackground(green);
                SATURDAY1_10TO11LABEL.setText(SSATURDAY1_10TO11);
            }
            rs = st.executeQuery(query7);
            while(rs.next()){
                SSATURDAY2_10TO11 = rs.getString(1);             
            }          
            if(SSATURDAY2_10TO11 == "" || SSATURDAY2_10TO11 == null){
                SATURDAY2_10TO11.setBackground(white); 
            }
            else{
                SATURDAY2_10TO11.setBackground(green); 
                SATURDAY2_10TO11LABEL.setText(SSATURDAY2_10TO11);
            }
            rs = st.executeQuery(query8);
            while(rs.next()){
                SSATURDAY1_11TO12 = rs.getString(1);             
            }          
            if(SSATURDAY1_11TO12 == "" || SSATURDAY1_11TO12 == null){
                SATURDAY1_11TO12.setBackground(white);
            }
            else{
                SATURDAY1_11TO12.setBackground(green);
                SATURDAY1_11TO12LABEL.setText(SSATURDAY1_11TO12);
            }
            rs = st.executeQuery(query9);
            while(rs.next()){
                SSATURDAY2_11TO12 = rs.getString(1);             
            }          
            if(SSATURDAY2_11TO12 == "" || SSATURDAY2_11TO12 == null){
                SATURDAY2_11TO12.setBackground(white);
            }
            else{
                SATURDAY2_11TO12.setBackground(green);
                SATURDAY2_11TO12LABEL.setText(SSATURDAY2_11TO12);
            }
            rs = st.executeQuery(query10);
            while(rs.next()){
                SSATURDAY1_12TO1 = rs.getString(1);             
            }          
            if(SSATURDAY1_12TO1 == "" || SSATURDAY1_12TO1 == null){
                SATURDAY1_12TO1.setBackground(white);
            }
            else{
                SATURDAY1_12TO1.setBackground(green);
                SATURDAY1_12TO1LABEL.setText(SSATURDAY1_12TO1);
            }
            rs = st.executeQuery(query11);
            while(rs.next()){
                SSATURDAY2_12TO1 = rs.getString(1);             
            }          
            if(SSATURDAY2_12TO1 == "" || SSATURDAY2_12TO1 == null){
                SATURDAY2_12TO1.setBackground(white);
            }
            else{
                SATURDAY2_12TO1.setBackground(green);
                SATURDAY2_12TO1LABEL.setText(SSATURDAY2_12TO1);
            }
            rs = st.executeQuery(query12);
            while(rs.next()){
                SSATURDAY1_1TO2 = rs.getString(1);             
            }          
            if(SSATURDAY1_1TO2 == "" || SSATURDAY1_1TO2 == null){
                SATURDAY1_1TO2.setBackground(white);
            }
            else{
                SATURDAY1_1TO2.setBackground(green);
                SATURDAY1_1TO2LABEL.setText(SSATURDAY1_1TO2);
            }
            rs = st.executeQuery(query13);
            while(rs.next()){
                SSATURDAY2_1TO2 = rs.getString(1);             
            }          
            if(SSATURDAY2_1TO2 == "" || SSATURDAY2_1TO2 == null){
                SATURDAY2_1TO2.setBackground(white);
            }
            else{
                SATURDAY2_1TO2.setBackground(green);
                SATURDAY2_1TO2LABEL.setText(SSATURDAY2_1TO2);
            }
            rs = st.executeQuery(query14);
            while(rs.next()){
                SSATURDAY1_2TO3 = rs.getString(1);             
            }          
            if(SSATURDAY1_2TO3 == "" || SSATURDAY1_2TO3 == null){
                SATURDAY1_2TO3.setBackground(white);
            }
            else{
                SATURDAY1_2TO3.setBackground(green);
                SATURDAY1_2TO3LABEL.setText(SSATURDAY1_2TO3);
            }
            rs = st.executeQuery(query15);
            while(rs.next()){
                SSATURDAY2_2TO3 = rs.getString(1);             
            }          
            if(SSATURDAY2_2TO3 == "" || SSATURDAY2_2TO3 == null){
                SATURDAY2_2TO3.setBackground(white);
            }
            else{
                SATURDAY2_2TO3.setBackground(green);
                SATURDAY2_2TO3LABEL.setText(SSATURDAY2_2TO3);
            }
            rs = st.executeQuery(query16);
            while(rs.next()){
                SSATURDAY1_3TO4 = rs.getString(1);             
            }          
            if(SSATURDAY1_3TO4 == "" || SSATURDAY1_3TO4 == null){
                SATURDAY1_3TO4.setBackground(white);
            }
            else{
                SATURDAY1_3TO4.setBackground(green);
                SATURDAY1_3TO4LABEL.setText(SSATURDAY1_3TO4);
            }
            
            rs = st.executeQuery(query17);
            while(rs.next()){
                SSATURDAY2_3TO4 = rs.getString(1);             
            } 
            if(SSATURDAY2_3TO4 == "" || SSATURDAY2_3TO4 == null){
                SATURDAY2_3TO4.setBackground(white);
            }
            else{
                SATURDAY2_3TO4.setBackground(green);
                SATURDAY2_3TO4LABEL.setText(SSATURDAY2_3TO4);
            }
            
            rs = st.executeQuery(query18);
            while(rs.next()){
                SSATURDAY1_4TO5 = rs.getString(1);             
            }          
            if(SSATURDAY1_4TO5 == "" || SSATURDAY1_4TO5 == null){
                SATURDAY1_4TO5.setBackground(white);
            }
            else{
                SATURDAY1_4TO5.setBackground(green);
                SATURDAY1_4TO5LABEL.setText(SSATURDAY1_4TO5);
            }
            rs = st.executeQuery(query19);
            while(rs.next()){
                SSATURDAY2_4TO5 = rs.getString(1);             
            }          
            if(SSATURDAY2_4TO5 == "" || SSATURDAY2_4TO5 == null){
                SATURDAY2_4TO5.setBackground(white);
            }
            else{
                SATURDAY2_4TO5.setBackground(green);
                SATURDAY2_4TO5LABEL.setText(SSATURDAY2_4TO5);
            }
            rs = st.executeQuery(query20);
            while(rs.next()){
                SSATURDAY1_5TO6 = rs.getString(1);             
            }          
            if(SSATURDAY1_5TO6 == "" || SSATURDAY1_5TO6 == null){
                SATURDAY1_5TO6.setBackground(white);
            }
            else{
                SATURDAY1_5TO6.setBackground(green);
                SATURDAY1_5TO6LABEL.setText(SSATURDAY1_5TO6);
            }
            rs = st.executeQuery(query21);
            while(rs.next()){
                SSATURDAY2_5TO6 = rs.getString(1);             
            }          
            if(SSATURDAY2_5TO6 == "" || SSATURDAY2_5TO6 == null){
                SATURDAY2_5TO6.setBackground(white);
            }
            else{
                SATURDAY2_5TO6.setBackground(green);
                SATURDAY2_5TO6LABEL.setText(SSATURDAY2_5TO6);
            }
            rs = st.executeQuery(query22);
            while(rs.next()){
                SSATURDAY1_6TO7 = rs.getString(1);             
            }          
            if(SSATURDAY1_6TO7 == "" || SSATURDAY1_6TO7 == null){
                SATURDAY1_6TO7.setBackground(white);
            }
            else{
                SATURDAY1_6TO7.setBackground(green);
                SATURDAY1_6TO7LABEL.setText(SSATURDAY1_6TO7);
            }
            rs = st.executeQuery(query23);
            while(rs.next()){
                SSATURDAY2_6TO7 = rs.getString(1);             
            }          
            if(SSATURDAY2_6TO7 == "" || SSATURDAY2_6TO7 == null){
                SATURDAY2_6TO7.setBackground(white);
            }
            else{
                SATURDAY2_6TO7.setBackground(green);
                SATURDAY2_6TO7LABEL.setText(SSATURDAY2_6TO7);
            }
            
            }
        catch(Exception e){
            System.out.println(e);
        } 
   }
    public void remove1s(){
        try{   
                int mon = Integer.parseInt( MONDAY1_7TO8LABEL.getText());
                if(mon == 1){
                MONDAY1_7TO8LABEL.setText("");
                }else if(mon > 1){MONDAY1_7TO8.setBackground(green);} }
         catch (Exception e){
             if(MONDAY1_7TO8LABEL.getText() == ""){
                 MONDAY1_7TO8.setBackground(white);
             }else{
                MONDAY1_7TO8.setBackground(green);
             }}
        try{   
                int mon2 = Integer.parseInt( MONDAY2_7TO8LABEL.getText());
                if(mon2 == 1){
                MONDAY2_7TO8LABEL.setText("");
                }else if(mon2 > 1){MONDAY2_7TO8.setBackground(green);}}
        catch (Exception e){
             if(MONDAY2_7TO8LABEL.getText() == ""){
                 MONDAY2_7TO8.setBackground(white);
             }else{
                MONDAY2_7TO8.setBackground(green);
             }}
        try{   
                int mon3 = Integer.parseInt( MONDAY1_8TO9LABEL.getText());
                if(mon3 == 1){
                MONDAY1_8TO9LABEL.setText("");
                }else if(mon3 > 1){MONDAY1_8TO9.setBackground(green);}}
         catch (Exception e){
             if(MONDAY1_8TO9LABEL.getText() == ""){
                 MONDAY1_8TO9.setBackground(white);
             }else{
                MONDAY1_8TO9.setBackground(green);
             }}
        try{
                int mon4 = Integer.parseInt( MONDAY2_8TO9LABEL.getText());
                if(mon4 == 1){
                MONDAY2_8TO9LABEL.setText("");
             }else if(mon4 > 1){MONDAY2_8TO9.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_8TO9LABEL.getText() == ""){
                 MONDAY1_8TO9.setBackground(white);
             }else{
                MONDAY1_8TO9.setBackground(green);
             }}
        try{        int mon5 = Integer.parseInt( MONDAY1_9TO10LABEL.getText());
                if(mon5 == 1){
                MONDAY1_9TO10LABEL.setText("");
                }else if(mon5 > 1){MONDAY1_9TO10.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_9TO10LABEL.getText() == ""){
                 MONDAY1_9TO10.setBackground(white);
             }else{
                MONDAY1_9TO10.setBackground(green);
             }} 
        try{    int mon6 = Integer.parseInt( MONDAY2_9TO10LABEL.getText());
                if(mon6 == 1){
                MONDAY2_9TO10LABEL.setText("");
                }else if(mon6 > 1){MONDAY2_9TO10.setBackground(green);}}
        catch (Exception e){
             if(MONDAY2_9TO10LABEL.getText() == ""){
                 MONDAY2_9TO10.setBackground(white);
             }else{
                MONDAY2_9TO10.setBackground(green);
             }}
        try{    int mon7 = Integer.parseInt( MONDAY1_10TO11LABEL.getText());
                if(mon7 == 1){
                MONDAY1_10TO11LABEL.setText("");
                }else if(mon7 > 1){MONDAY1_10TO11.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_10TO11LABEL.getText() == ""){
                 MONDAY1_10TO11.setBackground(white);
             }else{
                MONDAY1_10TO11.setBackground(green);
             }}
        try{    int mon8 = Integer.parseInt( MONDAY2_10TO11LABEL.getText());
                if(mon8 == 1){
                MONDAY2_10TO11LABEL.setText("");
                }else if(mon8 > 1){MONDAY2_10TO11.setBackground(green);}}
        catch (Exception e){
             if(MONDAY2_10TO11LABEL.getText() == ""){
                 MONDAY2_10TO11.setBackground(white);
             }else{
                MONDAY2_10TO11.setBackground(green);
             }}
        try{    int mon9 = Integer.parseInt( MONDAY1_11TO12LABEL.getText());
                if(mon9 == 1){
                MONDAY1_11TO12LABEL.setText("");
                }else if(mon9 > 1){MONDAY1_11TO12.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_11TO12LABEL.getText() == ""){
                 MONDAY1_11TO12.setBackground(white);
             }else{
                MONDAY1_11TO12.setBackground(green);
             }}
        try{    int mon10 = Integer.parseInt( MONDAY2_11TO12LABEL.getText());
                if(mon10 == 1){
                MONDAY2_11TO12LABEL.setText("");
                }else if(mon10 > 1){MONDAY2_11TO12.setBackground(green);}}
        catch (Exception e){
             if(MONDAY2_11TO12LABEL.getText() == ""){
                 MONDAY2_11TO12.setBackground(white);
             }else{
                MONDAY2_11TO12.setBackground(green);
             }}
        try{        int mon11 = Integer.parseInt( MONDAY1_12TO1LABEL.getText());
                if(mon11 == 1){
                MONDAY1_12TO1LABEL.setText("");
                }else if(mon11 > 1){MONDAY1_12TO1.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_12TO1LABEL.getText() == ""){
                 MONDAY1_12TO1.setBackground(white);
             }else{
                MONDAY1_12TO1.setBackground(green);
             }}
        try{    int mon12 = Integer.parseInt( MONDAY2_12TO1LABEL.getText());
                if(mon12 == 1){
                MONDAY2_12TO1LABEL.setText("");
                }else if(mon12 > 1){MONDAY2_12TO1.setBackground(green);}}
        catch (Exception e){
             if(MONDAY2_12TO1LABEL.getText() == ""){
                 MONDAY2_12TO1.setBackground(white);
             }else{
                MONDAY2_12TO1.setBackground(green);
             }}
        try{    int mon13 = Integer.parseInt( MONDAY1_1TO2LABEL.getText());
                if(mon13 == 1){
                MONDAY1_1TO2LABEL.setText("");
                }else if(mon13 > 1){MONDAY1_1TO2.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_1TO2LABEL.getText() == ""){
                 MONDAY1_1TO2.setBackground(white);
             }else{
                MONDAY1_1TO2.setBackground(green);
             }}
        try{    int mon14 = Integer.parseInt( MONDAY2_1TO2LABEL.getText());
                if(mon14 == 1){
                MONDAY2_1TO2LABEL.setText("");
                }else if(mon14 > 1){MONDAY2_1TO2.setBackground(green);}}
        catch (Exception e){
             if(MONDAY2_1TO2LABEL.getText() == ""){
                 MONDAY2_1TO2.setBackground(white);
             }else{
                MONDAY2_1TO2.setBackground(green);
             }}
        try{    int mon15 = Integer.parseInt( MONDAY1_2TO3LABEL.getText());
                if(mon15 == 1){
                MONDAY1_2TO3LABEL.setText("");
                }else if(mon15 > 1){MONDAY1_2TO3.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_2TO3LABEL.getText() == ""){
                 MONDAY1_2TO3.setBackground(white);
             }else{
                MONDAY1_2TO3.setBackground(green);
             }}
        try{    int mon16 = Integer.parseInt( MONDAY2_2TO3LABEL.getText());
                if(mon16 == 1){
                MONDAY2_2TO3LABEL.setText("");
                }else if(mon16 > 1){MONDAY2_2TO3.setBackground(green);}}
        catch (Exception e){
             if(MONDAY2_2TO3LABEL.getText() == ""){
                 MONDAY2_2TO3.setBackground(white);
             }else{
                MONDAY2_2TO3.setBackground(green);
             }}
        try{    int mon17 = Integer.parseInt( MONDAY1_3TO4LABEL.getText());
                if(mon17 == 1){
                MONDAY1_3TO4LABEL.setText("");
                }else if(mon17 > 1){MONDAY1_3TO4.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_3TO4LABEL.getText() == ""){
                 MONDAY1_3TO4.setBackground(white);
             }else{
                MONDAY1_3TO4.setBackground(green);
             }}
        try{    int mon18 = Integer.parseInt( MONDAY2_3TO4LABEL.getText());
                if(mon18 == 1){
                MONDAY2_3TO4LABEL.setText("");
                }else if(mon18 > 1){MONDAY2_3TO4.setBackground(green);}}
        catch (Exception e){
             if(MONDAY2_3TO4LABEL.getText() == ""){
                 MONDAY2_3TO4.setBackground(white);
             }else{
                MONDAY2_3TO4.setBackground(green);
             }}
        try{    int mon19 = Integer.parseInt( MONDAY1_4TO5LABEL.getText());
                if(mon19 == 1){
                MONDAY1_4TO5LABEL.setText("");
                }else if(mon19 > 1){MONDAY1_4TO5.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_4TO5LABEL.getText() == ""){
                 MONDAY1_4TO5.setBackground(white);
             }else{
                MONDAY1_4TO5.setBackground(green);
             }}        
        try{    int mon20 = Integer.parseInt( MONDAY2_4TO5LABEL.getText());
                if(mon20 == 1){
                MONDAY2_4TO5LABEL.setText("");
                }else if(mon20 > 1){MONDAY2_4TO5.setBackground(green);}}
        catch (Exception e){
             if(MONDAY2_4TO5LABEL.getText() == ""){
                 MONDAY2_4TO5.setBackground(white);
             }else{
                MONDAY2_4TO5.setBackground(green);
             }} 
        try{    int mon21 = Integer.parseInt( MONDAY1_5TO6LABEL.getText());
                if(mon21 == 1){
                MONDAY1_5TO6LABEL.setText("");
                }else if(mon21 > 1){MONDAY1_5TO6.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_5TO6LABEL.getText() == ""){
                 MONDAY1_4TO5.setBackground(white);
             }else{
                MONDAY1_5TO6.setBackground(green);
             }} 
        try{    int mon22 = Integer.parseInt( MONDAY2_5TO6LABEL.getText());
                if(mon22 == 1){
                MONDAY2_5TO6LABEL.setText("");
                }else if(mon22 > 1){MONDAY2_5TO6.setBackground(green);}}
        catch (Exception e){
             if(MONDAY2_5TO6LABEL.getText() == ""){
                 MONDAY2_4TO5.setBackground(white);
             }else{
                MONDAY2_5TO6.setBackground(green);
             }}
        try{    int mon23 = Integer.parseInt( MONDAY1_6TO7LABEL.getText());
                if(mon23 == 1){
                MONDAY1_6TO7LABEL.setText("");
                }else if(mon23 > 1){MONDAY1_6TO7.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_6TO7LABEL.getText() == ""){
                 MONDAY1_6TO7.setBackground(white);
             }else{
                MONDAY1_6TO7.setBackground(green);
             }}
        try{        int mon24 = Integer.parseInt( MONDAY2_6TO7LABEL.getText());
                if(mon24 == 1){
                MONDAY2_6TO7LABEL.setText("");
                }else if(mon24 > 1){MONDAY2_6TO7.setBackground(green);}}
        catch (Exception e){
             if(MONDAY1_6TO7LABEL.getText() == ""){
                 MONDAY1_6TO7.setBackground(white);
             }else{
                MONDAY1_6TO7.setBackground(green);
             }}
   
        try{   
                int tue = Integer.parseInt( TUESDAY1_7TO8LABEL.getText());
                if(tue == 1){
                TUESDAY1_7TO8LABEL.setText("");
                }else if(tue > 1){TUESDAY1_7TO8.setBackground(green);} }
         catch (Exception e){
             if(TUESDAY1_7TO8LABEL.getText() == ""){
                 TUESDAY1_7TO8.setBackground(white);
             }else{
                TUESDAY1_7TO8.setBackground(green);
             }}
        try{   
                int tue2 = Integer.parseInt( TUESDAY2_7TO8LABEL.getText());
                if(tue2 == 1){
                TUESDAY2_7TO8LABEL.setText("");
                }else if(tue2 > 1){TUESDAY2_7TO8.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY2_7TO8LABEL.getText() == ""){
                 TUESDAY2_7TO8.setBackground(white);
             }else{
                TUESDAY2_7TO8.setBackground(green);
             }}
        try{   
                int tue3 = Integer.parseInt( TUESDAY1_8TO9LABEL.getText());
                if(tue3 == 1){
                TUESDAY1_8TO9LABEL.setText("");
                }else if(tue3 > 1){TUESDAY1_8TO9.setBackground(green);}}
         catch (Exception e){
             if(TUESDAY1_8TO9LABEL.getText() == ""){
                 TUESDAY1_8TO9.setBackground(white);
             }else{
                TUESDAY1_8TO9.setBackground(green);
             }}
        try{
                int tue4 = Integer.parseInt( TUESDAY2_8TO9LABEL.getText());
                if(tue4 == 1){
                TUESDAY2_8TO9LABEL.setText("");
             }else if(tue4 > 1){TUESDAY2_8TO9.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_8TO9LABEL.getText() == ""){
                 TUESDAY1_8TO9.setBackground(white);
             }else{
                TUESDAY1_8TO9.setBackground(green);
             }}
        try{        int tue5 = Integer.parseInt( TUESDAY1_9TO10LABEL.getText());
                if(tue5 == 1){
                TUESDAY1_9TO10LABEL.setText("");
                }else if(tue5 > 1){TUESDAY1_9TO10.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_9TO10LABEL.getText() == ""){
                 TUESDAY1_9TO10.setBackground(white);
             }else{
                TUESDAY1_9TO10.setBackground(green);
             }} 
        try{    int tue6 = Integer.parseInt( TUESDAY2_9TO10LABEL.getText());
                if(tue6 == 1){
                TUESDAY2_9TO10LABEL.setText("");
                }else if(tue6 > 1){TUESDAY2_9TO10.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY2_9TO10LABEL.getText() == ""){
                 TUESDAY2_9TO10.setBackground(white);
             }else{
                TUESDAY2_9TO10.setBackground(green);
             }}
        try{    int tue7 = Integer.parseInt( TUESDAY1_10TO11LABEL.getText());
                if(tue7 == 1){
                TUESDAY1_10TO11LABEL.setText("");
                }else if(tue7 > 1){TUESDAY1_10TO11.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_10TO11LABEL.getText() == ""){
                 TUESDAY1_10TO11.setBackground(white);
             }else{
                TUESDAY1_10TO11.setBackground(green);
             }}
        try{    int tue8 = Integer.parseInt( TUESDAY2_10TO11LABEL.getText());
                if(tue8 == 1){
                TUESDAY2_10TO11LABEL.setText("");
                }else if(tue8 > 1){TUESDAY2_10TO11.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY2_10TO11LABEL.getText() == ""){
                 TUESDAY2_10TO11.setBackground(white);
             }else{
                TUESDAY2_10TO11.setBackground(green);
             }}
        try{    int tue9 = Integer.parseInt( TUESDAY1_11TO12LABEL.getText());
                if(tue9 == 1){
                TUESDAY1_11TO12LABEL.setText("");
                }else if(tue9 > 1){TUESDAY1_11TO12.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_11TO12LABEL.getText() == ""){
                 TUESDAY1_11TO12.setBackground(white);
             }else{
                TUESDAY1_11TO12.setBackground(green);
             }}
        try{    int tue10 = Integer.parseInt( TUESDAY2_11TO12LABEL.getText());
                if(tue10 == 1){
                TUESDAY2_11TO12LABEL.setText("");
                }else if(tue10 > 1){TUESDAY2_11TO12.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY2_11TO12LABEL.getText() == ""){
                 TUESDAY2_11TO12.setBackground(white);
             }else{
                TUESDAY2_11TO12.setBackground(green);
             }}
        try{        int tue11 = Integer.parseInt( TUESDAY1_12TO1LABEL.getText());
                if(tue11 == 1){
                TUESDAY1_12TO1LABEL.setText("");
                }else if(tue11 > 1){TUESDAY1_12TO1.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_12TO1LABEL.getText() == ""){
                 TUESDAY1_12TO1.setBackground(white);
             }else{
                TUESDAY1_12TO1.setBackground(green);
             }}
        try{    int tue12 = Integer.parseInt( TUESDAY2_12TO1LABEL.getText());
                if(tue12 == 1){
                TUESDAY2_12TO1LABEL.setText("");
                }else if(tue12 > 1){TUESDAY2_12TO1.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY2_12TO1LABEL.getText() == ""){
                 TUESDAY2_12TO1.setBackground(white);
             }else{
                TUESDAY2_12TO1.setBackground(green);
             }}
        try{    int tue13 = Integer.parseInt( TUESDAY1_1TO2LABEL.getText());
                if(tue13 == 1){
                TUESDAY1_1TO2LABEL.setText("");
                }else if(tue13 > 1){TUESDAY1_1TO2.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_1TO2LABEL.getText() == ""){
                 TUESDAY1_1TO2.setBackground(white);
             }else{
                TUESDAY1_1TO2.setBackground(green);
             }}
        try{    int tue14 = Integer.parseInt( TUESDAY2_1TO2LABEL.getText());
                if(tue14 == 1){
                TUESDAY2_1TO2LABEL.setText("");
                }else if(tue14 > 1){TUESDAY2_1TO2.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY2_1TO2LABEL.getText() == ""){
                 TUESDAY2_1TO2.setBackground(white);
             }else{
                TUESDAY2_1TO2.setBackground(green);
             }}
        try{    int tue15 = Integer.parseInt( TUESDAY1_2TO3LABEL.getText());
                if(tue15 == 1){
                TUESDAY1_2TO3LABEL.setText("");
                }else if(tue15 > 1){TUESDAY1_2TO3.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_2TO3LABEL.getText() == ""){
                 TUESDAY1_2TO3.setBackground(white);
             }else{
                TUESDAY1_2TO3.setBackground(green);
             }}
        try{    int tue16 = Integer.parseInt( TUESDAY2_2TO3LABEL.getText());
                if(tue16 == 1){
                TUESDAY2_2TO3LABEL.setText("");
                }else if(tue16 > 1){TUESDAY2_2TO3.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY2_2TO3LABEL.getText() == ""){
                 TUESDAY2_2TO3.setBackground(white);
             }else{
                TUESDAY2_2TO3.setBackground(green);
             }}
        try{    int tue17 = Integer.parseInt( TUESDAY1_3TO4LABEL.getText());
                if(tue17 == 1){
                TUESDAY1_3TO4LABEL.setText("");
                }else if(tue17 > 1){TUESDAY1_3TO4.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_3TO4LABEL.getText() == ""){
                 TUESDAY1_3TO4.setBackground(white);
             }else{
                TUESDAY1_3TO4.setBackground(green);
             }}
        try{    int tue18 = Integer.parseInt( TUESDAY2_3TO4LABEL.getText());
                if(tue18 == 1){
                TUESDAY2_3TO4LABEL.setText("");
                }else if(tue18 > 1){TUESDAY2_3TO4.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY2_3TO4LABEL.getText() == ""){
                 TUESDAY2_3TO4.setBackground(white);
             }else{
                TUESDAY2_3TO4.setBackground(green);
             }}
        try{    int tue19 = Integer.parseInt( TUESDAY1_4TO5LABEL.getText());
                if(tue19 == 1){
                TUESDAY1_4TO5LABEL.setText("");
                }else if(tue19 > 1){TUESDAY1_4TO5.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_4TO5LABEL.getText() == ""){
                 TUESDAY1_4TO5.setBackground(white);
             }else{
                TUESDAY1_4TO5.setBackground(green);
             }}        
        try{    int tue20 = Integer.parseInt( TUESDAY2_4TO5LABEL.getText());
                if(tue20 == 1){
                TUESDAY2_4TO5LABEL.setText("");
                }else if(tue20 > 1){TUESDAY2_4TO5.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY2_4TO5LABEL.getText() == ""){
                 TUESDAY2_4TO5.setBackground(white);
             }else{
                TUESDAY2_4TO5.setBackground(green);
             }} 
        try{    int tue21 = Integer.parseInt( TUESDAY1_5TO6LABEL.getText());
                if(tue21 == 1){
                TUESDAY1_5TO6LABEL.setText("");
                }else if(tue21 > 1){TUESDAY1_5TO6.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_5TO6LABEL.getText() == ""){
                 TUESDAY1_4TO5.setBackground(white);
             }else{
                TUESDAY1_5TO6.setBackground(green);
             }} 
        try{    int tue22 = Integer.parseInt( TUESDAY2_5TO6LABEL.getText());
                if(tue22 == 1){
                TUESDAY2_5TO6LABEL.setText("");
                }else if(tue22 > 1){TUESDAY2_5TO6.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY2_5TO6LABEL.getText() == ""){
                 TUESDAY2_4TO5.setBackground(white);
             }else{
                TUESDAY2_5TO6.setBackground(green);
             }}
        try{    int tue23 = Integer.parseInt( TUESDAY1_6TO7LABEL.getText());
                if(tue23 == 1){
                TUESDAY1_6TO7LABEL.setText("");
                }else if(tue23 > 1){TUESDAY1_6TO7.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_6TO7LABEL.getText() == ""){
                 TUESDAY1_6TO7.setBackground(white);
             }else{
                TUESDAY1_6TO7.setBackground(green);
             }}
        try{        int tue24 = Integer.parseInt( TUESDAY2_6TO7LABEL.getText());
                if(tue24 == 1){
                TUESDAY2_6TO7LABEL.setText("");
                }else if(tue24 > 1){TUESDAY2_6TO7.setBackground(green);}}
        catch (Exception e){
             if(TUESDAY1_6TO7LABEL.getText() == ""){
                 TUESDAY1_6TO7.setBackground(white);
             }else{
                TUESDAY1_6TO7.setBackground(green);
             }}
        
        try{   
                int wed = Integer.parseInt( WEDNESDAY1_7TO8LABEL.getText());
                if(wed == 1){
                WEDNESDAY1_7TO8LABEL.setText("");
                }else if(wed > 1){WEDNESDAY1_7TO8.setBackground(green);} }
         catch (Exception e){
             if(WEDNESDAY1_7TO8LABEL.getText() == ""){
                 WEDNESDAY1_7TO8.setBackground(white);
             }else{
                WEDNESDAY1_7TO8.setBackground(green);
             }}
        try{   
                int wed2 = Integer.parseInt( WEDNESDAY2_7TO8LABEL.getText());
                if(wed2 == 1){
                WEDNESDAY2_7TO8LABEL.setText("");
                }else if(wed2 > 1){WEDNESDAY2_7TO8.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY2_7TO8LABEL.getText() == ""){
                 WEDNESDAY2_7TO8.setBackground(white);
             }else{
                WEDNESDAY2_7TO8.setBackground(green);
             }}
        try{   
                int wed3 = Integer.parseInt( WEDNESDAY1_8TO9LABEL.getText());
                if(wed3 == 1){
                WEDNESDAY1_8TO9LABEL.setText("");
                }else if(wed3 > 1){WEDNESDAY1_8TO9.setBackground(green);}}
         catch (Exception e){
             if(WEDNESDAY1_8TO9LABEL.getText() == ""){
                 WEDNESDAY1_8TO9.setBackground(white);
             }else{
                WEDNESDAY1_8TO9.setBackground(green);
             }}
        try{
                int wed4 = Integer.parseInt( WEDNESDAY2_8TO9LABEL.getText());
                if(wed4 == 1){
                WEDNESDAY2_8TO9LABEL.setText("");
             }else if(wed4 > 1){WEDNESDAY2_8TO9.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_8TO9LABEL.getText() == ""){
                 WEDNESDAY1_8TO9.setBackground(white);
             }else{
                WEDNESDAY1_8TO9.setBackground(green);
             }}
        try{        int wed5 = Integer.parseInt( WEDNESDAY1_9TO10LABEL.getText());
                if(wed5 == 1){
                WEDNESDAY1_9TO10LABEL.setText("");
                }else if(wed5 > 1){WEDNESDAY1_9TO10.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_9TO10LABEL.getText() == ""){
                 WEDNESDAY1_9TO10.setBackground(white);
             }else{
                WEDNESDAY1_9TO10.setBackground(green);
             }} 
        try{    int wed6 = Integer.parseInt( WEDNESDAY2_9TO10LABEL.getText());
                if(wed6 == 1){
                WEDNESDAY2_9TO10LABEL.setText("");
                }else if(wed6 > 1){WEDNESDAY2_9TO10.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY2_9TO10LABEL.getText() == ""){
                 WEDNESDAY2_9TO10.setBackground(white);
             }else{
                WEDNESDAY2_9TO10.setBackground(green);
             }}
        try{    int wed7 = Integer.parseInt( WEDNESDAY1_10TO11LABEL.getText());
                if(wed7 == 1){
                WEDNESDAY1_10TO11LABEL.setText("");
                }else if(wed7 > 1){WEDNESDAY1_10TO11.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_10TO11LABEL.getText() == ""){
                 WEDNESDAY1_10TO11.setBackground(white);
             }else{
                WEDNESDAY1_10TO11.setBackground(green);
             }}
        try{    int wed8 = Integer.parseInt( WEDNESDAY2_10TO11LABEL.getText());
                if(wed8 == 1){
                WEDNESDAY2_10TO11LABEL.setText("");
                }else if(wed8 > 1){WEDNESDAY2_10TO11.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY2_10TO11LABEL.getText() == ""){
                 WEDNESDAY2_10TO11.setBackground(white);
             }else{
                WEDNESDAY2_10TO11.setBackground(green);
             }}
        try{    int wed9 = Integer.parseInt( WEDNESDAY1_11TO12LABEL.getText());
                if(wed9 == 1){
                WEDNESDAY1_11TO12LABEL.setText("");
                }else if(wed9 > 1){WEDNESDAY1_11TO12.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_11TO12LABEL.getText() == ""){
                 WEDNESDAY1_11TO12.setBackground(white);
             }else{
                WEDNESDAY1_11TO12.setBackground(green);
             }}
        try{    int wed10 = Integer.parseInt( WEDNESDAY2_11TO12LABEL.getText());
                if(wed10 == 1){
                WEDNESDAY2_11TO12LABEL.setText("");
                }else if(wed10 > 1){WEDNESDAY2_11TO12.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY2_11TO12LABEL.getText() == ""){
                 WEDNESDAY2_11TO12.setBackground(white);
             }else{
                WEDNESDAY2_11TO12.setBackground(green);
             }}
        try{        int wed11 = Integer.parseInt( WEDNESDAY1_12TO1LABEL.getText());
                if(wed11 == 1){
                WEDNESDAY1_12TO1LABEL.setText("");
                }else if(wed11 > 1){WEDNESDAY1_12TO1.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_12TO1LABEL.getText() == ""){
                 WEDNESDAY1_12TO1.setBackground(white);
             }else{
                WEDNESDAY1_12TO1.setBackground(green);
             }}
        try{    int wed12 = Integer.parseInt( WEDNESDAY2_12TO1LABEL.getText());
                if(wed12 == 1){
                WEDNESDAY2_12TO1LABEL.setText("");
                }else if(wed12 > 1){WEDNESDAY2_12TO1.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY2_12TO1LABEL.getText() == ""){
                 WEDNESDAY2_12TO1.setBackground(white);
             }else{
                WEDNESDAY2_12TO1.setBackground(green);
             }}
        try{    int wed13 = Integer.parseInt( WEDNESDAY1_1TO2LABEL.getText());
                if(wed13 == 1){
                WEDNESDAY1_1TO2LABEL.setText("");
                }else if(wed13 > 1){WEDNESDAY1_1TO2.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_1TO2LABEL.getText() == ""){
                 WEDNESDAY1_1TO2.setBackground(white);
             }else{
                WEDNESDAY1_1TO2.setBackground(green);
             }}
        try{    int wed14 = Integer.parseInt( WEDNESDAY2_1TO2LABEL.getText());
                if(wed14 == 1){
                WEDNESDAY2_1TO2LABEL.setText("");
                }else if(wed14 > 1){WEDNESDAY2_1TO2.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY2_1TO2LABEL.getText() == ""){
                 WEDNESDAY2_1TO2.setBackground(white);
             }else{
                WEDNESDAY2_1TO2.setBackground(green);
             }}
        try{    int wed15 = Integer.parseInt( WEDNESDAY1_2TO3LABEL.getText());
                if(wed15 == 1){
                WEDNESDAY1_2TO3LABEL.setText("");
                }else if(wed15 > 1){WEDNESDAY1_2TO3.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_2TO3LABEL.getText() == ""){
                 WEDNESDAY1_2TO3.setBackground(white);
             }else{
                WEDNESDAY1_2TO3.setBackground(green);
             }}
        try{    int wed16 = Integer.parseInt( WEDNESDAY2_2TO3LABEL.getText());
                if(wed16 == 1){
                WEDNESDAY2_2TO3LABEL.setText("");
                }else if(wed16 > 1){WEDNESDAY2_2TO3.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY2_2TO3LABEL.getText() == ""){
                 WEDNESDAY2_2TO3.setBackground(white);
             }else{
                WEDNESDAY2_2TO3.setBackground(green);
             }}
        try{    int wed17 = Integer.parseInt( WEDNESDAY1_3TO4LABEL.getText());
                if(wed17 == 1){
                WEDNESDAY1_3TO4LABEL.setText("");
                }else if(wed17 > 1){WEDNESDAY1_3TO4.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_3TO4LABEL.getText() == ""){
                 WEDNESDAY1_3TO4.setBackground(white);
             }else{
                WEDNESDAY1_3TO4.setBackground(green);
             }}
        try{    int wed18 = Integer.parseInt( WEDNESDAY2_3TO4LABEL.getText());
                if(wed18 == 1){
                WEDNESDAY2_3TO4LABEL.setText("");
                }else if(wed18 > 1){WEDNESDAY2_3TO4.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY2_3TO4LABEL.getText() == ""){
                 WEDNESDAY2_3TO4.setBackground(white);
             }else{
                WEDNESDAY2_3TO4.setBackground(green);
             }}
        try{    int wed19 = Integer.parseInt( WEDNESDAY1_4TO5LABEL.getText());
                if(wed19 == 1){
                WEDNESDAY1_4TO5LABEL.setText("");
                }else if(wed19 > 1){WEDNESDAY1_4TO5.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_4TO5LABEL.getText() == ""){
                 WEDNESDAY1_4TO5.setBackground(white);
             }else{
                WEDNESDAY1_4TO5.setBackground(green);
             }}        
        try{    int wed20 = Integer.parseInt( WEDNESDAY2_4TO5LABEL.getText());
                if(wed20 == 1){
                WEDNESDAY2_4TO5LABEL.setText("");
                }else if(wed20 > 1){WEDNESDAY2_4TO5.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY2_4TO5LABEL.getText() == ""){
                 WEDNESDAY2_4TO5.setBackground(white);
             }else{
                WEDNESDAY2_4TO5.setBackground(green);
             }} 
        try{    int wed21 = Integer.parseInt( WEDNESDAY1_5TO6LABEL.getText());
                if(wed21 == 1){
                WEDNESDAY1_5TO6LABEL.setText("");
                }else if(wed21 > 1){WEDNESDAY1_5TO6.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_5TO6LABEL.getText() == ""){
                 WEDNESDAY1_4TO5.setBackground(white);
             }else{
                WEDNESDAY1_5TO6.setBackground(green);
             }} 
        try{    int wed22 = Integer.parseInt( WEDNESDAY2_5TO6LABEL.getText());
                if(wed22 == 1){
                WEDNESDAY2_5TO6LABEL.setText("");
                }else if(wed22 > 1){WEDNESDAY2_5TO6.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY2_5TO6LABEL.getText() == ""){
                 WEDNESDAY2_4TO5.setBackground(white);
             }else{
                WEDNESDAY2_5TO6.setBackground(green);
             }}
        try{    int wed23 = Integer.parseInt( WEDNESDAY1_6TO7LABEL.getText());
                if(wed23 == 1){
                WEDNESDAY1_6TO7LABEL.setText("");
                }else if(wed23 > 1){WEDNESDAY1_6TO7.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_6TO7LABEL.getText() == ""){
                 WEDNESDAY1_6TO7.setBackground(white);
             }else{
                WEDNESDAY1_6TO7.setBackground(green);
             }}
        try{        int wed24 = Integer.parseInt( WEDNESDAY2_6TO7LABEL.getText());
                if(wed24 == 1){
                WEDNESDAY2_6TO7LABEL.setText("");
                }else if(wed24 > 1){WEDNESDAY2_6TO7.setBackground(green);}}
        catch (Exception e){
             if(WEDNESDAY1_6TO7LABEL.getText() == ""){
                 WEDNESDAY1_6TO7.setBackground(white);
             }else{
                WEDNESDAY1_6TO7.setBackground(green);
             }}
        
        try{   
                int thu = Integer.parseInt( THURSDAY1_7TO8LABEL.getText());
                if(thu == 1){
                THURSDAY1_7TO8LABEL.setText("");
                }else if(thu > 1){THURSDAY1_7TO8.setBackground(green);} }
         catch (Exception e){
             if(THURSDAY1_7TO8LABEL.getText() == ""){
                 THURSDAY1_7TO8.setBackground(white);
             }else{
                THURSDAY1_7TO8.setBackground(green);
             }}
        try{   
                int thu2 = Integer.parseInt( THURSDAY2_7TO8LABEL.getText());
                if(thu2 == 1){
                THURSDAY2_7TO8LABEL.setText("");
                }else if(thu2 > 1){THURSDAY2_7TO8.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY2_7TO8LABEL.getText() == ""){
                 THURSDAY2_7TO8.setBackground(white);
             }else{
                THURSDAY2_7TO8.setBackground(green);
             }}
        try{   
                int thu3 = Integer.parseInt( THURSDAY1_8TO9LABEL.getText());
                if(thu3 == 1){
                THURSDAY1_8TO9LABEL.setText("");
                }else if(thu3 > 1){THURSDAY1_8TO9.setBackground(green);}}
         catch (Exception e){
             if(THURSDAY1_8TO9LABEL.getText() == ""){
                 THURSDAY1_8TO9.setBackground(white);
             }else{
                THURSDAY1_8TO9.setBackground(green);
             }}
        try{
                int thu4 = Integer.parseInt( THURSDAY2_8TO9LABEL.getText());
                if(thu4 == 1){
                THURSDAY2_8TO9LABEL.setText("");
             }else if(thu4 > 1){THURSDAY2_8TO9.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_8TO9LABEL.getText() == ""){
                 THURSDAY1_8TO9.setBackground(white);
             }else{
                THURSDAY1_8TO9.setBackground(green);
             }}
        try{        int thu5 = Integer.parseInt( THURSDAY1_9TO10LABEL.getText());
                if(thu5 == 1){
                THURSDAY1_9TO10LABEL.setText("");
                }else if(thu5 > 1){THURSDAY1_9TO10.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_9TO10LABEL.getText() == ""){
                 THURSDAY1_9TO10.setBackground(white);
             }else{
                THURSDAY1_9TO10.setBackground(green);
             }} 
        try{    int thu6 = Integer.parseInt( THURSDAY2_9TO10LABEL.getText());
                if(thu6 == 1){
                THURSDAY2_9TO10LABEL.setText("");
                }else if(thu6 > 1){THURSDAY2_9TO10.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY2_9TO10LABEL.getText() == ""){
                 THURSDAY2_9TO10.setBackground(white);
             }else{
                THURSDAY2_9TO10.setBackground(green);
             }}
        try{    int thu7 = Integer.parseInt( THURSDAY1_10TO11LABEL.getText());
                if(thu7 == 1){
                THURSDAY1_10TO11LABEL.setText("");
                }else if(thu7 > 1){THURSDAY1_10TO11.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_10TO11LABEL.getText() == ""){
                 THURSDAY1_10TO11.setBackground(white);
             }else{
                THURSDAY1_10TO11.setBackground(green);
             }}
        try{    int thu8 = Integer.parseInt( THURSDAY2_10TO11LABEL.getText());
                if(thu8 == 1){
                THURSDAY2_10TO11LABEL.setText("");
                }else if(thu8 > 1){THURSDAY2_10TO11.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY2_10TO11LABEL.getText() == ""){
                 THURSDAY2_10TO11.setBackground(white);
             }else{
                THURSDAY2_10TO11.setBackground(green);
             }}
        try{    int thu9 = Integer.parseInt( THURSDAY1_11TO12LABEL.getText());
                if(thu9 == 1){
                THURSDAY1_11TO12LABEL.setText("");
                }else if(thu9 > 1){THURSDAY1_11TO12.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_11TO12LABEL.getText() == ""){
                 THURSDAY1_11TO12.setBackground(white);
             }else{
                THURSDAY1_11TO12.setBackground(green);
             }}
        try{    int thu10 = Integer.parseInt( THURSDAY2_11TO12LABEL.getText());
                if(thu10 == 1){
                THURSDAY2_11TO12LABEL.setText("");
                }else if(thu10 > 1){THURSDAY2_11TO12.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY2_11TO12LABEL.getText() == ""){
                 THURSDAY2_11TO12.setBackground(white);
             }else{
                THURSDAY2_11TO12.setBackground(green);
             }}
        try{        int thu11 = Integer.parseInt( THURSDAY1_12TO1LABEL.getText());
                if(thu11 == 1){
                THURSDAY1_12TO1LABEL.setText("");
                }else if(thu11 > 1){THURSDAY1_12TO1.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_12TO1LABEL.getText() == ""){
                 THURSDAY1_12TO1.setBackground(white);
             }else{
                THURSDAY1_12TO1.setBackground(green);
             }}
        try{    int thu12 = Integer.parseInt( THURSDAY2_12TO1LABEL.getText());
                if(thu12 == 1){
                THURSDAY2_12TO1LABEL.setText("");
                }else if(thu12 > 1){THURSDAY2_12TO1.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY2_12TO1LABEL.getText() == ""){
                 THURSDAY2_12TO1.setBackground(white);
             }else{
                THURSDAY2_12TO1.setBackground(green);
             }}
        try{    int thu13 = Integer.parseInt( THURSDAY1_1TO2LABEL.getText());
                if(thu13 == 1){
                THURSDAY1_1TO2LABEL.setText("");
                }else if(thu13 > 1){THURSDAY1_1TO2.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_1TO2LABEL.getText() == ""){
                 THURSDAY1_1TO2.setBackground(white);
             }else{
                THURSDAY1_1TO2.setBackground(green);
             }}
        try{    int thu14 = Integer.parseInt( THURSDAY2_1TO2LABEL.getText());
                if(thu14 == 1){
                THURSDAY2_1TO2LABEL.setText("");
                }else if(thu14 > 1){THURSDAY2_1TO2.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY2_1TO2LABEL.getText() == ""){
                 THURSDAY2_1TO2.setBackground(white);
             }else{
                THURSDAY2_1TO2.setBackground(green);
             }}
        try{    int thu15 = Integer.parseInt( THURSDAY1_2TO3LABEL.getText());
                if(thu15 == 1){
                THURSDAY1_2TO3LABEL.setText("");
                }else if(thu15 > 1){THURSDAY1_2TO3.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_2TO3LABEL.getText() == ""){
                 THURSDAY1_2TO3.setBackground(white);
             }else{
                THURSDAY1_2TO3.setBackground(green);
             }}
        try{    int thu16 = Integer.parseInt( THURSDAY2_2TO3LABEL.getText());
                if(thu16 == 1){
                THURSDAY2_2TO3LABEL.setText("");
                }else if(thu16 > 1){THURSDAY2_2TO3.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY2_2TO3LABEL.getText() == ""){
                 THURSDAY2_2TO3.setBackground(white);
             }else{
                THURSDAY2_2TO3.setBackground(green);
             }}
        try{    int thu17 = Integer.parseInt( THURSDAY1_3TO4LABEL.getText());
                if(thu17 == 1){
                THURSDAY1_3TO4LABEL.setText("");
                }else if(thu17 > 1){THURSDAY1_3TO4.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_3TO4LABEL.getText() == ""){
                 THURSDAY1_3TO4.setBackground(white);
             }else{
                THURSDAY1_3TO4.setBackground(green);
             }}
        try{    int thu18 = Integer.parseInt( THURSDAY2_3TO4LABEL.getText());
                if(thu18 == 1){
                THURSDAY2_3TO4LABEL.setText("");
                }else if(thu18 > 1){THURSDAY2_3TO4.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY2_3TO4LABEL.getText() == ""){
                 THURSDAY2_3TO4.setBackground(white);
             }else{
                THURSDAY2_3TO4.setBackground(green);
             }}
        try{    int thu19 = Integer.parseInt( THURSDAY1_4TO5LABEL.getText());
                if(thu19 == 1){
                THURSDAY1_4TO5LABEL.setText("");
                }else if(thu19 > 1){THURSDAY1_4TO5.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_4TO5LABEL.getText() == ""){
                 THURSDAY1_4TO5.setBackground(white);
             }else{
                THURSDAY1_4TO5.setBackground(green);
             }}        
        try{    int thu20 = Integer.parseInt( THURSDAY2_4TO5LABEL.getText());
                if(thu20 == 1){
                THURSDAY2_4TO5LABEL.setText("");
                }else if(thu20 > 1){THURSDAY2_4TO5.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY2_4TO5LABEL.getText() == ""){
                 THURSDAY2_4TO5.setBackground(white);
             }else{
                THURSDAY2_4TO5.setBackground(green);
             }} 
        try{    int thu21 = Integer.parseInt( THURSDAY1_5TO6LABEL.getText());
                if(thu21 == 1){
                THURSDAY1_5TO6LABEL.setText("");
                }else if(thu21 > 1){THURSDAY1_5TO6.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_5TO6LABEL.getText() == ""){
                 THURSDAY1_4TO5.setBackground(white);
             }else{
                THURSDAY1_5TO6.setBackground(green);
             }} 
        try{    int thu22 = Integer.parseInt( THURSDAY2_5TO6LABEL.getText());
                if(thu22 == 1){
                THURSDAY2_5TO6LABEL.setText("");
                }else if(thu22 > 1){THURSDAY2_5TO6.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY2_5TO6LABEL.getText() == ""){
                 THURSDAY2_4TO5.setBackground(white);
             }else{
                THURSDAY2_5TO6.setBackground(green);
             }}
        try{    int thu23 = Integer.parseInt( THURSDAY1_6TO7LABEL.getText());
                if(thu23 == 1){
                THURSDAY1_6TO7LABEL.setText("");
                }else if(thu23 > 1){THURSDAY1_6TO7.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_6TO7LABEL.getText() == ""){
                 THURSDAY1_6TO7.setBackground(white);
             }else{
                THURSDAY1_6TO7.setBackground(green);
             }}
        try{        int thu24 = Integer.parseInt( THURSDAY2_6TO7LABEL.getText());
                if(thu24 == 1){
                THURSDAY2_6TO7LABEL.setText("");
                }else if(thu24 > 1){THURSDAY2_6TO7.setBackground(green);}}
        catch (Exception e){
             if(THURSDAY1_6TO7LABEL.getText() == ""){
                 THURSDAY1_6TO7.setBackground(white);
             }else{
                THURSDAY1_6TO7.setBackground(green);
             }}
        
        try{   
                int fri = Integer.parseInt( FRIDAY1_7TO8LABEL.getText());
                if(fri == 1){
                FRIDAY1_7TO8LABEL.setText("");
                }else if(fri > 1){FRIDAY1_7TO8.setBackground(green);} }
         catch (Exception e){
             if(FRIDAY1_7TO8LABEL.getText() == ""){
                 FRIDAY1_7TO8.setBackground(white);
             }else{
                FRIDAY1_7TO8.setBackground(green);
             }}
        try{   
                int fri2 = Integer.parseInt( FRIDAY2_7TO8LABEL.getText());
                if(fri2 == 1){
                FRIDAY2_7TO8LABEL.setText("");
                }else if(fri2 > 1){FRIDAY2_7TO8.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY2_7TO8LABEL.getText() == ""){
                 FRIDAY2_7TO8.setBackground(white);
             }else{
                FRIDAY2_7TO8.setBackground(green);
             }}
        try{   
                int fri3 = Integer.parseInt( FRIDAY1_8TO9LABEL.getText());
                if(fri3 == 1){
                FRIDAY1_8TO9LABEL.setText("");
                }else if(fri3 > 1){FRIDAY1_8TO9.setBackground(green);}}
         catch (Exception e){
             if(FRIDAY1_8TO9LABEL.getText() == ""){
                 FRIDAY1_8TO9.setBackground(white);
             }else{
                FRIDAY1_8TO9.setBackground(green);
             }}
        try{
                int fri4 = Integer.parseInt( FRIDAY2_8TO9LABEL.getText());
                if(fri4 == 1){
                FRIDAY2_8TO9LABEL.setText("");
             }else if(fri4 > 1){FRIDAY2_8TO9.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_8TO9LABEL.getText() == ""){
                 FRIDAY1_8TO9.setBackground(white);
             }else{
                FRIDAY1_8TO9.setBackground(green);
             }}
        try{        int fri5 = Integer.parseInt( FRIDAY1_9TO10LABEL.getText());
                if(fri5 == 1){
                FRIDAY1_9TO10LABEL.setText("");
                }else if(fri5 > 1){FRIDAY1_9TO10.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_9TO10LABEL.getText() == ""){
                 FRIDAY1_9TO10.setBackground(white);
             }else{
                FRIDAY1_9TO10.setBackground(green);
             }} 
        try{    int fri6 = Integer.parseInt( FRIDAY2_9TO10LABEL.getText());
                if(fri6 == 1){
                FRIDAY2_9TO10LABEL.setText("");
                }else if(fri6 > 1){FRIDAY2_9TO10.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY2_9TO10LABEL.getText() == ""){
                 FRIDAY2_9TO10.setBackground(white);
             }else{
                FRIDAY2_9TO10.setBackground(green);
             }}
        try{    int fri7 = Integer.parseInt( FRIDAY1_10TO11LABEL.getText());
                if(fri7 == 1){
                FRIDAY1_10TO11LABEL.setText("");
                }else if(fri7 > 1){FRIDAY1_10TO11.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_10TO11LABEL.getText() == ""){
                 FRIDAY1_10TO11.setBackground(white);
             }else{
                FRIDAY1_10TO11.setBackground(green);
             }}
        try{    int fri8 = Integer.parseInt( FRIDAY2_10TO11LABEL.getText());
                if(fri8 == 1){
                FRIDAY2_10TO11LABEL.setText("");
                }else if(fri8 > 1){FRIDAY2_10TO11.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY2_10TO11LABEL.getText() == ""){
                 FRIDAY2_10TO11.setBackground(white);
             }else{
                FRIDAY2_10TO11.setBackground(green);
             }}
        try{    int fri9 = Integer.parseInt( FRIDAY1_11TO12LABEL.getText());
                if(fri9 == 1){
                FRIDAY1_11TO12LABEL.setText("");
                }else if(fri9 > 1){FRIDAY1_11TO12.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_11TO12LABEL.getText() == ""){
                 FRIDAY1_11TO12.setBackground(white);
             }else{
                FRIDAY1_11TO12.setBackground(green);
             }}
        try{    int fri10 = Integer.parseInt( FRIDAY2_11TO12LABEL.getText());
                if(fri10 == 1){
                FRIDAY2_11TO12LABEL.setText("");
                }else if(fri10 > 1){FRIDAY2_11TO12.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY2_11TO12LABEL.getText() == ""){
                 FRIDAY2_11TO12.setBackground(white);
             }else{
                FRIDAY2_11TO12.setBackground(green);
             }}
        try{        int fri11 = Integer.parseInt( FRIDAY1_12TO1LABEL.getText());
                if(fri11 == 1){
                FRIDAY1_12TO1LABEL.setText("");
                }else if(fri11 > 1){FRIDAY1_12TO1.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_12TO1LABEL.getText() == ""){
                 FRIDAY1_12TO1.setBackground(white);
             }else{
                FRIDAY1_12TO1.setBackground(green);
             }}
        try{    int fri12 = Integer.parseInt( FRIDAY2_12TO1LABEL.getText());
                if(fri12 == 1){
                FRIDAY2_12TO1LABEL.setText("");
                }else if(fri12 > 1){FRIDAY2_12TO1.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY2_12TO1LABEL.getText() == ""){
                 FRIDAY2_12TO1.setBackground(white);
             }else{
                FRIDAY2_12TO1.setBackground(green);
             }}
        try{    int fri13 = Integer.parseInt( FRIDAY1_1TO2LABEL.getText());
                if(fri13 == 1){
                FRIDAY1_1TO2LABEL.setText("");
                }else if(fri13 > 1){FRIDAY1_1TO2.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_1TO2LABEL.getText() == ""){
                 FRIDAY1_1TO2.setBackground(white);
             }else{
                FRIDAY1_1TO2.setBackground(green);
             }}
        try{    int fri14 = Integer.parseInt( FRIDAY2_1TO2LABEL.getText());
                if(fri14 == 1){
                FRIDAY2_1TO2LABEL.setText("");
                }else if(fri14 > 1){FRIDAY2_1TO2.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY2_1TO2LABEL.getText() == ""){
                 FRIDAY2_1TO2.setBackground(white);
             }else{
                FRIDAY2_1TO2.setBackground(green);
             }}
        try{    int fri15 = Integer.parseInt( FRIDAY1_2TO3LABEL.getText());
                if(fri15 == 1){
                FRIDAY1_2TO3LABEL.setText("");
                }else if(fri15 > 1){FRIDAY1_2TO3.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_2TO3LABEL.getText() == ""){
                 FRIDAY1_2TO3.setBackground(white);
             }else{
                FRIDAY1_2TO3.setBackground(green);
             }}
        try{    int fri16 = Integer.parseInt( FRIDAY2_2TO3LABEL.getText());
                if(fri16 == 1){
                FRIDAY2_2TO3LABEL.setText("");
                }else if(fri16 > 1){FRIDAY2_2TO3.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY2_2TO3LABEL.getText() == ""){
                 FRIDAY2_2TO3.setBackground(white);
             }else{
                FRIDAY2_2TO3.setBackground(green);
             }}
        try{    int fri17 = Integer.parseInt( FRIDAY1_3TO4LABEL.getText());
                if(fri17 == 1){
                FRIDAY1_3TO4LABEL.setText("");
                }else if(fri17 > 1){FRIDAY1_3TO4.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_3TO4LABEL.getText() == ""){
                 FRIDAY1_3TO4.setBackground(white);
             }else{
                FRIDAY1_3TO4.setBackground(green);
             }}
        try{    int fri18 = Integer.parseInt( FRIDAY2_3TO4LABEL.getText());
                if(fri18 == 1){
                FRIDAY2_3TO4LABEL.setText("");
                }else if(fri18 > 1){FRIDAY2_3TO4.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY2_3TO4LABEL.getText() == ""){
                 FRIDAY2_3TO4.setBackground(white);
             }else{
                FRIDAY2_3TO4.setBackground(green);
             }}
        try{    int fri19 = Integer.parseInt( FRIDAY1_4TO5LABEL.getText());
                if(fri19 == 1){
                FRIDAY1_4TO5LABEL.setText("");
                }else if(fri19 > 1){FRIDAY1_4TO5.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_4TO5LABEL.getText() == ""){
                 FRIDAY1_4TO5.setBackground(white);
             }else{
                FRIDAY1_4TO5.setBackground(green);
             }}        
        try{    int fri20 = Integer.parseInt( FRIDAY2_4TO5LABEL.getText());
                if(fri20 == 1){
                FRIDAY2_4TO5LABEL.setText("");
                }else if(fri20 > 1){FRIDAY2_4TO5.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY2_4TO5LABEL.getText() == ""){
                 FRIDAY2_4TO5.setBackground(white);
             }else{
                FRIDAY2_4TO5.setBackground(green);
             }} 
        try{    int fri21 = Integer.parseInt( FRIDAY1_5TO6LABEL.getText());
                if(fri21 == 1){
                FRIDAY1_5TO6LABEL.setText("");
                }else if(fri21 > 1){FRIDAY1_5TO6.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_5TO6LABEL.getText() == ""){
                 FRIDAY1_4TO5.setBackground(white);
             }else{
                FRIDAY1_5TO6.setBackground(green);
             }} 
        try{    int fri22 = Integer.parseInt( FRIDAY2_5TO6LABEL.getText());
                if(fri22 == 1){
                FRIDAY2_5TO6LABEL.setText("");
                }else if(fri22 > 1){FRIDAY2_5TO6.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY2_5TO6LABEL.getText() == ""){
                 FRIDAY2_4TO5.setBackground(white);
             }else{
                FRIDAY2_5TO6.setBackground(green);
             }}
        try{    int fri23 = Integer.parseInt( FRIDAY1_6TO7LABEL.getText());
                if(fri23 == 1){
                FRIDAY1_6TO7LABEL.setText("");
                }else if(fri23 > 1){FRIDAY1_6TO7.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_6TO7LABEL.getText() == ""){
                 FRIDAY1_6TO7.setBackground(white);
             }else{
                FRIDAY1_6TO7.setBackground(green);
             }}
        try{        int fri24 = Integer.parseInt( FRIDAY2_6TO7LABEL.getText());
                if(fri24 == 1){
                FRIDAY2_6TO7LABEL.setText("");
                }else if(fri24 > 1){FRIDAY2_6TO7.setBackground(green);}}
        catch (Exception e){
             if(FRIDAY1_6TO7LABEL.getText() == ""){
                 FRIDAY1_6TO7.setBackground(white);
             }else{
                FRIDAY1_6TO7.setBackground(green);
             }}
        
        try{   
                int sat = Integer.parseInt( SATURDAY1_7TO8LABEL.getText());
                if(sat == 1){
                SATURDAY1_7TO8LABEL.setText("");
                }else if(sat > 1){SATURDAY1_7TO8.setBackground(green);} }
         catch (Exception e){
             if(SATURDAY1_7TO8LABEL.getText() == ""){
                 SATURDAY1_7TO8.setBackground(white);
             }else{
                SATURDAY1_7TO8.setBackground(green);
             }}
        try{   
                int sat2 = Integer.parseInt( SATURDAY2_7TO8LABEL.getText());
                if(sat2 == 1){
                SATURDAY2_7TO8LABEL.setText("");
                }else if(sat2 > 1){SATURDAY2_7TO8.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY2_7TO8LABEL.getText() == ""){
                 SATURDAY2_7TO8.setBackground(white);
             }else{
                SATURDAY2_7TO8.setBackground(green);
             }}
        try{   
                int sat3 = Integer.parseInt( SATURDAY1_8TO9LABEL.getText());
                if(sat3 == 1){
                SATURDAY1_8TO9LABEL.setText("");
                }else if(sat3 > 1){SATURDAY1_8TO9.setBackground(green);}}
         catch (Exception e){
             if(SATURDAY1_8TO9LABEL.getText() == ""){
                 SATURDAY1_8TO9.setBackground(white);
             }else{
                SATURDAY1_8TO9.setBackground(green);
             }}
        try{
                int sat4 = Integer.parseInt( SATURDAY2_8TO9LABEL.getText());
                if(sat4 == 1){
                SATURDAY2_8TO9LABEL.setText("");
             }else if(sat4 > 1){SATURDAY2_8TO9.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_8TO9LABEL.getText() == ""){
                 SATURDAY1_8TO9.setBackground(white);
             }else{
                SATURDAY1_8TO9.setBackground(green);
             }}
        try{        int sat5 = Integer.parseInt( SATURDAY1_9TO10LABEL.getText());
                if(sat5 == 1){
                SATURDAY1_9TO10LABEL.setText("");
                }else if(sat5 > 1){SATURDAY1_9TO10.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_9TO10LABEL.getText() == ""){
                 SATURDAY1_9TO10.setBackground(white);
             }else{
                SATURDAY1_9TO10.setBackground(green);
             }} 
        try{    int sat6 = Integer.parseInt( SATURDAY2_9TO10LABEL.getText());
                if(sat6 == 1){
                SATURDAY2_9TO10LABEL.setText("");
                }else if(sat6 > 1){SATURDAY2_9TO10.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY2_9TO10LABEL.getText() == ""){
                 SATURDAY2_9TO10.setBackground(white);
             }else{
                SATURDAY2_9TO10.setBackground(green);
             }}
        try{    int sat7 = Integer.parseInt( SATURDAY1_10TO11LABEL.getText());
                if(sat7 == 1){
                SATURDAY1_10TO11LABEL.setText("");
                }else if(sat7 > 1){SATURDAY1_10TO11.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_10TO11LABEL.getText() == ""){
                 SATURDAY1_10TO11.setBackground(white);
             }else{
                SATURDAY1_10TO11.setBackground(green);
             }}
        try{    int sat8 = Integer.parseInt( SATURDAY2_10TO11LABEL.getText());
                if(sat8 == 1){
                SATURDAY2_10TO11LABEL.setText("");
                }else if(sat8 > 1){SATURDAY2_10TO11.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY2_10TO11LABEL.getText() == ""){
                 SATURDAY2_10TO11.setBackground(white);
             }else{
                SATURDAY2_10TO11.setBackground(green);
             }}
        try{    int sat9 = Integer.parseInt( SATURDAY1_11TO12LABEL.getText());
                if(sat9 == 1){
                SATURDAY1_11TO12LABEL.setText("");
                }else if(sat9 > 1){SATURDAY1_11TO12.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_11TO12LABEL.getText() == ""){
                 SATURDAY1_11TO12.setBackground(white);
             }else{
                SATURDAY1_11TO12.setBackground(green);
             }}
        try{    int sat10 = Integer.parseInt( SATURDAY2_11TO12LABEL.getText());
                if(sat10 == 1){
                SATURDAY2_11TO12LABEL.setText("");
                }else if(sat10 > 1){SATURDAY2_11TO12.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY2_11TO12LABEL.getText() == ""){
                 SATURDAY2_11TO12.setBackground(white);
             }else{
                SATURDAY2_11TO12.setBackground(green);
             }}
        try{        int sat11 = Integer.parseInt( SATURDAY1_12TO1LABEL.getText());
                if(sat11 == 1){
                SATURDAY1_12TO1LABEL.setText("");
                }else if(sat11 > 1){SATURDAY1_12TO1.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_12TO1LABEL.getText() == ""){
                 SATURDAY1_12TO1.setBackground(white);
             }else{
                SATURDAY1_12TO1.setBackground(green);
             }}
        try{    int sat12 = Integer.parseInt( SATURDAY2_12TO1LABEL.getText());
                if(sat12 == 1){
                SATURDAY2_12TO1LABEL.setText("");
                }else if(sat12 > 1){SATURDAY2_12TO1.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY2_12TO1LABEL.getText() == ""){
                 SATURDAY2_12TO1.setBackground(white);
             }else{
                SATURDAY2_12TO1.setBackground(green);
             }}
        try{    int sat13 = Integer.parseInt( SATURDAY1_1TO2LABEL.getText());
                if(sat13 == 1){
                SATURDAY1_1TO2LABEL.setText("");
                }else if(sat13 > 1){SATURDAY1_1TO2.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_1TO2LABEL.getText() == ""){
                 SATURDAY1_1TO2.setBackground(white);
             }else{
                SATURDAY1_1TO2.setBackground(green);
             }}
        try{    int sat14 = Integer.parseInt( SATURDAY2_1TO2LABEL.getText());
                if(sat14 == 1){
                SATURDAY2_1TO2LABEL.setText("");
                }else if(sat14 > 1){SATURDAY2_1TO2.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY2_1TO2LABEL.getText() == ""){
                 SATURDAY2_1TO2.setBackground(white);
             }else{
                SATURDAY2_1TO2.setBackground(green);
             }}
        try{    int sat15 = Integer.parseInt( SATURDAY1_2TO3LABEL.getText());
                if(sat15 == 1){
                SATURDAY1_2TO3LABEL.setText("");
                }else if(sat15 > 1){SATURDAY1_2TO3.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_2TO3LABEL.getText() == ""){
                 SATURDAY1_2TO3.setBackground(white);
             }else{
                SATURDAY1_2TO3.setBackground(green);
             }}
        try{    int sat16 = Integer.parseInt( SATURDAY2_2TO3LABEL.getText());
                if(sat16 == 1){
                SATURDAY2_2TO3LABEL.setText("");
                }else if(sat16 > 1){SATURDAY2_2TO3.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY2_2TO3LABEL.getText() == ""){
                 SATURDAY2_2TO3.setBackground(white);
             }else{
                SATURDAY2_2TO3.setBackground(green);
             }}
        try{    int sat17 = Integer.parseInt( SATURDAY1_3TO4LABEL.getText());
                if(sat17 == 1){
                SATURDAY1_3TO4LABEL.setText("");
                }else if(sat17 > 1){SATURDAY1_3TO4.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_3TO4LABEL.getText() == ""){
                 SATURDAY1_3TO4.setBackground(white);
             }else{
                SATURDAY1_3TO4.setBackground(green);
             }}
        try{    int sat18 = Integer.parseInt( SATURDAY2_3TO4LABEL.getText());
                if(sat18 == 1){
                SATURDAY2_3TO4LABEL.setText("");
                }else if(sat18 > 1){SATURDAY2_3TO4.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY2_3TO4LABEL.getText() == ""){
                 SATURDAY2_3TO4.setBackground(white);
             }else{
                SATURDAY2_3TO4.setBackground(green);
             }}
        try{    int sat19 = Integer.parseInt( SATURDAY1_4TO5LABEL.getText());
                if(sat19 == 1){
                SATURDAY1_4TO5LABEL.setText("");
                }else if(sat19 > 1){SATURDAY1_4TO5.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_4TO5LABEL.getText() == ""){
                 SATURDAY1_4TO5.setBackground(white);
             }else{
                SATURDAY1_4TO5.setBackground(green);
             }}        
        try{    int sat20 = Integer.parseInt( SATURDAY2_4TO5LABEL.getText());
                if(sat20 == 1){
                SATURDAY2_4TO5LABEL.setText("");
                }else if(sat20 > 1){SATURDAY2_4TO5.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY2_4TO5LABEL.getText() == ""){
                 SATURDAY2_4TO5.setBackground(white);
             }else{
                SATURDAY2_4TO5.setBackground(green);
             }} 
        try{    int sat21 = Integer.parseInt( SATURDAY1_5TO6LABEL.getText());
                if(sat21 == 1){
                SATURDAY1_5TO6LABEL.setText("");
                }else if(sat21 > 1){SATURDAY1_5TO6.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_5TO6LABEL.getText() == ""){
                 SATURDAY1_4TO5.setBackground(white);
             }else{
                SATURDAY1_5TO6.setBackground(green);
             }} 
        try{    int sat22 = Integer.parseInt( SATURDAY2_5TO6LABEL.getText());
                if(sat22 == 1){
                SATURDAY2_5TO6LABEL.setText("");
                }else if(sat22 > 1){SATURDAY2_5TO6.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY2_5TO6LABEL.getText() == ""){
                 SATURDAY2_4TO5.setBackground(white);
             }else{
                SATURDAY2_5TO6.setBackground(green);
             }}
        try{    int sat23 = Integer.parseInt( SATURDAY1_6TO7LABEL.getText());
                if(sat23 == 1){
                SATURDAY1_6TO7LABEL.setText("");
                }else if(sat23 > 1){SATURDAY1_6TO7.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_6TO7LABEL.getText() == ""){
                 SATURDAY1_6TO7.setBackground(white);
             }else{
                SATURDAY1_6TO7.setBackground(green);
             }}
        try{        int sat24 = Integer.parseInt( SATURDAY2_6TO7LABEL.getText());
                if(sat24 == 1){
                SATURDAY2_6TO7LABEL.setText("");
                }else if(sat24 > 1){SATURDAY2_6TO7.setBackground(green);}}
        catch (Exception e){
             if(SATURDAY1_6TO7LABEL.getText() == ""){
                 SATURDAY1_6TO7.setBackground(white);
             }else{
                SATURDAY1_6TO7.setBackground(green);
             }}
    }
    
}
