/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LoginAndSignUp;

import java.util.HashMap;

/**
 *S010324E
 * @author kurt
 */
public class IdAndPassword {
    
    HashMap<String, String> LoginInfo = new HashMap<>();
    
    IdAndPassword(){
        
        LoginInfo.put("kurt", "0542");
    }
    
    protected HashMap GetLoginInfo (){
        return LoginInfo;
    }
    
}
