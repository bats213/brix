/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package LoginAndSignUp;


/**
 *S010324E
 * R0325
 * @author ADMIN
 */
public class AttendanceSystem {

    public static void main(String[] args) {
        
   
    }
}
