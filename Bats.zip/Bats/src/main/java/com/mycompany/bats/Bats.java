/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bats;

/**
 *
 * @author ValMia iCafe
 */
public class Bats {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
